#' Database Connection Module
#'
#' @description
#' Provides tools for connecting to various databases.
#'
#' @name data_connect
#' @keywords internal
NULL

#' Connect to Database
#' @param db_type Database type: "sqlite", "mysql", "postgresql", "mongodb".
#' @param db_name Database name.
#' @param host Host address.
#' @param port Port number.
#' @param user Username.
#' @param password Password.
#' @param ... Additional arguments.
#' @return Database connection object.
#' @export
omni_connect_db <- function(db_type = "sqlite", db_name = NULL, host = "localhost",
                            port = NULL, user = NULL, password = NULL, ...) {
  con <- switch(db_type,
                sqlite = {
                  if (!requireNamespace("RSQLite", quietly = TRUE)) stop("RSQLite required")
                  DBI::dbConnect(RSQLite::SQLite(), dbname = db_name, ...)
                },
                mysql = {
                  if (!requireNamespace("RMariaDB", quietly = TRUE)) stop("RMariaDB required")
                  DBI::dbConnect(RMariaDB::MariaDB(), host = host, port = port,
                                 user = user, password = password, dbname = db_name, ...)
                },
                postgresql = {
                  if (!requireNamespace("RPostgres", quietly = TRUE)) stop("RPostgres required")
                  DBI::dbConnect(RPostgres::Postgres(), host = host, port = port,
                                 user = user, password = password, dbname = db_name, ...)
                },
                mongodb = {
                  if (!requireNamespace("mongolite", quietly = TRUE)) stop("mongolite required")
                  mongolite::mongo(db = db_name, url = paste0("mongodb://", host, ":", port), ...)
                })
  structure(list(connection = con, type = db_type), class = c("omni_db", "list"))
}

#' Query Database
#' @param db Database connection object.
#' @param query SQL query string.
#' @param ... Additional arguments.
#' @return Query results.
#' @export
omni_query_db <- function(db, query, ...) {
  if (db$type == "mongodb") {
    db$connection$find(query, ...)
  } else {
    DBI::dbGetQuery(db$connection, query, ...)
  }
}
