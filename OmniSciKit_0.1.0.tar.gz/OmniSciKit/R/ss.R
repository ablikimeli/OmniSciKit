#' Sample Size Module
#'
#' @description
#' Provides comprehensive sample size calculation tools for various
#' study designs and statistical tests.
#'
#' @name ss
#' @keywords internal
NULL

#' T-Test Sample Size
#' @param delta Effect size (Cohen's d).
#' @param sd Standard deviation. Default 1.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @param alternative "two.sided" or "one.sided".
#' @param type "one.sample", "two.sample", "paired".
#' @return Sample size per group.
#' @export
ss_ttest <- function(delta, sd = 1, power = 0.8, alpha = 0.05,
                     alternative = "two.sided", type = "two.sample") {
  if (type == "one.sample") {
    n <- power.t.test(delta = delta, sd = sd, sig.level = alpha, power = power,
                      type = "one.sample", alternative = alternative)$n
  } else if (type == "paired") {
    n <- power.t.test(delta = delta, sd = sd, sig.level = alpha, power = power,
                      type = "paired", alternative = alternative)$n
  } else {
    n <- power.t.test(delta = delta, sd = sd, sig.level = alpha, power = power,
                      type = "two.sample", alternative = alternative)$n
  }
  structure(list(n = ceiling(n), parameters = list(delta = delta, sd = sd, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' ANOVA Sample Size
#' @param groups Number of groups.
#' @param f Effect size (Cohen's f).
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size per group.
#' @export
ss_anova <- function(groups, f, power = 0.8, alpha = 0.05) {
  # Simplified calculation
  # Using power.anova.test
  tryCatch({
    result <- power.anova.test(groups = groups, between.var = f^2, within.var = 1,
                               sig.level = alpha, power = power)
    n <- result$n
  }, error = function(e) {
    # Approximate formula
    n <- 2 * ((qnorm(1 - alpha/2) + qnorm(power))^2) * (1/f^2)
  })
  structure(list(n = ceiling(n), parameters = list(groups = groups, f = f, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' Chi-Square Test Sample Size
#' @param p1 Proportion in group 1.
#' @param p2 Proportion in group 2.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size per group.
#' @export
ss_chisq <- function(p1, p2, power = 0.8, alpha = 0.05) {
  p_avg <- (p1 + p2) / 2
  delta <- abs(p1 - p2)
  n <- ((qnorm(1 - alpha/2) * sqrt(2 * p_avg * (1 - p_avg)) +
           qnorm(power) * sqrt(p1 * (1 - p1) + p2 * (1 - p2)))^2) / delta^2
  structure(list(n = ceiling(n), parameters = list(p1 = p1, p2 = p2, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' Correlation Sample Size
#' @param r Expected correlation.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @param alternative "two.sided" or "one.sided".
#' @return Sample size.
#' @export
ss_correlation <- function(r, power = 0.8, alpha = 0.05, alternative = "two.sided") {
  # Fisher's z transformation
  z_r <- 0.5 * log((1 + r) / (1 - r))
  if (alternative == "two.sided") {
    n <- ((qnorm(1 - alpha/2) + qnorm(power)) / z_r)^2 + 3
  } else {
    n <- ((qnorm(1 - alpha) + qnorm(power)) / z_r)^2 + 3
  }
  structure(list(n = ceiling(n), parameters = list(r = r, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' Linear Regression Sample Size
#' @param f2 Effect size (Cohen's f2).
#' @param n_pred Number of predictors.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size.
#' @export
ss_regression <- function(f2, n_pred, power = 0.8, alpha = 0.05) {
  # Simplified: using power calculation for multiple regression
  u <- n_pred
  v <- 1  # initial guess
  for (i in 1:100) {
    lambda <- f2 * (u + v + 1)
    v_new <- qf(power, u, v, lambda) * v / qf(1 - alpha, u, v)
    if (abs(v_new - v) < 0.01) break
    v <- v_new
  }
  n <- ceiling(v + u + 1)
  structure(list(n = n, parameters = list(f2 = f2, n_pred = n_pred, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' Logistic Regression Sample Size
#' @param p1 Event rate in group 1.
#' @param p2 Event rate in group 2.
#' @param r2 R-squared with other predictors. Default 0.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size.
#' @export
ss_logistic <- function(p1, p2, r2 = 0, power = 0.8, alpha = 0.05) {
  # Simplified formula
  p_avg <- (p1 + p2) / 2
  b <- log(p2 * (1 - p1) / (p1 * (1 - p2)))
  n <- (qnorm(1 - alpha/2) + qnorm(power))^2 / (p_avg * (1 - p_avg) * b^2 * (1 - r2))
  structure(list(n = ceiling(n), parameters = list(p1 = p1, p2 = p2, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' Cox Regression Sample Size
#' @param hr Hazard ratio.
#' @param p Event rate.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Number of events needed.
#' @export
ss_cox <- function(hr, p, power = 0.8, alpha = 0.05) {
  # Events needed
  events <- (qnorm(1 - alpha/2) + qnorm(power))^2 / (p * (log(hr))^2)
  structure(list(events = ceiling(events), n = ceiling(events / p),
                 parameters = list(hr = hr, p = p, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' Two Proportions Sample Size
#' @param p1 Proportion 1.
#' @param p2 Proportion 2.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size per group.
#' @export
ss_two_prop <- function(p1, p2, power = 0.8, alpha = 0.05) {
  ss_chisq(p1, p2, power, alpha)
}

#' Two Means Sample Size
#' @param delta Mean difference.
#' @param sd Standard deviation.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size per group.
#' @export
ss_two_mean <- function(delta, sd, power = 0.8, alpha = 0.05) {
  ss_ttest(delta / sd, sd = sd, power = power, alpha = alpha, type = "two.sample")
}

#' Paired T-Test Sample Size
#' @param delta Mean difference.
#' @param sd_sd Standard deviation of differences.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size (pairs).
#' @export
ss_paired_ttest <- function(delta, sd_sd, power = 0.8, alpha = 0.05) {
  ss_ttest(delta / sd_sd, sd = sd_sd, power = power, alpha = alpha, type = "paired")
}

#' McNemar's Test Sample Size
#' @param p12 Proportion changing from + to -.
#' @param p21 Proportion changing from - to +.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size (pairs).
#' @export
ss_mcnemar <- function(p12, p21, power = 0.8, alpha = 0.05) {
  discordant <- p12 + p21
  n <- ((qnorm(1 - alpha/2) * sqrt(discordant) + qnorm(power) * sqrt(discordant - (p12 - p21)^2))^2) /
    (p12 - p21)^2
  structure(list(n = ceiling(n), parameters = list(p12 = p12, p21 = p21, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' Kappa Statistic Sample Size
#' @param kappa0 Null hypothesis kappa.
#' @param kappa1 Alternative hypothesis kappa.
#' @param p Proportion of positive ratings.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size.
#' @export
ss_kappa <- function(kappa0, kappa1, p, power = 0.8, alpha = 0.05) {
  # Simplified formula
  se0 <- sqrt(p * (1 - p) / (1 - kappa0)^2)
  se1 <- sqrt(p * (1 - p) / (1 - kappa1)^2)
  n <- ((qnorm(1 - alpha/2) * se0 + qnorm(power) * se1) / (kappa1 - kappa0))^2
  structure(list(n = ceiling(n), parameters = list(kappa0 = kappa0, kappa1 = kappa1, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' AUC Sample Size
#' @param auc0 Null hypothesis AUC.
#' @param auc1 Alternative hypothesis AUC.
#' @param ratio Ratio of cases to controls. Default 1.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size.
#' @export
ss_auc <- function(auc0, auc1, ratio = 1, power = 0.8, alpha = 0.05) {
  # Hanley-McNeil formula
  q1 <- auc1 / (2 - auc1)
  q2 <- 2 * auc1^2 / (1 + auc1)
  v <- qnorm(auc1) * (1 + ratio) / (2 * ratio)
  n_cases <- ((qnorm(1 - alpha/2) * sqrt(qnorm(auc0) * (1 + ratio) / (2 * ratio)) +
                 qnorm(power) * sqrt(v))^2) / (auc1 - auc0)^2
  structure(list(n_cases = ceiling(n_cases), n_controls = ceiling(n_cases * ratio),
                 parameters = list(auc0 = auc0, auc1 = auc1, ratio = ratio, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' Precision-Based Sample Size
#' @param p Expected proportion.
#' @param margin Margin of error. Default 0.05.
#' @param conf.level Confidence level. Default 0.95.
#' @return Sample size.
#' @export
ss_precision <- function(p, margin = 0.05, conf.level = 0.95) {
  z <- qnorm(1 - (1 - conf.level) / 2)
  n <- z^2 * p * (1 - p) / margin^2
  structure(list(n = ceiling(n), parameters = list(p = p, margin = margin, conf.level = conf.level)),
            class = c("omni_ss", "list"))
}

#' Equivalence Test Sample Size
#' @param delta Equivalence margin.
#' @param sd Standard deviation.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size per group.
#' @export
ss_equivalence <- function(delta, sd, power = 0.8, alpha = 0.05) {
  n <- 2 * ((qnorm(1 - alpha) + qnorm((1 + power) / 2))^2) * (sd^2) / (delta^2)
  structure(list(n = ceiling(n), parameters = list(delta = delta, sd = sd, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' Non-Inferiority Test Sample Size
#' @param delta Non-inferiority margin.
#' @param sd Standard deviation.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size per group.
#' @export
ss_noninferiority <- function(delta, sd, power = 0.8, alpha = 0.05) {
  n <- 2 * ((qnorm(1 - alpha) + qnorm(power))^2) * (sd^2) / (delta^2)
  structure(list(n = ceiling(n), parameters = list(delta = delta, sd = sd, power = power, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' Superiority Test Sample Size
#' @param delta Superiority margin.
#' @param sd Standard deviation.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size per group.
#' @export
ss_superiority <- function(delta, sd, power = 0.8, alpha = 0.05) {
  ss_ttest(delta, sd = sd, power = power, alpha = alpha, type = "two.sample")
}

#' Cluster Randomized Trial Sample Size
#' @param icc Intraclass correlation coefficient.
#' @param clusters Number of clusters per group.
#' @param effect_size Effect size.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size per cluster.
#' @export
ss_cluster_random <- function(icc, clusters, effect_size, power = 0.8, alpha = 0.05) {
  # Design effect
  de <- 1 + (clusters - 1) * icc
  # Individual sample size
  n_ind <- ss_ttest(effect_size, power = power, alpha = alpha)$n
  # Cluster sample size
  n_cluster <- ceiling(n_ind * de / clusters)
  structure(list(n_per_cluster = n_cluster, total_n = n_cluster * clusters,
                 parameters = list(icc = icc, clusters = clusters, effect_size = effect_size)),
            class = c("omni_ss", "list"))
}

#' Stratified Design Sample Size
#' @param strata_sizes Stratum proportions.
#' @param effect_size Effect size.
#' @param power Power. Default 0.8.
#' @param alpha Alpha level. Default 0.05.
#' @return Sample size per stratum.
#' @export
ss_stratified <- function(strata_sizes, effect_size, power = 0.8, alpha = 0.05) {
  n_total <- ss_ttest(effect_size, power = power, alpha = alpha)$n
  n_strata <- ceiling(n_total * strata_sizes)
  structure(list(n_strata = n_strata, total_n = sum(n_strata),
                 parameters = list(strata_sizes = strata_sizes, effect_size = effect_size)),
            class = c("omni_ss", "list"))
}

#' Adaptive Design Sample Size
#' @param n1 Stage 1 sample size.
#' @param effect_size Effect size.
#' @param alpha1 Stage 1 alpha.
#' @param alpha Overall alpha.
#' @return Adaptive design parameters.
#' @export
ss_adaptive <- function(n1, effect_size, alpha1 = 0.01, alpha = 0.05) {
  # Simplified adaptive design
  n_total <- ss_ttest(effect_size, alpha = alpha)$n
  n2 <- n_total - n1
  structure(list(n1 = n1, n2 = max(0, ceiling(n2)), n_total = ceiling(n_total),
                 parameters = list(effect_size = effect_size, alpha1 = alpha1, alpha = alpha)),
            class = c("omni_ss", "list"))
}

#' Futility Analysis Sample Size
#' @param n_interim Interim sample size.
#' @param n_total Total sample size.
#' @param futility_bound Futility boundary.
#' @return Futility parameters.
#' @export
ss_futility <- function(n_interim, n_total, futility_bound = 0.2) {
  structure(list(n_interim = n_interim, n_total = n_total, futility_bound = futility_bound),
            class = c("omni_ss", "list"))
}

#' Interim Analysis Sample Size
#' @param n_total Total sample size.
#' @param n_interims Number of interim analyses.
#' @param alpha_spending Alpha spending function.
#' @return Interim analysis schedule.
#' @export
ss_interim <- function(n_total, n_interims = 2, alpha_spending = "obrien_fleming") {
  times <- seq(0, 1, length.out = n_interims + 1)[-1]
  if (alpha_spending == "obrien_fleming") {
    alpha <- 2 * (1 - pnorm(qnorm(1 - 0.025 / 2) / sqrt(times)))
  } else {
    alpha <- times * 0.05
  }
  n_at_interim <- ceiling(times * n_total)
  structure(list(n_at_interim = n_at_interim, alpha_at_interim = alpha,
                 parameters = list(n_total = n_total, n_interims = n_interims)),
            class = c("omni_ss", "list"))
}

#' Multiplicity Adjustment Sample Size
#' @param n_comparisons Number of comparisons.
#' @param effect_size Effect size.
#' @param alpha Alpha level. Default 0.05.
#' @param adjustment Adjustment method: "bonferroni", "holm", "fdr".
#' @return Adjusted sample size.
#' @export
ss_multiplicity <- function(n_comparisons, effect_size, alpha = 0.05, adjustment = "bonferroni") {
  if (adjustment == "bonferroni") {
    alpha_adj <- alpha / n_comparisons
  } else {
    alpha_adj <- alpha
  }
  n <- ss_ttest(effect_size, alpha = alpha_adj)$n
  structure(list(n = n, alpha_adj = alpha_adj, parameters = list(n_comparisons = n_comparisons)),
            class = c("omni_ss", "list"))
}

#' MAMS (Multi-Arm Multi-Stage) Sample Size
#' @param n_arms Number of arms.
#' @param n_stages Number of stages.
#' @param effect_size Effect size.
#' @param power Power. Default 0.8.
#' @return MAMS parameters.
#' @export
ss_mams <- function(n_arms, n_stages, effect_size, power = 0.8) {
  # Simplified MAMS calculation
  n_per_arm <- ss_ttest(effect_size, power = power)$n
  total_n <- n_per_arm * n_arms * n_stages
  structure(list(n_per_arm = n_per_arm, total_n = total_n,
                 parameters = list(n_arms = n_arms, n_stages = n_stages)),
            class = c("omni_ss", "list"))
}

#' Basket Trial Sample Size
#' @param n_baskets Number of baskets.
#' @param p_response Response probability.
#' @param power Power. Default 0.8.
#' @return Sample size per basket.
#' @export
ss_basket_trial <- function(n_baskets, p_response, power = 0.8) {
  # Simplified basket trial
  n_per_basket <- ss_precision(p_response, margin = 0.1)$n
  structure(list(n_per_basket = n_per_basket, total_n = n_per_basket * n_baskets,
                 parameters = list(n_baskets = n_baskets, p_response = p_response)),
            class = c("omni_ss", "list"))
}

#' Platform Trial Sample Size
#' @param n_arms Number of arms (including control).
#' @param effect_size Effect size.
#' @param power Power. Default 0.8.
#' @return Sample size per arm.
#' @export
ss_platform_trial <- function(n_arms, effect_size, power = 0.8) {
  n_per_arm <- ss_ttest(effect_size, power = power)$n
  structure(list(n_per_arm = n_per_arm, total_n = n_per_arm * n_arms,
                 parameters = list(n_arms = n_arms)),
            class = c("omni_ss", "list"))
}
