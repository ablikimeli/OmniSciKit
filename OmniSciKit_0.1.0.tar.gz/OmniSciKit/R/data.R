#' Clinical Dataset
#'
#' Simulated clinical trial data with patient demographics,
#' biomarkers, treatment assignment, and outcomes.
#'
#' @format A data frame with 100 rows and 12 variables:
#' \describe{
#'   \item{patient_id}{Unique patient identifier}
#'   \item{age}{Age in years}
#'   \item{gender}{Gender (Male/Female)}
#'   \item{bmi}{Body mass index}
#'   \item{systolic_bp}{Systolic blood pressure}
#'   \item{diastolic_bp}{Diastolic blood pressure}
#'   \item{cholesterol}{Cholesterol level}
#'   \item{glucose}{Glucose level}
#'   \item{treatment}{Treatment group (Drug_A/Drug_B/Placebo)}
#'   \item{response}{Treatment response (Responder/Non_responder)}
#'   \item{survival_time}{Survival time in months}
#'   \item{event_status}{Event indicator (0=censored, 1=event)}
#' }
#' @examples
#' data(omni_clinical)
#' head(omni_clinical)
#' table(omni_clinical$treatment, omni_clinical$response)
#' @source Simulated data
#' @docType data
"omni_clinical"

#' Gene Expression Dataset
#'
#' Simulated gene expression matrix for differential expression analysis.
#'
#' @format A matrix with 50 genes (rows) and 20 samples (columns):
#' \describe{
#'   \item{rows}{Gene identifiers (GENE_1 to GENE_50)}
#'   \item{columns}{Sample identifiers (Sample_1 to Sample_20)}
#'   \item{values}{Log2-transformed expression values}
#' }
#' @examples
#' data(omni_expression)
#' dim(omni_expression)
#' boxplot(omni_expression[1:10,])
#' @source Simulated data
#' @docType data
"omni_expression"

#' Epidemic Dataset
#'
#' Simulated infectious disease outbreak data over 60 days.
#'
#' @format A data frame with 60 rows and 7 variables:
#' \describe{
#'   \item{day}{Day of outbreak}
#'   \item{new_cases}{Daily new cases}
#'   \item{new_deaths}{Daily new deaths}
#'   \item{cumulative_cases}{Cumulative case count}
#'   \item{tests_conducted}{Daily tests performed}
#'   \item{population}{Total population}
#'   \item{vaccination_rate}{Daily vaccination coverage}
#' }
#' @examples
#' data(omni_epidemic)
#' plot(omni_epidemic$day, omni_epidemic$new_cases, type = "l")
#' @source Simulated data
#' @docType data
"omni_epidemic"

#' Machine Learning Dataset
#'
#' Simulated dataset for classification and regression tasks.
#'
#' @format A data frame with 200 rows and 7 variables:
#' \describe{
#'   \item{feature1}{Numeric predictor variable}
#'   \item{feature2}{Numeric predictor variable}
#'   \item{feature3}{Numeric predictor variable}
#'   \item{feature4}{Numeric predictor variable}
#'   \item{feature5}{Numeric predictor variable}
#'   \item{target}{Categorical outcome (Class_A/B/C)}
#'   \item{continuous_target}{Numeric outcome for regression}
#' }
#' @examples
#' data(omni_ml_data)
#' head(omni_ml_data)
#' table(omni_ml_data$target)
#' @source Simulated data
"omni_ml_data"

#' Mendelian Randomization Dataset
#'
#' Simulated GWAS summary statistics for MR analysis.
#'
#' @format A data frame with 20 rows and 10 variables:
#' \describe{
#'   \item{SNP}{SNP identifier}
#'   \item{beta_exposure}{Effect on exposure}
#'   \item{se_exposure}{Standard error for exposure}
#'   \item{beta_outcome}{Effect on outcome}
#'   \item{se_outcome}{Standard error for outcome}
#'   \item{pval_exposure}{P-value for exposure}
#'   \item{pval_outcome}{P-value for outcome}
#'   \item{eaf}{Effect allele frequency}
#'   \item{samplesize_exposure}{Sample size for exposure GWAS}
#'   \item{samplesize_outcome}{Sample size for outcome GWAS}
#' }
#' @examples
#' data(omni_mr)
#' head(omni_mr)
#' plot(omni_mr$beta_exposure, omni_mr$beta_outcome)
#' @source Simulated data
#' @docType data
"omni_mr"

#' Time Series Dataset
#'
#' Simulated environmental and disease time series data.
#'
#' @format A data frame with 365 rows and 5 variables:
#' \describe{
#'   \item{date}{Calendar date}
#'   \item{temperature}{Daily temperature (Celsius)}
#'   \item{humidity}{Daily humidity (%)}
#'   \item{rainfall}{Daily rainfall (mm)}
#'   \item{cases}{Daily disease cases}
#' }
#' @examples
#' data(omni_timeseries)
#' head(omni_timeseries)
#' plot(1:nrow(omni_timeseries), omni_timeseries$cases, type = "l",
#'      xlab = "Day", ylab = "Cases", main = "Time Series")
#' @source Simulated data
#' @docType data
"omni_timeseries"

#' Demo Dataset
#'
#' Small simulated dataset for quick demonstrations.
#'
#' @format A data frame with 30 rows and 5 variables:
#' \describe{
#'   \item{id}{Patient ID}
#'   \item{age}{Age in years}
#'   \item{sex}{Gender (Male/Female)}
#'   \item{treatment}{Treatment group (A/B)}
#'   \item{outcome}{Outcome score}
#' }
#' @examples
#' data(omni_demo)
#' head(omni_demo)
#' @source Simulated data
#' @docType data
"omni_demo"

#' Epi Dataset
#'
#' Simulated epidemiological outbreak data.
#'
#' @format A data frame with 50 rows and 4 variables:
#' \describe{
#'   \item{day}{Day of outbreak}
#'   \item{cases}{Daily new cases}
#'   \item{deaths}{Daily new deaths}
#'   \item{recovered}{Daily recoveries}
#' }
#' @examples
#' data(omni_epi)
#' head(omni_epi)
#' @source Simulated data
#' @docType data
"omni_epi"

#' ML Dataset
#'
#' Simulated machine learning dataset (alternative version).
#'
#' @format A data frame with 100 rows and 6 variables:
#' \describe{
#'   \item{x1}{Numeric feature}
#'   \item{x2}{Numeric feature}
#'   \item{x3}{Numeric feature}
#'   \item{x4}{Numeric feature}
#'   \item{x5}{Numeric feature}
#'   \item{y}{Binary outcome}
#' }
#' @examples
#' data(omni_ml)
#' head(omni_ml)
#' @source Simulated data
#' @docType data
"omni_ml"
NA
"omni_ml"
