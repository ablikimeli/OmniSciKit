#' OmniSciKit Example Datasets
#'
#' @description
#' Example datasets for demonstrating OmniSciKit functionality.
#'
#' @name omni_datasets
#' @keywords datasets
NULL

#' Example Clinical Dataset
#'
#' A simulated clinical dataset with patient demographics and outcomes.
#'
#' @format A data frame with 200 rows and 8 variables:
#' \describe{
#'   \item{patient_id}{Patient identifier}
#'   \item{age}{Age in years}
#'   \item{sex}{Sex (Male/Female)}
#'   \item{treatment}{Treatment group (A/B)}
#'   \item{baseline_score}{Baseline measurement}
#'   \item{follow_up_score}{Follow-up measurement}
#'   \item{response}{Treatment response (Yes/No)}
#'   \item{survival_time}{Survival time in months}
#'   \item{event}{Event indicator (0=censored, 1=event)}
#' }
#' @examples
#' \dontrun{
#' data(omni_demo)
#' head(omni_demo)
#' }
"omni_demo"

#' Example Epidemiological Dataset
#'
#' A simulated dataset for infectious disease modeling.
#'
#' @format A data frame with 365 rows and 5 variables:
#' \describe{
#'   \item{day}{Day number}
#'   \item{cases}{New cases}
#'   \item{deaths}{New deaths}
#'   \item{recoveries}{New recoveries}
#'   \item{cumulative_cases}{Cumulative cases}
#' }
#' @examples
#' \dontrun{
#' data(omni_epi)
#' head(omni_epi)
#' }
"omni_epi"

#' Example Machine Learning Dataset
#'
#' A simulated dataset for machine learning demonstrations.
#'
#' @format A data frame with 500 rows and 10 variables:
#' \describe{
#'   \item{id}{Identifier}
#'   \item{feature_1}{Feature 1}
#'   \item{feature_2}{Feature 2}
#'   \item{feature_3}{Feature 3}
#'   \item{feature_4}{Feature 4}
#'   \item{feature_5}{Feature 5}
#'   \item{feature_6}{Feature 6}
#'   \item{feature_7}{Feature 7}
#'   \item{feature_8}{Feature 8}
#'   \item{outcome}{Binary outcome}
#' }
#' @examples
#' \dontrun{
#' data(omni_ml)
#' head(omni_ml)
#' }
"omni_ml"
