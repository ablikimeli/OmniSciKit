#' MR Power Calculation
#'
#' Calculate power for Mendelian Randomization study.
#'
#' @param R2 Variance explained by instruments.
#' @param N Sample size.
#' @param alpha Significance level (default 0.05).
#' @return List with power and parameters.
#' @examples
#' # Example 1: Basic power calculation
#' result <- mr_power(R2 = 0.02, N = 50000)
#' print(result)
#'
#' # Example 2: Vary sample size
#' sample_sizes <- c(10000, 25000, 50000, 100000)
#' powers <- sapply(sample_sizes, function(n) mr_power(R2 = 0.02, N = n)$power)
#' plot(sample_sizes, powers, type = "b", pch = 19, col = "blue",
#'      xlab = "Sample Size", ylab = "Power",
#'      main = "MR Power vs Sample Size")
#' abline(h = 0.8, col = "red", lty = 2)
#'
#' # Example 3: Using MR data
#' data(omni_mr)
#' f_stats <- (omni_mr$beta_exposure / omni_mr$se_exposure)^2
#' mean_r2 <- mean(f_stats / (f_stats + omni_mr$samplesize_exposure - 1))
#' result <- mr_power(R2 = mean_r2, N = mean(omni_mr$samplesize_exposure))
#' print(result)
#' @export
mr_power <- function(R2, N, alpha = 0.05) {
  za <- qnorm(1 - alpha/2)
  ncp <- sqrt(N * R2)
  power <- pnorm(ncp - za)
  
  result <- list(
    power = power,
    R2 = R2,
    N = N,
    alpha = alpha,
    note = ifelse(power > 0.8,
                  "Adequate power (>80%)",
                  "Power may be insufficient (<80%)")
  )
  class(result) <- "omni_mr"
  return(result)
}

#' Pleiotropy Test
#'
#' Test for pleiotropy in MR analysis.
#'
#' @param bx Instrument-exposure associations.
#' @param by Instrument-outcome associations.
#' @param sebx Standard errors for bx.
#' @param seby Standard errors for by.
#' @return List with pleiotropy test results.
#' @examples
#' # Example 1: Basic test
#' data(omni_mr)
#' result <- mr_pleiotropy(
#'   bx = omni_mr$beta_exposure,
#'   by = omni_mr$beta_outcome,
#'   sebx = omni_mr$se_exposure,
#'   seby = omni_mr$se_outcome
#' )
#' print(result)
#'
#' # Example 2: Funnel plot
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   ratios <- omni_mr$beta_outcome / omni_mr$beta_exposure
#'   se_ratios <- sqrt(omni_mr$se_outcome^2 / omni_mr$beta_exposure^2 +
#'                       omni_mr$beta_outcome^2 * omni_mr$se_exposure^2 / 
#'                       omni_mr$beta_exposure^4)
#'   df <- data.frame(ratio = ratios, se = se_ratios)
#'   p <- ggplot2::ggplot(df, ggplot2::aes(x = ratio, y = 1/se)) +
#'     ggplot2::geom_point(size = 3) +
#'     ggplot2::labs(title = "Funnel Plot", x = "MR Estimate", y = "Precision")
#'   print(p)
#' }
#' @export
mr_pleiotropy <- function(bx, by, sebx, seby) {
  ivw <- sum(bx * by / seby^2) / sum(bx^2 / seby^2)
  
  weights <- (bx / seby)^2
  Q <- sum(weights * (by/bx - ivw)^2)
  df <- length(bx) - 1
  p_value <- 1 - pchisq(Q, df)
  
  result <- list(
    Q = Q,
    df = df,
    p_value = p_value,
    ivw_estimate = ivw,
    interpretation = ifelse(p_value < 0.05,
                            "Significant heterogeneity detected (possible pleiotropy)",
                            "No significant heterogeneity"),
    note = paste0("Q = ", round(Q, 2), ", p = ", format.pval(p_value, eps = 0.001))
  )
  class(result) <- "omni_mr"
  return(result)
}

#' Inverse Variance Weighted MR
#'
#' IVW method for MR analysis.
#'
#' @param bx Instrument-exposure associations.
#' @param by Instrument-outcome associations.
#' @param sebx Standard errors for bx.
#' @param seby Standard errors for by.
#' @return List with IVW results.
#' @examples
#' # Example 1: Basic IVW
#' data(omni_mr)
#' result <- mr_ivw(
#'   bx = omni_mr$beta_exposure,
#'   by = omni_mr$beta_outcome,
#'   sebx = omni_mr$se_exposure,
#'   seby = omni_mr$se_outcome
#' )
#' print(result)
#'
#' # Example 2: Scatter plot
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   df <- data.frame(
#'     bx = omni_mr$beta_exposure,
#'     by = omni_mr$beta_outcome
#'   )
#'   p <- ggplot2::ggplot(df, ggplot2::aes(x = bx, y = by)) +
#'     ggplot2::geom_point(size = 3) +
#'     ggplot2::geom_abline(intercept = 0, slope = result$estimate, 
#'                          color = "red", size = 1) +
#'     ggplot2::labs(title = "MR Scatter Plot", x = "Exposure", y = "Outcome")
#'   print(p)
#' }
#'
#' # Example 3: Compare methods
#' ivw_result <- mr_ivw(
#'   bx = omni_mr$beta_exposure,
#'   by = omni_mr$beta_outcome,
#'   sebx = omni_mr$se_exposure,
#'   seby = omni_mr$se_outcome
#' )
#' cat("IVW estimate:", round(ivw_result$estimate, 4), "\n")
#' cat("95% CI:", round(ivw_result$ci_95[1], 4), "-", round(ivw_result$ci_95[2], 4), "\n")
#' @export
mr_ivw <- function(bx, by, sebx, seby) {
  weights <- 1 / seby^2
  estimate <- sum(weights * by / bx) / sum(weights)
  se <- sqrt(1 / sum(weights * (bx/seby)^2))
  ci_lower <- estimate - 1.96 * se
  ci_upper <- estimate + 1.96 * se
  p_value <- 2 * (1 - pnorm(abs(estimate / se)))
  
  result <- list(
    estimate = estimate,
    se = se,
    ci_95 = c(ci_lower, ci_upper),
    p_value = p_value,
    method = "Inverse Variance Weighted",
    n_snps = length(bx),
    interpretation = ifelse(p_value < 0.05,
                            "Significant causal effect detected",
                            "No significant causal effect"),
    note = paste0("Estimate: ", round(estimate, 4), 
                  " (95% CI: ", round(ci_lower, 4), "-", round(ci_upper, 4), ")")
  )
  class(result) <- "omni_mr"
  return(result)
}

#' MR-Egger Regression
#'
#' MR-Egger method for pleiotropy-robust MR.
#'
#' @param bx Instrument-exposure associations.
#' @param by Instrument-outcome associations.
#' @param sebx Standard errors for bx.
#' @param seby Standard errors for by.
#' @return List with Egger results.
#' @examples
#' # Example 1: Basic Egger
#' data(omni_mr)
#' result <- mr_egger(
#'   bx = omni_mr$beta_exposure,
#'   by = omni_mr$beta_outcome,
#'   sebx = omni_mr$se_exposure,
#'   seby = omni_mr$se_outcome
#' )
#' print(result)
#'
#' # Example 2: Compare IVW vs Egger
#' ivw_result <- mr_ivw(
#'   bx = omni_mr$beta_exposure,
#'   by = omni_mr$beta_outcome,
#'   sebx = omni_mr$se_exposure,
#'   seby = omni_mr$se_outcome
#' )
#' cat("IVW:", round(ivw_result$estimate, 4), "\n")
#' cat("Egger:", round(result$estimate, 4), "\n")
#' cat("Egger intercept p:", format.pval(result$intercept_p, eps = 0.001), "\n")
#' @export
mr_egger <- function(bx, by, sebx, seby) {
  ratio <- by / bx
  precision <- 1 / seby
  
  fit <- lm(ratio ~ I(1/bx), weights = precision^2)
  
  estimate <- coef(fit)[2]
  se <- summary(fit)$coefficients[2, 2]
  ci_lower <- estimate - 1.96 * se
  ci_upper <- estimate + 1.96 * se
  p_value <- summary(fit)$coefficients[2, 4]
  
  intercept <- coef(fit)[1]
  intercept_p <- summary(fit)$coefficients[1, 4]
  
  result <- list(
    estimate = estimate,
    se = se,
    ci_95 = c(ci_lower, ci_upper),
    p_value = p_value,
    intercept = intercept,
    intercept_p = intercept_p,
    method = "MR-Egger",
    n_snps = length(bx),
    interpretation = ifelse(p_value < 0.05,
                            "Significant causal effect (Egger)",
                            "No significant causal effect (Egger)"),
    pleiotropy_test = ifelse(intercept_p < 0.05,
                             "Evidence of directional pleiotropy",
                             "No evidence of directional pleiotropy"),
    note = paste0("Estimate: ", round(estimate, 4), 
                  " | Intercept p: ", format.pval(intercept_p, eps = 0.001))
  )
  class(result) <- "omni_mr"
  return(result)
}

#' Print Method for MR Results
#'
#' @param x omni_mr object.
#' @param ... Additional arguments (not used).
#' @examples
#' result <- mr_power(R2 = 0.02, N = 50000)
#' print(result)
#' @export
print.omni_mr <- function(x, ...) {
  cat("\n=== Mendelian Randomization Results ===\n")
  if (!is.null(x$power)) {
    cat("Power:", round(x$power * 100, 1), "%\n")
  }
  if (!is.null(x$estimate)) {
    cat("Estimate:", round(x$estimate, 4), "\n")
    cat("95% CI:", round(x$ci_95[1], 4), "-", round(x$ci_95[2], 4), "\n")
    cat("P-value:", format.pval(x$p_value, eps = 0.001), "\n")
  }
  if (!is.null(x$Q)) {
    cat("Heterogeneity Q:", round(x$Q, 2), "\n")
    cat("P-value:", format.pval(x$p_value, eps = 0.001), "\n")
  }
  if (!is.null(x$interpretation)) {
    cat("Interpretation:", x$interpretation, "\n")
  }
  if (!is.null(x$pleiotropy_test)) {
    cat("Pleiotropy:", x$pleiotropy_test, "\n")
  }
  cat("\n")
}

