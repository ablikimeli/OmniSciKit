#' Mendelian Randomization Module
#'
#' @description
#' Provides comprehensive tools for Mendelian randomization analysis including
#' various MR methods, sensitivity analyses, and visualization.
#'
#' @name mr
#' @keywords internal
NULL

#' Inverse Variance Weighted (IVW) MR
#'
#' @param b_exp Beta coefficients for exposure.
#' @param b_out Beta coefficients for outcome.
#' @param se_exp Standard errors for exposure.
#' @param se_out Standard errors for outcome.
#' @param data Data frame containing the above columns.
#' @param method Method for IVW: "random", "fixed", "multiplicative".
#' @return MR results object
#' @export
mr_ivw <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL,
                   data = NULL, method = "random") {
  if (!is.null(data)) {
    b_exp <- data$b_exp; b_out <- data$b_out
    se_exp <- data$se_exp; se_out <- data$se_out
  }
  weights <- 1 / se_out^2
  b_ivw <- sum(b_out * weights) / sum(weights)
  
  if (method == "random") {
    Q <- sum(weights * (b_out - b_ivw)^2)
    df <- length(b_exp) - 1
    tau2 <- max(0, (Q - df) / (sum(weights) - sum(weights^2)/sum(weights)))
    weights <- 1 / (se_out^2 + tau2)
    b_ivw <- sum(b_out * weights) / sum(weights)
  }
  
  se_ivw <- sqrt(1 / sum(weights))
  p_value <- 2 * pnorm(-abs(b_ivw / se_ivw))
  
  structure(list(
    b = b_ivw, se = se_ivw, pval = p_value,
    ci_lower = b_ivw - 1.96 * se_ivw,
    ci_upper = b_ivw + 1.96 * se_ivw,
    method = paste("IVW", method), nsnp = length(b_exp)
  ), class = c("omni_mr", "list"))
}

#' MR-Egger Regression
#' @export
mr_egger <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  weights <- 1 / se_out^2
  fit <- lm(b_out ~ b_exp, weights = weights)
  slope <- coef(fit)[2]; se_slope <- summary(fit)$coefficients[2,2]
  p_slope <- 2 * pt(-abs(slope/se_slope), df = length(b_exp)-2)
  structure(list(
    b = slope, se = se_slope, pval = p_slope,
    ci_lower = slope - 1.96*se_slope, ci_upper = slope + 1.96*se_slope,
    intercept = coef(fit)[1], method = "MR-Egger", nsnp = length(b_exp)
  ), class = c("omni_mr", "list"))
}

#' Weighted Median MR
#' @export
mr_weighted_median <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  b_ratio <- b_out / b_exp
  weights <- 1 / (se_out / abs(b_exp))^2
  ordered <- order(b_ratio); b_ratio <- b_ratio[ordered]; weights <- weights[ordered]
  cum_weights <- cumsum(weights) / sum(weights)
  b_median <- b_ratio[which(cum_weights >= 0.5)[1]]
  # Bootstrap SE
  boot_est <- replicate(1000, {
    idx <- sample(length(b_exp), replace = TRUE)
    br <- (b_out[idx]/b_exp[idx])[order(b_out[idx]/b_exp[idx])]
    w <- (1/(se_out[idx]/abs(b_exp[idx]))^2)[order(b_out[idx]/b_exp[idx])]
    br[which(cumsum(w)/sum(w) >= 0.5)[1]]
  })
  se_median <- sd(boot_est)
  structure(list(
    b = b_median, se = se_median, pval = 2*pnorm(-abs(b_median/se_median)),
    ci_lower = b_median - 1.96*se_median, ci_upper = b_median + 1.96*se_median,
    method = "Weighted Median", nsnp = length(b_exp)
  ), class = c("omni_mr", "list"))
}

#' Simple Median MR
#' @export
mr_simple_median <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  b_ratio <- b_out / b_exp
  b_median <- median(b_ratio)
  boot_est <- replicate(1000, { idx <- sample(length(b_exp), replace = TRUE); median(b_out[idx]/b_exp[idx]) })
  se_median <- sd(boot_est)
  structure(list(
    b = b_median, se = se_median, pval = 2*pnorm(-abs(b_median/se_median)),
    ci_lower = b_median - 1.96*se_median, ci_upper = b_median + 1.96*se_median,
    method = "Simple Median", nsnp = length(b_exp)
  ), class = c("omni_mr", "list"))
}

#' Penalized Weighted Median
#' @export
mr_penalized <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  # Simple penalized approach: weight by F-statistic
  f_stat <- (b_exp/se_exp)^2
  weights <- pmin(f_stat, 100) / sum(pmin(f_stat, 100))
  b_weighted <- sum((b_out/b_exp) * weights)
  se_weighted <- sqrt(sum((weights * (se_out/b_exp))^2))
  structure(list(
    b = b_weighted, se = se_weighted, pval = 2*pnorm(-abs(b_weighted/se_weighted)),
    ci_lower = b_weighted - 1.96*se_weighted, ci_upper = b_weighted + 1.96*se_weighted,
    method = "Penalized", nsnp = length(b_exp)
  ), class = c("omni_mr", "list"))
}

#' MR-RAPS
#' @export
mr_raps <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  if (!requireNamespace("mr.raps", quietly = TRUE)) {
    stop("mr.raps package required. Install with: install_omni('mendelian_randomization')")
  }
  mr.raps::mr.raps(b_exp = b_exp, b_out = b_out, se_exp = se_exp, se_out = se_out)
}

#' MR-PRESSO
#' @export
mr_presso <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL, NbDistribution = 1000) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  if (!requireNamespace("MRPRESSO", quietly = TRUE)) {
    stop("MRPRESSO package required. Install with: install_omni('mendelian_randomization')")
  }
  MRPRESSO::mr_presso(BetaOutcome = b_out, BetaExposure = b_exp, SdOutcome = se_out, SdExposure = se_exp, NbDistribution = NbDistribution)
}

#' Radial MR
#' @export
mr_radial <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  if (!requireNamespace("RadialMR", quietly = TRUE)) {
    stop("RadialMR package required. Install with: install_omni('mendelian_randomization')")
  }
  RadialMR::ivw_radial(cbind(b_exp, b_out, se_exp, se_out))
}

#' Funnel Plot for MR
#' @export
mr_funnel_plot <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  b_ratio <- b_out / b_exp
  precision <- 1 / se_out
  
  ggplot2::ggplot(data.frame(Ratio = b_ratio, Precision = precision), 
                  ggplot2::aes(x = Ratio, y = Precision)) +
    ggplot2::geom_point(size = 3, alpha = 0.7) +
    ggplot2::geom_vline(xintercept = median(b_ratio), linetype = "dashed", color = "red") +
    ggplot2::labs(title = "MR Funnel Plot", x = "Causal Effect (beta_out/beta_exp)", y = "Precision (1/SE)") +
    ggplot2::theme_minimal()
}

#' Leave-One-Out Analysis
#' @export
mr_leave_one_out <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  results <- lapply(1:length(b_exp), function(i) {
    mr_ivw(b_exp[-i], b_out[-i], se_exp[-i], se_out[-i])
  })
  
  b_values <- sapply(results, function(x) x$b)
  se_values <- sapply(results, function(x) x$se)
  
  data.frame(
    SNP = paste0("SNP", 1:length(b_exp)),
    b = b_values,
    se = se_values,
    ci_lower = b_values - 1.96*se_values,
    ci_upper = b_values + 1.96*se_values
  )
}

#' Heterogeneity Test
#' @export
mr_heterogeneity <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  # Cochran's Q statistic
  b_ratio <- b_out / b_exp
  weights <- 1 / (se_out / abs(b_exp))^2
  b_ivw <- sum(b_ratio * weights) / sum(weights)
  Q <- sum(weights * (b_ratio - b_ivw)^2)
  df <- length(b_exp) - 1
  p_value <- 1 - pchisq(Q, df)
  I2 <- max(0, (Q - df) / Q * 100)
  
  structure(list(
    Q = Q, df = df, pval = p_value, I2 = I2,
    method = "Cochran's Q"
  ), class = c("omni_mr_het", "list"))
}

#' Pleiotropy Test
#' @export
mr_pleiotropy <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  egger_result <- mr_egger(b_exp, b_out, se_exp, se_out)
  structure(list(
    intercept = egger_result$intercept,
    se = egger_result$se_intercept,
    pval = egger_result$p_intercept,
    method = "MR-Egger Intercept"
  ), class = c("omni_mr_pleio", "list"))
}

#' Steiger Test for Directionality
#' @export
mr_steiger <- function(b_exp, b_out, se_exp, se_out, n_exp, n_out) {
  r_exp <- b_exp / sqrt(b_exp^2 + (n_exp - 2) * se_exp^2)
  r_out <- b_out / sqrt(b_out^2 + (n_out - 2) * se_out^2)
  
  z_exp <- atanh(r_exp) * sqrt(n_exp - 3)
  z_out <- atanh(r_out) * sqrt(n_out - 3)
  
  z_diff <- z_exp - z_out
  p_value <- 2 * pnorm(-abs(z_diff))
  
  structure(list(
    z_exp = z_exp, z_out = z_out,
    z_diff = z_diff, pval = p_value,
    direction = ifelse(z_exp > z_out, "Exposure -> Outcome", "Outcome -> Exposure"),
    method = "Steiger Test"
  ), class = c("omni_mr_steiger", "list"))
}

#' MR Power Calculation
#' @export
mr_power <- function(b_true, se_exp, se_out, n_snps, alpha = 0.05) {
  # Approximate power for IVW
  se_total <- sqrt(sum(1 / (se_out^2 + b_true^2 * se_exp^2)))
  ncp <- b_true / se_total
  power <- 1 - pt(qt(1 - alpha/2, df = n_snps - 1), df = n_snps - 1, ncp = ncp) +
    pt(qt(alpha/2, df = n_snps - 1), df = n_snps - 1, ncp = ncp)
  
  structure(list(
    power = power, ncp = ncp, alpha = alpha,
    n_snps = n_snps, b_true = b_true
  ), class = c("omni_mr_power", "list"))
}

#' Sensitivity Analysis
#' @export
mr_sensitivity <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  
  results <- list(
    ivw = mr_ivw(b_exp, b_out, se_exp, se_out),
    egger = mr_egger(b_exp, b_out, se_exp, se_out),
    weighted_median = mr_weighted_median(b_exp, b_out, se_exp, se_out),
    simple_median = mr_simple_median(b_exp, b_out, se_exp, se_out),
    heterogeneity = mr_heterogeneity(b_exp, b_out, se_exp, se_out),
    pleiotropy = mr_pleiotropy(b_exp, b_out, se_exp, se_out)
  )
  
  structure(results, class = c("omni_mr_sens", "list"))
}

#' MR Scatter Plot
#' @export
mr_scatter_plot <- function(b_exp = NULL, b_out = NULL, se_exp = NULL, se_out = NULL, data = NULL) {
  if (!is.null(data)) { b_exp <- data$b_exp; b_out <- data$b_out; se_exp <- data$se_exp; se_out <- data$se_out }
  
  df <- data.frame(
    b_exp = b_exp, b_out = b_out,
    se_exp = se_exp, se_out = se_out
  )
  
  # Fit lines
  ivw_fit <- lm(b_out ~ b_exp - 1, weights = 1/se_out^2)
  egger_fit <- lm(b_out ~ b_exp, weights = 1/se_out^2)
  
  ggplot2::ggplot(df, ggplot2::aes(x = b_exp, y = b_out)) +
    ggplot2::geom_point(size = 3, alpha = 0.7) +
    ggplot2::geom_errorbarh(ggplot2::aes(xmin = b_exp - se_exp, xmax = b_exp + se_exp), alpha = 0.3) +
    ggplot2::geom_errorbar(ggplot2::aes(ymin = b_out - se_out, ymax = b_out + se_out), alpha = 0.3) +
    ggplot2::geom_abline(intercept = 0, slope = coef(ivw_fit)[1], color = "red", linetype = "dashed") +
    ggplot2::geom_abline(intercept = coef(egger_fit)[1], slope = coef(egger_fit)[2], color = "blue", linetype = "dotted") +
    ggplot2::labs(title = "MR Scatter Plot", x = "Exposure Effect", y = "Outcome Effect") +
    ggplot2::theme_minimal()
}

#' MR Forest Plot
#' @export
mr_forest_plot <- function(mr_results) {
  if (inherits(mr_results, "omni_mr_sens")) {
    methods <- names(mr_results)[sapply(mr_results, inherits, "omni_mr")]
    df <- data.frame(
      Method = methods,
      b = sapply(methods, function(m) mr_results[[m]]$b),
      se = sapply(methods, function(m) mr_results[[m]]$se),
      pval = sapply(methods, function(m) mr_results[[m]]$pval)
    )
  } else {
    df <- data.frame(
      Method = "MR",
      b = mr_results$b,
      se = mr_results$se,
      pval = mr_results$pval
    )
  }
  
  df$ci_lower <- df$b - 1.96 * df$se
  df$ci_upper <- df$b + 1.96 * df$se
  
  ggplot2::ggplot(df, ggplot2::aes(x = Method, y = b)) +
    ggplot2::geom_point(size = 3) +
    ggplot2::geom_errorbar(ggplot2::aes(ymin = ci_lower, ymax = ci_upper), width = 0.2) +
    ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
    ggplot2::coord_flip() +
    ggplot2::labs(title = "MR Forest Plot", x = "Method", y = "Causal Effect") +
    ggplot2::theme_minimal()
}

#' Leave-One-Out Plot
#' @export
mr_loo_plot <- function(loo_results) {
  ggplot2::ggplot(loo_results, ggplot2::aes(x = SNP, y = b)) +
    ggplot2::geom_point(size = 3) +
    ggplot2::geom_errorbar(ggplot2::aes(ymin = ci_lower, ymax = ci_upper), width = 0.2) +
    ggplot2::geom_hline(yintercept = mean(loo_results$b), linetype = "dashed", color = "red") +
    ggplot2::coord_flip() +
    ggplot2::labs(title = "Leave-One-Out Analysis", x = "SNP Excluded", y = "Causal Effect") +
    ggplot2::theme_minimal()
}

#' Extract Instruments from GWAS
#' @export
mr_extract_instruments <- function(exposure_gwas, p1 = 5e-8, clump = TRUE, r2 = 0.001, kb = 10000) {
  if (!requireNamespace("TwoSampleMR", quietly = TRUE)) {
    stop("TwoSampleMR package required. Install with: install_omni('mendelian_randomization')")
  }
  TwoSampleMR::extract_instruments(
    exposure_gwas,
    p1 = p1,
    clump = clump,
    r2 = r2,
    kb = kb
  )
}

#' Extract Outcome Data
#' @export
mr_extract_outcome <- function(snps, outcome_gwas) {
  if (!requireNamespace("TwoSampleMR", quietly = TRUE)) {
    stop("TwoSampleMR package required. Install with: install_omni('mendelian_randomization')")
  }
  TwoSampleMR::extract_outcome_data(snps = snps, outcomes = outcome_gwas)
}

#' Harmonize Exposure and Outcome Data
#' @export
mr_harmonize <- function(exposure_dat, outcome_dat, action = 2) {
  if (!requireNamespace("TwoSampleMR", quietly = TRUE)) {
    stop("TwoSampleMR package required. Install with: install_omni('mendelian_randomization')")
  }
  TwoSampleMR::harmonise_data(exposure_dat, outcome_dat, action = action)
}

#' Clump SNPs
#' @export
mr_clump <- function(dat, clump_kb = 10000, clump_r2 = 0.001, clump_p1 = 1, clump_p2 = 1) {
  if (!requireNamespace("ieugwasr", quietly = TRUE)) {
    stop("ieugwasr package required. Install with: install_omni('mendelian_randomization')")
  }
  ieugwasr::ld_clump(
    dat,
    clump_kb = clump_kb,
    clump_r2 = clump_r2,
    clump_p1 = clump_p1,
    clump_p2 = clump_p2
  )
}

#' Calculate F-statistic
#' @export
mr_f_statistic <- function(b_exp, se_exp, n) {
  f_stat <- (b_exp / se_exp)^2
  mean_f <- mean(f_stat)
  
  structure(list(
    f_stat = f_stat,
    mean_f = mean_f,
    weak_instruments = sum(f_stat < 10),
    n = n
  ), class = c("omni_mr_fstat", "list"))
}

#' Directionality Test
#' @export
mr_directionality <- function(b_exp, b_out, se_exp, se_out, n_exp, n_out) {
  steiger <- mr_steiger(b_exp, b_out, se_exp, se_out, n_exp, n_out)
  
  structure(list(
    steiger = steiger,
    direction = steiger$direction,
    confidence = 1 - steiger$pval
  ), class = c("omni_mr_dir", "list"))
}
