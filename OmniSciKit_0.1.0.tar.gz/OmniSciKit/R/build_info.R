#' OmniSciKit Build Information
#'
#' Provides information about the package version and build.
#'
#' @return List with version and build information.
#' @examples
#' info <- omni_build_info()
#' print(info)
#' @export
omni_build_info <- function() {
  list(
    package = "OmniSciKit",
    version = "0.1.0",
    author = "Ablikim Ali",
    email = "medical_stat@163.com",
    github = "https://github.com/ablikimeli/OmniSciKit",
    license = "GPL-3",
    date = "2024",
    description = "A Comprehensive Toolkit for Biomedical Research",
    modules = c(
      "Sample Size Calculation (ss_*)",
      "Statistical Analysis (stats_*)",
      "Epidemiological Modeling (epi_*)",
      "Machine Learning (ml_*)",
      "Omics Analysis (omics_*)",
      "Mendelian Randomization (mr_*)"
    ),
    inspiration = c(
      "pwr - Power analysis (Champely et al.)",
      "epiR - Epidemiological analysis (Stevenson et al.)",
      "caret - Machine learning (Kuhn et al.)",
      "limma - Omics analysis (Ritchie et al.)",
      "TwoSampleMR - Mendelian randomization (Hemani et al.)",
      "automatedtests - Automated testing (Zeevat et al.)"
    )
  )
}
