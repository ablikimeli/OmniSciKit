#' @importFrom utils globalVariables
globalVariables(c('sd'))

#' Train-Test Split
#'
#' Split data into training and testing sets.
#'
#' @param data Data frame.
#' @param train_ratio Proportion for training (default 0.8).
#' @param seed Random seed.
#' @return List with train and test data frames.
#' @examples
#' # Example 1: Basic usage with ML data
#' data(omni_ml_data)
#' split <- ml_train_test_split(omni_ml_data, train_ratio = 0.8, seed = 123)
#' cat("Training:", nrow(split$train), "| Testing:", nrow(split$test), "\n")
#'
#' # Example 2: Using clinical data
#' data(omni_clinical)
#' split <- ml_train_test_split(omni_clinical, train_ratio = 0.75, seed = 42)
#' cat("Training:", nrow(split$train), "| Testing:", nrow(split$test), "\n")
#'
#' # Example 3: Check class balance
#' table(split$train$target)
#' table(split$test$target)
#' @export
ml_train_test_split <- function(data, train_ratio = 0.8, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  n <- nrow(data)
  train_idx <- sample(1:n, round(n * train_ratio))
  list(
    train = data[train_idx, ],
    test = data[-train_idx, ],
    train_ratio = train_ratio,
    n_train = length(train_idx),
    n_test = n - length(train_idx)
  )
}

#' Data Preprocessing
#'
#' Standardize numeric features and encode categoricals.
#'
#' @param data Data frame.
#' @param target_col Name of target column to exclude.
#' @return List with processed data and preprocessing parameters.
#' @examples
#' # Example 1: Basic usage
#' data(omni_ml_data)
#' preproc <- ml_preprocess(omni_ml_data[, 1:5])
#' head(preproc$data)
#'
#' # Example 2: Using clinical data
#' data(omni_clinical)
#' features <- omni_clinical[, c("age", "bmi", "systolic_bp", "cholesterol")]
#' preproc <- ml_preprocess(features)
#' summary(preproc$data)
#'
#' # Example 3: Compare before/after
#' par(mfrow = c(1, 2))
#' hist(features$age, main = "Original Age", breaks = 15)
#' hist(preproc$data$age, main = "Standardized Age", breaks = 15)
#' @export
ml_preprocess <- function(data, target_col = NULL) {
  numeric_cols <- sapply(data, is.numeric)
  means <- sapply(data[, numeric_cols, drop = FALSE], mean, na.rm = TRUE)
  sds <- sapply(data[, numeric_cols, drop = FALSE], sd, na.rm = TRUE)
  
  processed <- data
  processed[, numeric_cols] <- scale(data[, numeric_cols])
  
  list(
    data = processed,
    means = means,
    sds = sds,
    numeric_cols = numeric_cols
  )
}

#' Train Model
#'
#' Train a machine learning model.
#'
#' @param formula Model formula.
#' @param data Training data.
#' @param method Method: "lm", "glm", "rpart", "rf".
#' @return Trained model object.
#' @examples
#' # Example 1: Linear regression
#' data(omni_ml_data)
#' model <- ml_train(continuous_target ~ feature1 + feature2, 
#'                   data = omni_ml_data, method = "lm")
#' summary(model)
#'
#' # Example 2: Logistic regression with clinical data
#' data(omni_clinical)
#' omni_clinical$response_num <- ifelse(omni_clinical$response == "Responder", 1, 0)
#' model <- ml_train(response_num ~ age + bmi + cholesterol, 
#'                   data = omni_clinical, method = "glm")
#' summary(model)
#'
#' # Example 3: Compare methods
#' model_lm <- ml_train(continuous_target ~ feature1 + feature2,
#'                      data = omni_ml_data, method = "lm")
#' cat("LM model trained\n")
#' print(summary(model_lm)$r.squared)
#' @export
ml_train <- function(formula, data, method = "lm") {
  if (method == "lm") {
    model <- lm(formula, data = data)
  } else if (method == "glm") {
    model <- glm(formula, data = data, family = binomial())
  } else if (method == "rpart") {
    if (!requireNamespace("rpart", quietly = TRUE)) {
      stop("Please install 'rpart' package")
    }
    model <- rpart::rpart(formula, data = data)
  } else if (method == "rf") {
    if (!requireNamespace("randomForest", quietly = TRUE)) {
      stop("Please install 'randomForest' package")
    }
    model <- randomForest::randomForest(formula, data = data)
  } else {
    stop("Unknown method. Use 'lm', 'glm', 'rpart', or 'rf'")
  }
  
  class(model) <- c("omni_model", class(model))
  return(model)
}

#' Make Predictions
#'
#' Predict using trained model.
#'
#' @param model Trained model.
#' @param newdata New data for prediction.
#' @return Vector of predictions.
#' @examples
#' # Example 1: Basic prediction
#' data(omni_ml_data)
#' train_idx <- 1:150
#' model <- ml_train(continuous_target ~ feature1 + feature2, 
#'                   data = omni_ml_data[train_idx, ], method = "lm")
#' preds <- ml_predict(model, omni_ml_data[151:200, ])
#' head(preds)
#'
#' # Example 2: Compare predicted vs actual
#' actual <- omni_ml_data$continuous_target[151:200]
#' plot(preds, actual, main = "Predicted vs Actual", pch = 19, col = "blue")
#' abline(0, 1, col = "red", lwd = 2)
#'
#' # Example 3: Calculate RMSE
#' rmse <- sqrt(mean((preds - actual)^2))
#' cat("RMSE:", round(rmse, 3), "\n")
#' @export
ml_predict <- function(model, newdata) {
  if (inherits(model, "glm") && model$family$family == "binomial") {
    predict(model, newdata = newdata, type = "response")
  } else {
    predict(model, newdata = newdata)
  }
}

#' Model Evaluation
#'
#' Evaluate model performance.
#'
#' @param model Trained model.
#' @param test_data Test data.
#' @param target_col Target column name.
#' @return List with performance metrics.
#' @examples
#' # Example 1: Regression evaluation
#' data(omni_ml_data)
#' train_idx <- 1:150
#' model <- ml_train(continuous_target ~ feature1 + feature2, 
#'                   data = omni_ml_data[train_idx, ], method = "lm")
#' result <- ml_evaluate(model, omni_ml_data[151:200, ], "continuous_target")
#' print(result)
#'
#' # Example 2: Classification evaluation
#' omni_ml_data$binary_target <- ifelse(omni_ml_data$target == "Class_A", 1, 0)
#' model <- ml_train(binary_target ~ feature1 + feature2 + feature3, 
#'                   data = omni_ml_data[train_idx, ], method = "glm")
#' result <- ml_evaluate(model, omni_ml_data[151:200, ], "binary_target")
#' print(result)
#'
#' # Example 3: Visualization
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   preds <- ml_predict(model, omni_ml_data[151:200, ])
#'   actual <- omni_ml_data$continuous_target[151:200]
#'   df <- data.frame(Predicted = preds, Actual = actual)
#'   p <- ggplot2::ggplot(df, ggplot2::aes(x = Actual, y = Predicted)) +
#'     ggplot2::geom_point(size = 3, alpha = 0.6) +
#'     ggplot2::geom_abline(intercept = 0, slope = 1, color = "red", size = 1) +
#'     ggplot2::labs(title = "Model Performance")
#'   print(p)
#' }
#' @export
ml_evaluate <- function(model, test_data, target_col) {
  preds <- ml_predict(model, test_data)
  actual <- test_data[[target_col]]
  
  if (is.numeric(actual) && length(unique(actual)) > 10) {
    mse <- mean((preds - actual)^2)
    rmse <- sqrt(mse)
    mae <- mean(abs(preds - actual))
    r2 <- 1 - sum((actual - preds)^2) / sum((actual - mean(actual))^2)
    
    result <- list(
      type = "regression",
      mse = mse,
      rmse = rmse,
      mae = mae,
      r_squared = r2,
      predictions = preds,
      actual = actual
    )
  } else {
    if (is.numeric(preds)) {
      pred_class <- ifelse(preds > 0.5, 1, 0)
    } else {
      pred_class <- preds
    }
    
    cm <- table(Predicted = pred_class, Actual = actual)
    accuracy <- sum(diag(cm)) / sum(cm)
    
    result <- list(
      type = "classification",
      accuracy = accuracy,
      confusion_matrix = cm,
      predictions = preds,
      actual = actual
    )
  }
  
  class(result) <- "omni_ml"
  return(result)
}

#' Cross-Validation
#'
#' K-fold cross-validation.
#'
#' @param formula Model formula.
#' @param data Data frame.
#' @param method Model method.
#' @param k Number of folds.
#' @return List with CV results.
#' @examples
#' # Example 1: Basic CV
#' data(omni_ml_data)
#' result <- ml_cv(continuous_target ~ feature1 + feature2, 
#'                 data = omni_ml_data, method = "lm", k = 5)
#' print(result)
#'
#' # Example 2: Compare methods
#' result_lm <- ml_cv(continuous_target ~ feature1 + feature2, 
#'                    data = omni_ml_data, method = "lm", k = 5)
#' cat("LM RMSE:", round(result_lm$mean_rmse, 3), "+/-", round(result_lm$sd_rmse, 3), "\n")
#'
#' # Example 3: Using clinical data
#' data(omni_clinical)
#' result <- ml_cv(cholesterol ~ age + bmi, 
#'                 data = omni_clinical, method = "lm", k = 5)
#' print(result)
#' @export
ml_cv <- function(formula, data, method = "lm", k = 5) {
  n <- nrow(data)
  folds <- sample(rep(1:k, length.out = n))
  
  rmse_values <- numeric(k)
  
  for (i in 1:k) {
    train_data <- data[folds != i, ]
    test_data <- data[folds == i, ]
    
    model <- ml_train(formula, data = train_data, method = method)
    preds <- ml_predict(model, test_data)
    
    target_col <- as.character(formula[[2]])
    actual <- test_data[[target_col]]
    rmse_values[i] <- sqrt(mean((preds - actual)^2, na.rm = TRUE))
  }
  
  result <- list(
    k = k,
    rmse_values = rmse_values,
    mean_rmse = mean(rmse_values),
    sd_rmse = sd(rmse_values),
    method = method
  )
  class(result) <- "omni_ml"
  return(result)
}

#' Print Method for ML Results
#'
#' @param x omni_ml object.
#' @param ... Additional arguments (not used).
#' @examples
#' result <- ml_cv(continuous_target ~ feature1, data = omni_ml_data, k = 3)
#' print(result)
#' @export
print.omni_ml <- function(x, ...) {
  cat("\n=== Machine Learning Results ===\n")
  if (!is.null(x$type)) {
    cat("Type:", x$type, "\n")
  }
  if (!is.null(x$rmse)) {
    cat("RMSE:", round(x$rmse, 4), "\n")
  }
  if (!is.null(x$r_squared)) {
    cat("R-squared:", round(x$r_squared, 4), "\n")
  }
  if (!is.null(x$accuracy)) {
    cat("Accuracy:", round(x$accuracy, 4), "\n")
  }
  if (!is.null(x$mean_rmse)) {
    cat("CV Mean RMSE:", round(x$mean_rmse, 4), "(+/-", round(x$sd_rmse, 4), ")\n")
  }
  cat("\n")
}

