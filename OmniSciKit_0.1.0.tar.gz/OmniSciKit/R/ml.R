#' Machine Learning Module
#'
#' @description
#' Provides comprehensive machine learning tools for prediction,
#' classification, and feature selection.
#'
#' @name ml
#' @keywords internal
NULL

#' Train-Test Split
#' @param data Data frame.
#' @param target Target variable name.
#' @param test_prop Proportion for test set. Default 0.2.
#' @param seed Random seed.
#' @return List with train and test data.
#' @export
ml_train_test_split <- function(data, target, test_prop = 0.2, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  n <- nrow(data)
  test_idx <- sample(n, round(n * test_prop))
  list(
    train = data[-test_idx, ],
    test = data[test_idx, ],
    test_idx = test_idx
  )
}

#' Random Forest Model
#' @param formula Model formula.
#' @param data Training data.
#' @param ntree Number of trees. Default 500.
#' @param mtry Number of variables to try. Default sqrt(p).
#' @param ... Additional arguments.
#' @return Trained model object.
#' @export
ml_random_forest <- function(formula, data, ntree = 500, mtry = NULL, ...) {
  if (!requireNamespace("randomForest", quietly = TRUE)) {
    stop("randomForest package required. Install with: install_omni('machine_learning')")
  }
  if (is.null(mtry)) mtry <- floor(sqrt(ncol(data) - 1))
  fit <- randomForest::randomForest(formula, data = data, ntree = ntree, mtry = mtry, ...)
  structure(list(model = fit, formula = formula, method = "Random Forest"), class = c("omni_ml", "list"))
}

#' XGBoost Model
#' @param x Predictor matrix.
#' @param y Response vector.
#' @param params XGBoost parameters.
#' @param nrounds Number of rounds. Default 100.
#' @param ... Additional arguments.
#' @return Trained model object.
#' @export
ml_xgboost <- function(x, y, params = list(), nrounds = 100, ...) {
  if (!requireNamespace("xgboost", quietly = TRUE)) {
    stop("xgboost package required. Install with: install_omni('machine_learning')")
  }
  dtrain <- xgboost::xgb.DMatrix(data = as.matrix(x), label = y)
  default_params <- list(objective = ifelse(is.factor(y), "multi:softprob", "reg:squarederror"), eval_metric = "rmse")
  params <- modifyList(default_params, params)
  fit <- xgboost::xgb.train(params = params, data = dtrain, nrounds = nrounds, ...)
  structure(list(model = fit, x = x, y = y, method = "XGBoost"), class = c("omni_ml", "list"))
}

#' GLMNET Model (Lasso/Ridge/Elastic Net)
#' @param x Predictor matrix.
#' @param y Response vector.
#' @param alpha Elastic net mixing parameter. Default 1 (Lasso).
#' @param lambda Regularization parameter. Default NULL (cv).
#' @param family Response type: "gaussian", "binomial", "cox".
#' @param ... Additional arguments.
#' @return Trained model object.
#' @export
ml_glmnet <- function(x, y, alpha = 1, lambda = NULL, family = "gaussian", ...) {
  if (!requireNamespace("glmnet", quietly = TRUE)) {
    stop("glmnet package required. Install with: install_omni('machine_learning')")
  }
  if (is.null(lambda)) {
    cv_fit <- glmnet::cv.glmnet(as.matrix(x), y, alpha = alpha, family = family, ...)
    lambda <- cv_fit$lambda.min
  }
  fit <- glmnet::glmnet(as.matrix(x), y, alpha = alpha, lambda = lambda, family = family, ...)
  structure(list(model = fit, x = x, y = y, alpha = alpha, lambda = lambda, family = family, method = "GLMNET"), class = c("omni_ml", "list"))
}

#' Support Vector Machine
#' @param formula Model formula.
#' @param data Training data.
#' @param kernel Kernel type. Default "radial".
#' @param cost Cost parameter. Default 1.
#' @param ... Additional arguments.
#' @return Trained model object.
#' @export
ml_svm <- function(formula, data, kernel = "radial", cost = 1, ...) {
  if (!requireNamespace("e1071", quietly = TRUE)) {
    stop("e1071 package required. Install with: install_omni('machine_learning')")
  }
  fit <- e1071::svm(formula, data = data, kernel = kernel, cost = cost, probability = TRUE, ...)
  structure(list(model = fit, formula = formula, method = "SVM"), class = c("omni_ml", "list"))
}

#' K-Nearest Neighbors
#' @param formula Model formula.
#' @param data Training data.
#' @param k Number of neighbors. Default 5.
#' @param ... Additional arguments.
#' @return Trained model object.
#' @export
ml_knn <- function(formula, data, k = 5, ...) {
  if (!requireNamespace("caret", quietly = TRUE)) {
    stop("caret package required. Install with: install_omni('machine_learning')")
  }
  fit <- caret::knn3(formula, data = data, k = k, ...)
  structure(list(model = fit, formula = formula, k = k, method = "KNN"), class = c("omni_ml", "list"))
}

#' Naive Bayes
#' @param formula Model formula.
#' @param data Training data.
#' @param laplace Laplace smoothing. Default 0.
#' @param ... Additional arguments.
#' @return Trained model object.
#' @export
ml_naive_bayes <- function(formula, data, laplace = 0, ...) {
  if (!requireNamespace("e1071", quietly = TRUE)) {
    stop("e1071 package required. Install with: install_omni('machine_learning')")
  }
  fit <- e1071::naiveBayes(formula, data = data, laplace = laplace, ...)
  structure(list(model = fit, formula = formula, method = "Naive Bayes"), class = c("omni_ml", "list"))
}

#' Logistic Regression
#' @param formula Model formula.
#' @param data Training data.
#' @param family Binomial family. Default binomial().
#' @param ... Additional arguments.
#' @return Trained model object.
#' @export
ml_logistic <- function(formula, data, family = binomial(), ...) {
  fit <- glm(formula, data = data, family = family, ...)
  structure(list(model = fit, formula = formula, method = "Logistic Regression"), class = c("omni_ml", "list"))
}

#' Cox Proportional Hazards Model
#' @param formula Model formula.
#' @param data Training data.
#' @param ... Additional arguments.
#' @return Trained model object.
#' @export
ml_coxph <- function(formula, data, ...) {
  if (!requireNamespace("survival", quietly = TRUE)) {
    stop("survival package required. Install with: install_omni('machine_learning')")
  }
  fit <- survival::coxph(formula, data = data, ...)
  structure(list(model = fit, formula = formula, method = "Cox PH"), class = c("omni_ml", "list"))
}

#' Feature Importance
#' @param model Trained model object.
#' @param n_top Number of top features. Default 20.
#' @return Data frame with feature importance.
#' @export
ml_feature_importance <- function(model, n_top = 20) {
  if (inherits(model$model, "randomForest")) {
    imp <- randomForest::importance(model$model)
    df <- data.frame(Feature = rownames(imp), Importance = imp[, 1])
  } else if (inherits(model$model, "xgb.Booster")) {
    imp <- xgboost::xgb.importance(model = model$model)
    df <- data.frame(Feature = imp$Feature, Importance = imp$Gain)
  } else if (inherits(model$model, "glmnet")) {
    coefs <- as.matrix(coef(model$model))
    df <- data.frame(Feature = rownames(coefs)[-1], Importance = abs(coefs[-1, 1]))
  } else {
    stop("Feature importance not available for this model type")
  }
  df <- df[order(df$Importance, decreasing = TRUE), ]
  head(df, n_top)
}

#' Cross-Validation
#' @param formula Model formula.
#' @param data Data frame.
#' @param method Model method: "glm", "rf", "svm", etc.
#' @param k Number of folds. Default 5.
#' @param metric Evaluation metric.
#' @param ... Additional arguments.
#' @return CV results object.
#' @export
ml_cross_validate <- function(formula, data, method = "glm", k = 5, metric = NULL, ...) {
  if (!requireNamespace("caret", quietly = TRUE)) {
    stop("caret package required. Install with: install_omni('machine_learning')")
  }
  ctrl <- caret::trainControl(method = "cv", number = k)
  fit <- caret::train(formula, data = data, method = method, trControl = ctrl, metric = metric, ...)
  structure(list(model = fit, method = method, k = k), class = c("omni_ml_cv", "list"))
}

#' Grid Search for Hyperparameters
#' @param formula Model formula.
#' @param data Data frame.
#' @param method Model method.
#' @param tuneGrid Grid of parameters.
#' @param k CV folds. Default 5.
#' @param ... Additional arguments.
#' @return Grid search results.
#' @export
ml_grid_search <- function(formula, data, method, tuneGrid, k = 5, ...) {
  if (!requireNamespace("caret", quietly = TRUE)) {
    stop("caret package required. Install with: install_omni('machine_learning')")
  }
  ctrl <- caret::trainControl(method = "cv", number = k)
  fit <- caret::train(formula, data = data, method = method, trControl = ctrl, tuneGrid = tuneGrid, ...)
  structure(list(model = fit, method = method, bestTune = fit$bestTune), class = c("omni_ml_gs", "list"))
}

#' ROC Curve Analysis
#' @param actual Actual labels.
#' @param predicted Predicted probabilities.
#' @param positive Positive class label.
#' @return ROC curve object.
#' @export
ml_roc_curve <- function(actual, predicted, positive = NULL) {
  if (!requireNamespace("pROC", quietly = TRUE)) {
    stop("pROC package required. Install with: install_omni('machine_learning')")
  }
  roc_obj <- pROC::roc(actual, predicted, quiet = TRUE)
  structure(list(roc = roc_obj, auc = pROC::auc(roc_obj)), class = c("omni_ml_roc", "list"))
}

#' Confusion Matrix
#' @param actual Actual labels.
#' @param predicted Predicted labels.
#' @return Confusion matrix object.
#' @export
ml_confusion_matrix <- function(actual, predicted) {
  cm <- table(Predicted = predicted, Actual = actual)
  accuracy <- sum(diag(cm)) / sum(cm)
  structure(list(matrix = cm, accuracy = accuracy), class = c("omni_ml_cm", "list"))
}

#' Calibration Plot
#' @param actual Actual outcomes.
#' @param predicted Predicted probabilities.
#' @param n_bins Number of bins. Default 10.
#' @return Calibration data frame.
#' @export
ml_calibration <- function(actual, predicted, n_bins = 10) {
  bin_edges <- quantile(predicted, probs = seq(0, 1, length.out = n_bins + 1))
  bin_edges[1] <- 0; bin_edges[length(bin_edges)] <- 1
  bins <- cut(predicted, breaks = bin_edges, include.lowest = TRUE)
  
  cal_df <- data.frame(
    bin = levels(bins),
    predicted = tapply(predicted, bins, mean),
    observed = tapply(actual, bins, mean),
    n = table(bins)
  )
  cal_df
}

#' SHAP Values (simplified)
#' @param model Trained model.
#' @param newdata New data for explanation.
#' @param nsamples Number of samples. Default 100.
#' @return SHAP summary.
#' @export
ml_shap <- function(model, newdata, nsamples = 100) {
  if (!requireNamespace("xgboost", quietly = TRUE)) {
    stop("xgboost package required for SHAP")
  }
  shap_values <- xgboost::predict(model$model, as.matrix(newdata), predcontrib = TRUE)
  structure(list(shap = shap_values), class = c("omni_ml_shap", "list"))
}

#' Predict from Model
#' @param object Trained model object.
#' @param newdata New data for prediction.
#' @param type Prediction type: "response", "prob", "class".
#' @param ... Additional arguments.
#' @return Predictions.
#' @export
predict.ml_model <- function(object, newdata, type = "response", ...) {
  if (inherits(object$model, "randomForest")) {
    predict(object$model, newdata, type = type, ...)
  } else if (inherits(object$model, "xgb.Booster")) {
    xgboost::predict(object$model, as.matrix(newdata), ...)
  } else if (inherits(object$model, "glmnet")) {
    predict(object$model, as.matrix(newdata), type = type, s = object$lambda, ...)
  } else {
    predict(object$model, newdata, type = type, ...)
  }
}

#' Evaluate Model Performance
#' @param actual Actual values.
#' @param predicted Predicted values.
#' @param task Task type: "regression", "classification", "survival".
#' @return Performance metrics.
#' @export
ml_evaluate <- function(actual, predicted, task = "regression") {
  if (task == "regression") {
    metrics <- list(
      rmse = sqrt(mean((actual - predicted)^2)),
      mae = mean(abs(actual - predicted)),
      r2 = 1 - sum((actual - predicted)^2) / sum((actual - mean(actual))^2),
      mape = mean(abs((actual - predicted) / actual)) * 100
    )
  } else if (task == "classification") {
    cm <- ml_confusion_matrix(actual, predicted)
    metrics <- list(
      accuracy = cm$accuracy,
      sensitivity = cm$matrix[2, 2] / sum(cm$matrix[, 2]),
      specificity = cm$matrix[1, 1] / sum(cm$matrix[, 1]),
      precision = cm$matrix[2, 2] / sum(cm$matrix[2, ]),
      f1 = 2 * (cm$matrix[2, 2] / sum(cm$matrix[2, ])) * (cm$matrix[2, 2] / sum(cm$matrix[, 2])) / 
        ((cm$matrix[2, 2] / sum(cm$matrix[2, ])) + (cm$matrix[2, 2] / sum(cm$matrix[, 2])))
    )
  }
  structure(metrics, class = c("omni_ml_eval", "list"))
}

#' Tune Hyperparameters
#' @param formula Model formula.
#' @param data Data frame.
#' @param method Model method.
#' @param param_grid Parameter grid.
#' @param cv_folds CV folds. Default 5.
#' @return Tuned model.
#' @export
ml_tune_hyperparameters <- function(formula, data, method, param_grid, cv_folds = 5) {
  ml_grid_search(formula, data, method, tuneGrid = param_grid, k = cv_folds)
}

#' Feature Selection
#' @param x Predictor matrix.
#' @param y Response vector.
#' @param method Selection method: "correlation", "rfe", "lasso".
#' @param n_features Number of features to select. Default 10.
#' @return Selected features.
#' @export
ml_feature_selection <- function(x, y, method = "correlation", n_features = 10) {
  if (method == "correlation") {
    cors <- abs(apply(x, 2, function(col) cor(col, y, use = "complete.obs")))
    selected <- names(sort(cors, decreasing = TRUE))[1:n_features]
  } else if (method == "rfe") {
    if (!requireNamespace("caret", quietly = TRUE)) stop("caret required")
    ctrl <- caret::rfeControl(functions = caret::rfFuncs, method = "cv", number = 5)
    rfe_result <- caret::rfe(x, y, sizes = n_features, rfeControl = ctrl)
    selected <- predictors(rfe_result)
  } else if (method == "lasso") {
    fit <- ml_glmnet(x, y, alpha = 1)
    coefs <- as.matrix(coef(fit$model))
    selected <- rownames(coefs)[coefs[, 1] != 0][-1]
  }
  selected
}

#' PCA Preprocessing
#' @param x Data matrix.
#' @param n_components Number of components. Default 10.
#' @param scale Whether to scale. Default TRUE.
#' @return PCA object.
#' @export
ml_pca_preprocessing <- function(x, n_components = 10, scale = TRUE) {
  pca <- prcomp(x, scale. = scale, rank. = n_components)
  structure(list(pca = pca, n_components = n_components, scale = scale), class = c("omni_ml_pca", "list"))
}

#' Impute Missing Values
#' @param data Data frame.
#' @param method Imputation method: "mean", "median", "knn", "mice".
#' @return Imputed data frame.
#' @export
ml_impute_missing <- function(data, method = "mean") {
  if (method == "mean") {
    for (col in names(data)) {
      if (is.numeric(data[[col]])) {
        data[[col]][is.na(data[[col]])] <- mean(data[[col]], na.rm = TRUE)
      }
    }
  } else if (method == "median") {
    for (col in names(data)) {
      if (is.numeric(data[[col]])) {
        data[[col]][is.na(data[[col]])] <- median(data[[col]], na.rm = TRUE)
      }
    }
  } else if (method == "knn") {
    if (!requireNamespace("caret", quietly = TRUE)) stop("caret required")
    data <- caret::preProcess(data, method = c("knnImpute"))
  }
  data
}

#' Scale Features
#' @param x Data matrix.
#' @param method Scaling method: "standard", "minmax", "robust".
#' @return Scaled data.
#' @export
ml_scale_features <- function(x, method = "standard") {
  if (method == "standard") {
    scale(x)
  } else if (method == "minmax") {
    apply(x, 2, function(col) (col - min(col)) / (max(col) - min(col)))
  } else if (method == "robust") {
    apply(x, 2, function(col) (col - median(col)) / IQR(col))
  }
}

#' Model Comparison
#' @param models List of trained models.
#' @param test_data Test data frame.
#' @param target Target variable name.
#' @return Comparison data frame.
#' @export
ml_model_comparison <- function(models, test_data, target) {
  results <- lapply(names(models), function(name) {
    model <- models[[name]]
    pred <- predict(model, test_data)
    actual <- test_data[[target]]
    eval <- ml_evaluate(actual, pred, task = ifelse(is.factor(actual), "classification", "regression"))
    data.frame(Model = name, RMSE = eval$rmse, MAE = eval$mae, R2 = eval$r2)
  })
  do.call(rbind, results)
}
