#' Sample Size for T-Test
#'
#' Calculate required sample size for one-sample or two-sample t-test.
#'
#' @param delta Expected effect size (difference in means).
#' @param sd Standard deviation.
#' @param power Desired statistical power (default 0.8).
#' @param alpha Significance level (default 0.05).
#' @param type Test type: "two.sample" or "one.sample".
#' @return List with n per group, total n, and parameters.
#' @examples
#' # Example 1: Two-sample t-test for clinical trial
#' # Scenario: Compare new drug vs placebo for blood pressure reduction
#' # Expected difference: 10 mmHg, SD: 15 mmHg
#' result <- ss_ttest(delta = 10, sd = 15, power = 0.8)
#' print(result)
#' # Output shows: n per group and total n needed
#'
#' # Example 2: One-sample t-test
#' # Scenario: Compare mean BMI to population norm of 24
#' result <- ss_ttest(delta = 2, sd = 4, power = 0.9, type = "one.sample")
#' print(result)
#'
#' # Example 3: Using built-in clinical dataset
#' data(omni_clinical)
#' # Compare BMI between Drug_A and Placebo groups
#' drug_group <- omni_clinical$bmi[omni_clinical$treatment == "Drug_A"]
#' placebo_group <- omni_clinical$bmi[omni_clinical$treatment == "Placebo"]
#' pooled_sd <- sqrt((var(drug_group) + var(placebo_group)) / 2)
#' delta <- abs(mean(drug_group) - mean(placebo_group))
#' result <- ss_ttest(delta = delta, sd = pooled_sd, power = 0.8)
#' print(result)
#' cat("Recommended:", result$n_per_group, "per group,", result$total_n, "total\n")
#'
#' # Example 4: Visualize power curve
#' power_values <- seq(0.5, 0.95, by = 0.05)
#' sample_sizes <- sapply(power_values, function(p) {
#'   r <- ss_ttest(delta = 10, sd = 15, power = p)
#'   r$n_per_group
#' })
#' plot(power_values, sample_sizes, type = "b", pch = 19, col = "blue",
#'      xlab = "Power", ylab = "Sample Size per Group",
#'      main = "Power vs Sample Size (delta=10, sd=15)")
#' abline(h = 64, col = "red", lty = 2)
#' text(0.7, 70, "80% power = 64/group", col = "red")
#' @export
ss_ttest <- function(delta, sd, power = 0.8, alpha = 0.05, type = "two.sample") {
  if (!requireNamespace("pwr", quietly = TRUE)) {
    stop("Please install 'pwr' package: install.packages('pwr')")
  }
  d <- delta / sd
  if (type == "two.sample") {
    res <- pwr::pwr.t.test(d = d, power = power, sig.level = alpha, type = "two.sample")
    n_per_group <- ceiling(res$n)
    total_n <- n_per_group * 2
    result <- list(
      n_per_group = n_per_group,
      total_n = total_n,
      delta = delta,
      sd = sd,
      cohen_d = d,
      power = power,
      alpha = alpha,
      type = type,
      note = paste("Each group needs", n_per_group, "subjects; Total:", total_n)
    )
  } else {
    res <- pwr::pwr.t.test(d = d, power = power, sig.level = alpha, type = "one.sample")
    n <- ceiling(res$n)
    result <- list(
      n = n,
      delta = delta,
      sd = sd,
      cohen_d = d,
      power = power,
      alpha = alpha,
      type = type,
      note = paste("Need", n, "subjects total")
    )
  }
  class(result) <- "omni_sample_size"
  return(result)
}

#' Sample Size for ANOVA
#'
#' Calculate total sample size for one-way ANOVA.
#'
#' @param k Number of groups.
#' @param f Effect size (Cohen's f, small=0.1, medium=0.25, large=0.4).
#' @param power Desired power (default 0.8).
#' @param alpha Significance level (default 0.05).
#' @return List with total n, per group n, and parameters.
#' @examples
#' # Example 1: Compare 3 treatment arms
#' result <- ss_anova(k = 3, f = 0.25, power = 0.8)
#' print(result)
#' cat("Each group:", result$n_per_group, "| Total:", result$total_n, "\n")
#'
#' # Example 2: Compare 4 doses with large effect
#' result <- ss_anova(k = 4, f = 0.4, power = 0.9)
#' print(result)
#'
#' # Example 3: Using clinical data - determine groups
#' data(omni_clinical)
#' k <- length(unique(omni_clinical$treatment))
#' cat("Number of treatment groups:", k, "\n")
#' result <- ss_anova(k = k, f = 0.25, power = 0.8)
#' print(result)
#'
#' # Example 4: Power curve for different group numbers
#' k_values <- 2:6
#' sizes <- sapply(k_values, function(k) ss_anova(k = k, f = 0.25, power = 0.8)$total_n)
#' barplot(sizes, names.arg = k_values, col = "steelblue",
#'         xlab = "Number of Groups", ylab = "Total Sample Size",
#'         main = "ANOVA Sample Size vs Number of Groups")
#' @export
ss_anova <- function(k, f, power = 0.8, alpha = 0.05) {
  if (!requireNamespace("pwr", quietly = TRUE)) {
    stop("Please install 'pwr' package: install.packages('pwr')")
  }
  res <- pwr::pwr.anova.test(k = k, f = f, power = power, sig.level = alpha)
  n_per_group <- ceiling(res$n)
  total_n <- n_per_group * k
  result <- list(
    n_per_group = n_per_group,
    total_n = total_n,
    k = k,
    f = f,
    power = power,
    alpha = alpha,
    note = paste(k, "groups:", n_per_group, "per group; Total:", total_n)
  )
  class(result) <- "omni_sample_size"
  return(result)
}

#' Sample Size for Correlation
#'
#' Calculate sample size for correlation test.
#'
#' @param r Expected correlation coefficient.
#' @param power Desired power (default 0.8).
#' @param alpha Significance level (default 0.05).
#' @return List with n and parameters.
#' @examples
#' # Example 1: Detect medium correlation (r=0.5)
#' result <- ss_correlation(r = 0.5, power = 0.8)
#' print(result)
#' cat("Need", result$n, "subjects total\n")
#'
#' # Example 2: Detect small correlation (r=0.3)
#' result <- ss_correlation(r = 0.3, power = 0.8)
#' print(result)
#'
#' # Example 3: Using clinical data - check age-BMI correlation
#' data(omni_clinical)
#' r_observed <- cor(omni_clinical$age, omni_clinical$bmi)
#' cat("Observed correlation:", round(r_observed, 3), "\n")
#' result <- ss_correlation(r = abs(r_observed), power = 0.8)
#' print(result)
#'
#' # Example 4: Sample size for different correlations
#' r_values <- seq(0.1, 0.9, by = 0.1)
#' sizes <- sapply(r_values, function(r) ss_correlation(r = r, power = 0.8)$n)
#' plot(r_values, sizes, type = "b", pch = 19, col = "darkgreen",
#'      xlab = "Expected Correlation (r)", ylab = "Sample Size",
#'      main = "Sample Size vs Correlation Strength")
#' @export
ss_correlation <- function(r, power = 0.8, alpha = 0.05) {
  if (!requireNamespace("pwr", quietly = TRUE)) {
    stop("Please install 'pwr' package: install.packages('pwr')")
  }
  res <- pwr::pwr.r.test(r = r, power = power, sig.level = alpha)
  n <- ceiling(res$n)
  result <- list(
    n = n,
    r = r,
    power = power,
    alpha = alpha,
    note = paste("Need", n, "subjects total")
  )
  class(result) <- "omni_sample_size"
  return(result)
}

#' Sample Size for Proportion Test
#'
#' Calculate sample size for comparing two proportions.
#'
#' @param p1 Proportion in group 1.
#' @param p2 Proportion in group 2.
#' @param power Desired power (default 0.8).
#' @param alpha Significance level (default 0.05).
#' @return List with n per group, total n, and parameters.
#' @examples
#' # Example 1: Compare response rates (30% vs 50%)
#' result <- ss_proportion(p1 = 0.3, p2 = 0.5, power = 0.8)
#' print(result)
#' cat("Each group:", result$n_per_group, "| Total:", result$total_n, "\n")
#'
#' # Example 2: Compare mortality rates (5% vs 10%)
#' result <- ss_proportion(p1 = 0.05, p2 = 0.10, power = 0.8)
#' print(result)
#'
#' # Example 3: Using clinical data
#' data(omni_clinical)
#' resp_drug <- mean(omni_clinical$response == "Responder" & 
#'                   omni_clinical$treatment == "Drug_A")
#' resp_placebo <- mean(omni_clinical$response == "Responder" & 
#'                      omni_clinical$treatment == "Placebo")
#' cat("Drug response rate:", round(resp_drug, 3), "\n")
#' cat("Placebo response rate:", round(resp_placebo, 3), "\n")
#' result <- ss_proportion(p1 = resp_drug, p2 = resp_placebo, power = 0.8)
#' print(result)
#'
#' # Example 4: Power analysis for different effect sizes
#' p2_values <- seq(0.4, 0.8, by = 0.1)
#' sizes <- sapply(p2_values, function(p) {
#'   ss_proportion(p1 = 0.3, p2 = p, power = 0.8)$n_per_group
#' })
#' plot(p2_values, sizes, type = "b", pch = 19, col = "purple",
#'      xlab = "Proportion in Group 2", ylab = "Sample Size per Group",
#'      main = "Sample Size vs Effect Size (p1=0.3)")
#' @export
ss_proportion <- function(p1, p2, power = 0.8, alpha = 0.05) {
  if (!requireNamespace("pwr", quietly = TRUE)) {
    stop("Please install 'pwr' package: install.packages('pwr')")
  }
  h <- 2 * asin(sqrt(p1)) - 2 * asin(sqrt(p2))
  res <- pwr::pwr.2p.test(h = abs(h), power = power, sig.level = alpha)
  n_per_group <- ceiling(res$n)
  total_n <- n_per_group * 2
  result <- list(
    n_per_group = n_per_group,
    total_n = total_n,
    p1 = p1,
    p2 = p2,
    h = abs(h),
    power = power,
    alpha = alpha,
    note = paste("Each group needs", n_per_group, "subjects; Total:", total_n)
  )
  class(result) <- "omni_sample_size"
  return(result)
}

#' Sample Size for Linear Regression
#'
#' Calculate sample size for multiple linear regression.
#'
#' @param f2 Effect size (Cohen's f2, small=0.02, medium=0.15, large=0.35).
#' @param u Number of predictors.
#' @param power Desired power (default 0.8).
#' @param alpha Significance level (default 0.05).
#' @return List with n and parameters.
#' @examples
#' # Example 1: Medium effect, 5 predictors
#' result <- ss_regression(f2 = 0.15, u = 5, power = 0.8)
#' print(result)
#' cat("Need", result$n, "subjects for", result$u, "predictors\n")
#'
#' # Example 2: Small effect, 3 predictors
#' result <- ss_regression(f2 = 0.02, u = 3, power = 0.8)
#' print(result)
#'
#' # Example 3: Using clinical data
#' data(omni_clinical)
#' # Predict cholesterol from age, bmi, systolic_bp
#' result <- ss_regression(f2 = 0.15, u = 3, power = 0.8)
#' print(result)
#'
#' # Example 4: Sample size vs number of predictors
#' u_values <- 1:10
#' sizes <- sapply(u_values, function(u) ss_regression(f2 = 0.15, u = u, power = 0.8)$n)
#' plot(u_values, sizes, type = "b", pch = 19, col = "orange",
#'      xlab = "Number of Predictors", ylab = "Sample Size",
#'      main = "Regression Sample Size vs Predictors (f2=0.15)")
#' @export
ss_regression <- function(f2, u, power = 0.8, alpha = 0.05) {
  if (!requireNamespace("pwr", quietly = TRUE)) {
    stop("Please install 'pwr' package: install.packages('pwr')")
  }
  res <- pwr::pwr.f2.test(u = u, f2 = f2, power = power, sig.level = alpha)
  n <- ceiling(res$v + u + 1)
  result <- list(
    n = n,
    u = u,
    f2 = f2,
    power = power,
    alpha = alpha,
    note = paste("Need", n, "subjects total (", u, "predictors)")
  )
  class(result) <- "omni_sample_size"
  return(result)
}

#' Sample Size for Survival Analysis
#'
#' Calculate sample size for log-rank test.
#'
#' @param hr Hazard ratio.
#' @param p Proportion in group 1.
#' @param power Desired power (default 0.8).
#' @param alpha Significance level (default 0.05).
#' @return List with total events needed and total n.
#' @examples
#' # Example 1: HR = 0.7 (30% risk reduction)
#' result <- ss_survival(hr = 0.7, p = 0.5, power = 0.8)
#' print(result)
#' cat("Need", result$total_events, "total events\n")
#'
#' # Example 2: HR = 0.5 (50% risk reduction)
#' result <- ss_survival(hr = 0.5, p = 0.5, power = 0.8)
#' print(result)
#'
#' # Example 3: Using clinical data
#' data(omni_clinical)
#' result <- ss_survival(hr = 0.7, p = 0.5, power = 0.8)
#' print(result)
#'
#' # Example 4: Events needed for different HRs
#' hr_values <- seq(0.5, 0.9, by = 0.05)
#' events <- sapply(hr_values, function(hr) ss_survival(hr = hr, p = 0.5, power = 0.8)$total_events)
#' plot(hr_values, events, type = "b", pch = 19, col = "red",
#'      xlab = "Hazard Ratio", ylab = "Total Events Needed",
#'      main = "Events Needed vs Hazard Ratio")
#' @export
ss_survival <- function(hr, p = 0.5, power = 0.8, alpha = 0.05) {
  if (!requireNamespace("pwr", quietly = TRUE)) {
    stop("Please install 'pwr' package: install.packages('pwr')")
  }
  za <- qnorm(1 - alpha/2)
  zb <- qnorm(power)
  events <- ceiling((za + zb)^2 / (p * (1 - p) * (log(hr))^2))
  result <- list(
    total_events = events,
    hr = hr,
    p = p,
    power = power,
    alpha = alpha,
    note = paste("Need", events, "total events across both groups")
  )
  class(result) <- "omni_sample_size"
  return(result)
}

#' Sample Size for Logistic Regression
#'
#' Calculate sample size for logistic regression.
#'
#' @param p0 Baseline probability.
#' @param or Odds ratio.
#' @param power Desired power (default 0.8).
#' @param alpha Significance level (default 0.05).
#' @return List with n and parameters.
#' @examples
#' # Example 1: Common scenario (p0=0.3, OR=1.5)
#' result <- ss_logistic(p0 = 0.3, or = 1.5, power = 0.8)
#' print(result)
#' cat("Need", result$n, "subjects total\n")
#'
#' # Example 2: Rare outcome (p0=0.05, OR=2.0)
#' result <- ss_logistic(p0 = 0.05, or = 2.0, power = 0.8)
#' print(result)
#'
#' # Example 3: Using clinical data
#' data(omni_clinical)
#' p0 <- mean(omni_clinical$response == "Responder")
#' cat("Baseline response rate:", round(p0, 3), "\n")
#' result <- ss_logistic(p0 = p0, or = 1.5, power = 0.8)
#' print(result)
#'
#' # Example 4: Sample size for different ORs
#' or_values <- seq(1.2, 3.0, by = 0.2)
#' sizes <- sapply(or_values, function(or) ss_logistic(p0 = 0.3, or = or, power = 0.8)$n)
#' plot(or_values, sizes, type = "b", pch = 19, col = "brown",
#'      xlab = "Odds Ratio", ylab = "Sample Size",
#'      main = "Sample Size vs Odds Ratio (p0=0.3)")
#' @export
ss_logistic <- function(p0, or, power = 0.8, alpha = 0.05) {
  p1 <- (or * p0) / (1 - p0 + or * p0)
  p_bar <- (p0 + p1) / 2
  za <- qnorm(1 - alpha/2)
  zb <- qnorm(power)
  n <- ceiling((za * sqrt(2 * p_bar * (1 - p_bar)) + 
                  zb * sqrt(p0 * (1 - p0) + p1 * (1 - p1)))^2 / (p1 - p0)^2)
  result <- list(
    n = n,
    p0 = p0,
    p1 = p1,
    or = or,
    power = power,
    alpha = alpha,
    note = paste("Need", n, "subjects total")
  )
  class(result) <- "omni_sample_size"
  return(result)
}

#' Print Method for Sample Size Results
#'
#' @param x omni_sample_size object.
#' @param ... Additional arguments (not used).
#' @examples
#' result <- ss_ttest(delta = 10, sd = 15, power = 0.8)
#' print(result)
#' @export
print.omni_sample_size <- function(x, ...) {
  cat("\n=== Sample Size Calculation ===\n")
  cat("Power:", x$power, "| Alpha:", x$alpha, "\n")
  if (!is.null(x$n_per_group)) {
    cat("Per group:", x$n_per_group, "| Total:", x$total_n, "\n")
  } else if (!is.null(x$total_events)) {
    cat("Total events needed:", x$total_events, "\n")
  } else {
    cat("Total n:", x$n, "\n")
  }
  cat("Note:", x$note, "\n\n")
}

