#' Utility Functions
#'
#' @description
#' Provides utility functions for data manipulation and visualization.
#'
#' @name utils
#' @keywords internal
NULL

#' Save Plot
#' @param plot ggplot object.
#' @param file Output file.
#' @param width Width in inches.
#' @param height Height in inches.
#' @param dpi DPI.
#' @param ... Additional arguments.
#' @return File path.
#' @export
omni_save_plot <- function(plot, file, width = 8, height = 6, dpi = 300, ...) {
  ggplot2::ggsave(file, plot, width = width, height = height, dpi = dpi, ...)
  invisible(file)
}

#' Save Table
#' @param table Table object.
#' @param file Output file.
#' @param format Format: "csv", "xlsx", "html".
#' @param ... Additional arguments.
#' @return File path.
#' @export
omni_save_table <- function(table, file, format = "csv", ...) {
  switch(format,
         csv = write.csv(table, file, ...),
         html = if (requireNamespace("knitr", quietly = TRUE)) {
           writeLines(knitr::kable(table, format = "html"), file)
         })
  invisible(file)
}

#' Save Data
#' @param data Data object.
#' @param file Output file.
#' @param format Format: "rds", "csv", "xlsx".
#' @param ... Additional arguments.
#' @return File path.
#' @export
omni_save_data <- function(data, file, format = "rds", ...) {
  switch(format,
         rds = saveRDS(data, file, ...),
         csv = write.csv(data, file, ...),
         xlsx = if (requireNamespace("writexl", quietly = TRUE)) {
           writexl::write_xlsx(data, file)
         })
  invisible(file)
}

#' Load Data
#' @param file Input file.
#' @param format File format.
#' @param ... Additional arguments.
#' @return Loaded data.
#' @export
omni_load_data <- function(file, format = NULL, ...) {
  if (is.null(format)) {
    format <- tools::file_ext(file)
  }
  switch(format,
         rds = readRDS(file, ...),
         csv = read.csv(file, ...),
         xlsx = if (requireNamespace("readxl", quietly = TRUE)) readxl::read_excel(file, ...) else read.csv(file, ...),
         readRDS(file, ...))
}

#' Check Data Quality
#' @param data Data frame.
#' @return Quality report.
#' @export
omni_check_data <- function(data) {
  list(
    n_rows = nrow(data),
    n_cols = ncol(data),
    missing = colSums(is.na(data)),
    missing_pct = colMeans(is.na(data)) * 100,
    types = sapply(data, class),
    duplicates = sum(duplicated(data))
  )
}

#' Clean Data
#' @param data Data frame.
#' @param remove_duplicates Remove duplicates. Default TRUE.
#' @param handle_missing Missing value handling: "remove", "mean", "median".
#' @return Cleaned data.
#' @export
omni_clean_data <- function(data, remove_duplicates = TRUE, handle_missing = "remove") {
  if (remove_duplicates) {
    data <- data[!duplicated(data), ]
  }
  
  if (handle_missing == "remove") {
    data <- na.omit(data)
  } else if (handle_missing == "mean") {
    for (col in names(data)) {
      if (is.numeric(data[[col]])) {
        data[[col]][is.na(data[[col]])] <- mean(data[[col]], na.rm = TRUE)
      }
    }
  } else if (handle_missing == "median") {
    for (col in names(data)) {
      if (is.numeric(data[[col]])) {
        data[[col]][is.na(data[[col]])] <- median(data[[col]], na.rm = TRUE)
      }
    }
  }
  
  data
}

#' Transform Data
#' @param data Data frame.
#' @param transform Transformation: "log", "sqrt", "scale", "normalize".
#' @param cols Columns to transform.
#' @return Transformed data.
#' @export
omni_transform_data <- function(data, transform = "log", cols = NULL) {
  if (is.null(cols)) {
    cols <- names(data)[sapply(data, is.numeric)]
  }
  
  for (col in cols) {
    if (transform == "log") {
      data[[col]] <- log(data[[col]] + 1)
    } else if (transform == "sqrt") {
      data[[col]] <- sqrt(data[[col]])
    } else if (transform == "scale") {
      data[[col]] <- scale(data[[col]])
    } else if (transform == "normalize") {
      data[[col]] <- (data[[col]] - min(data[[col]])) / (max(data[[col]]) - min(data[[col]]))
    }
  }
  
  data
}

#' Merge Data
#' @param x First data frame.
#' @param y Second data frame.
#' @param by Merge columns.
#' @param type Merge type: "left", "right", "inner", "full".
#' @return Merged data.
#' @export
omni_merge_data <- function(x, y, by = NULL, type = "left") {
  switch(type,
         left = merge(x, y, by = by, all.x = TRUE),
         right = merge(x, y, by = by, all.y = TRUE),
         inner = merge(x, y, by = by),
         full = merge(x, y, by = by, all = TRUE))
}

#' Subset Data
#' @param data Data frame.
#' @param condition Logical condition.
#' @param select Columns to select.
#' @return Subsetted data.
#' @export
omni_subset_data <- function(data, condition = NULL, select = NULL) {
  if (!is.null(condition)) {
    data <- data[condition, ]
  }
  if (!is.null(select)) {
    data <- data[, select, drop = FALSE]
  }
  data
}

#' Summarize Data
#' @param data Data frame.
#' @param by Grouping variables.
#' @param ... Summary functions.
#' @return Summary data.
#' @export
omni_summarize_data <- function(data, by = NULL, ...) {
  if (is.null(by)) {
    summary(data, ...)
  } else {
    aggregate(data, by = list(data[[by]]), ...)
  }
}

#' Visualize Data
#' @param data Data frame.
#' @param type Plot type: "histogram", "boxplot", "scatter", "correlation".
#' @param x X variable.
#' @param y Y variable.
#' @param ... Additional arguments.
#' @return ggplot object.
#' @export
omni_visualize_data <- function(data, type = "histogram", x = NULL, y = NULL, ...) {
  switch(type,
         histogram = {
           ggplot2::ggplot(data, ggplot2::aes_string(x = x)) +
             ggplot2::geom_histogram(...) +
             ggplot2::theme_minimal()
         },
         boxplot = {
           ggplot2::ggplot(data, ggplot2::aes_string(x = x, y = y)) +
             ggplot2::geom_boxplot(...) +
             ggplot2::theme_minimal()
         },
         scatter = {
           ggplot2::ggplot(data, ggplot2::aes_string(x = x, y = y)) +
             ggplot2::geom_point(...) +
             ggplot2::theme_minimal()
         },
         correlation = {
           if (requireNamespace("corrplot", quietly = TRUE)) {
             M <- cor(data[, sapply(data, is.numeric)], use = "complete.obs")
             corrplot::corrplot(M, ...)
           }
         })
}
