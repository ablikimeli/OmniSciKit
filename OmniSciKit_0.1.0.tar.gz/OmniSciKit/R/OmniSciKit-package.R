#' OmniSciKit: A Comprehensive Toolkit for Scientific Research
#'
#' @description
#' OmniSciKit provides a unified framework for multi-omics analysis,
#' Mendelian randomization, machine learning, epidemiological modeling,
#' statistical analysis, and sample size calculation.
#'
#' @details
#' The package includes six main modules:
#' \itemize{
#'   \item Bioinformatics: Differential expression, pathway enrichment
#'   \item Mendelian Randomization: Causal inference methods
#'   \item Machine Learning: Prediction and classification models
#'   \item Epidemiology: Infectious disease modeling
#'   \item Statistics: Comprehensive statistical tests
#'   \item Sample Size: Power and sample size calculations
#' }
#'
#' @docType _PACKAGE
#' @name OmniSciKit-package
#' @aliases OmniSciKit
#' @keywords package
NULL

#' @importFrom ggplot2 ggplot aes geom_point geom_line geom_bar geom_boxplot
#' @importFrom ggplot2 geom_histogram geom_density geom_ribbon geom_errorbar
#' @importFrom ggplot2 geom_text geom_vline geom_hline facet_wrap facet_grid
#' @importFrom ggplot2 theme theme_minimal labs xlab ylab ggtitle
#' @importFrom ggplot2 scale_color_manual scale_fill_manual
#' @importFrom ggplot2 scale_x_continuous scale_y_continuous coord_flip
#' @importFrom ggplot2 element_text element_rect element_line element_blank
#' @importFrom dplyr filter select mutate arrange summarise group_by
#' @importFrom dplyr left_join right_join inner_join full_join bind_rows
#' @importFrom dplyr bind_cols rename distinct slice pull count tally
#' @importFrom tidyr pivot_longer pivot_wider separate unite drop_na
#' @importFrom tibble tibble as_tibble
#' @importFrom rlang enquo quo_name sym
#' @importFrom cli cli_alert_success cli_alert_info cli_alert_warning
#' @importFrom cli cli_alert_danger cli_h1 cli_h2 cli_text cli_rule
#' @importFrom stats t.test wilcox.test aov kruskal.test chisq.test
#' @importFrom stats fisher.test mcnemar.test cor.test lm glm coef confint
#' @importFrom stats predict residuals fitted rstandard rstudent anova
#' @importFrom stats drop1 add1 step update formula model.matrix model.frame
#' @importFrom stats na.omit complete.cases aggregate quantile median
#' @importFrom stats sd var cor cov density ecdf rnorm runif rbinom rpois
#' @importFrom utils install.packages installed.packages packageVersion
#' @importFrom utils citation read.csv write.csv data
#' @importFrom graphics plot lines points abline text legend axis
#' @importFrom grDevices rgb hsv col2rgb colorRamp colorRampPalette
#' @importFrom grDevices pdf png jpeg tiff bmp svg dev.off
#' @importFrom methods new as is slot
NULL
