#' OmniSciKit: Multi-Domain Integrated Research Toolbox
#'
#' @description
#' A unified R meta-package that integrates bioinformatics, Mendelian randomization,
#' machine learning, infectious disease modeling, medical statistics, and sample size
#' calculation into a consistent interface.
#'
#' @section Core Features:
#' \itemize{
#'   \item \strong{Environment Management}: Intelligent dependency checking and installation
#'   \item \strong{Omics Analysis}: RNA-seq, DE analysis, enrichment, pathway analysis
#'   \item \strong{Mendelian Randomization}: Two-sample MR, sensitivity analyses
#'   \item \strong{Machine Learning}: Classification, regression, clustering, deep learning
#'   \item \strong{Epidemiology}: SIR/SEIR models, outbreak detection, intervention analysis
#'   \item \strong{Medical Statistics}: Comprehensive statistical testing and reporting
#'   \item \strong{Sample Size}: Power analysis for various study designs
#' }
#'
#' @section Dependency Management:
#' OmniSciKit uses a soft dependency approach. Core functions work with base R,
#' while advanced features require additional packages. Use \code{check_deps()} to
#' verify and load required packages:
#'
#' \preformatted{
#' check_deps(c("ggplot2", "dplyr", "DESeq2"))
#' }
#'
#' @section Getting Started:
#' \preformatted{
#' library(OmniSciKit)
#'
#' # Check dependencies
#' check_deps(c("ggplot2", "dplyr"))
#'
#' # Sample size calculation
#' ss_ttest(delta = 0.5, sd = 1, power = 0.8)
#'
#' # Statistical analysis
#' stats_ttest(rnorm(20), rnorm(20, 0.5))
#' }
#'
#' @keywords internal
#' @importFrom grDevices heat.colors
#' @importFrom stats TukeyHSD aggregate aov binomial chisq.test coef cor.test
#'   fisher.test fitted glm kruskal.test ks.test lm median p.adjust pchisq
#'   pnorm prcomp predict qnorm residuals sd setNames shapiro.test t.test
#'   var.test wilcox.test
#' @importFrom utils install.packages
#'
"_PACKAGE"
