#' Basic Reproduction Number (R0)
#'
#' Estimate R0 from epidemic curve using exponential growth method.
#'
#' @param cases Vector of daily new cases.
#' @param dates Vector of dates or days.
#' @param generation_time Generation interval (default 5 days).
#' @return List with R0 estimate and confidence interval.
#' @examples
#' # Example 1: Using built-in epidemic data
#' data(omni_epidemic)
#' result <- epi_r0(omni_epidemic$new_cases[1:30], 1:30)
#' print(result)
#' cat("R0:", round(result$r0, 2), "-", result$note, "\n")
#'
#' # Example 2: Simulated outbreak
#' set.seed(123)
#' days <- 1:30
#' cases <- round(10 * exp(0.15 * days) + rnorm(30, 0, 20))
#' cases[cases < 0] <- 0
#' result <- epi_r0(cases, days, generation_time = 4)
#' print(result)
#'
#' # Example 3: Visualization
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   df <- data.frame(day = days, cases = cases)
#'   p <- ggplot2::ggplot(df, ggplot2::aes(x = day, y = cases)) +
#'     ggplot2::geom_line(color = "red", size = 1) +
#'     ggplot2::geom_point(color = "darkred") +
#'     ggplot2::labs(title = "Epidemic Curve", y = "Daily Cases")
#'   print(p)
#' }
#' @export
epi_r0 <- function(cases, dates, generation_time = 5) {
  valid <- cases > 0
  log_cases <- log(cases[valid])
  t <- dates[valid]
  
  fit <- lm(log_cases ~ t)
  r <- coef(fit)[2]
  r0 <- 1 + r * generation_time
  se <- summary(fit)$coefficients[2, 2]
  r0_lower <- 1 + (r - 1.96 * se) * generation_time
  r0_upper <- 1 + (r + 1.96 * se) * generation_time
  
  result <- list(
    r0 = r0,
    r0_ci = c(r0_lower, r0_upper),
    growth_rate = r,
    generation_time = generation_time,
    note = ifelse(r0 > 1, 
                  "R0 > 1: Epidemic growing",
                  "R0 <= 1: Epidemic controlled"),
    data = data.frame(day = dates, cases = cases)
  )
  class(result) <- "omni_epi"
  return(result)
}

#' SIR Model
#'
#' Simulate Susceptible-Infected-Recovered model.
#'
#' @param N Total population.
#' @param I0 Initial infected.
#' @param beta Transmission rate.
#' @param gamma Recovery rate.
#' @param days Simulation days.
#' @return Data frame with S, I, R compartments over time.
#' @examples
#' # Example 1: Basic simulation
#' result <- epi_sir(N = 1000, I0 = 10, beta = 0.3, gamma = 0.1, days = 60)
#' head(result)
#' cat("Peak infected:", max(result$I), "on day", which.max(result$I) - 1, "\n")
#'
#' # Example 2: Visualization
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   p <- ggplot2::ggplot(result, ggplot2::aes(x = day)) +
#'     ggplot2::geom_line(ggplot2::aes(y = S, color = "Susceptible"), size = 1) +
#'     ggplot2::geom_line(ggplot2::aes(y = I, color = "Infected"), size = 1) +
#'     ggplot2::geom_line(ggplot2::aes(y = R, color = "Recovered"), size = 1) +
#'     ggplot2::labs(title = "SIR Model", y = "Number of Individuals") +
#'     ggplot2::scale_color_manual(values = c("blue", "red", "green"))
#'   print(p)
#' }
#'
#' # Example 3: Compare different beta values
#' result_high <- epi_sir(N = 1000, I0 = 10, beta = 0.5, gamma = 0.1, days = 60)
#' result_low <- epi_sir(N = 1000, I0 = 10, beta = 0.2, gamma = 0.1, days = 60)
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   df <- rbind(
#'     cbind(result_high, scenario = "High transmission"),
#'     cbind(result_low, scenario = "Low transmission")
#'   )
#'   p <- ggplot2::ggplot(df, ggplot2::aes(x = day, y = I, color = scenario)) +
#'     ggplot2::geom_line(size = 1) +
#'     ggplot2::labs(title = "Compare Transmission Scenarios")
#'   print(p)
#' }
#' @export
epi_sir <- function(N, I0, beta, gamma, days) {
  S <- numeric(days + 1)
  I <- numeric(days + 1)
  R <- numeric(days + 1)
  
  S[1] <- N - I0
  I[1] <- I0
  R[1] <- 0
  
  for (t in 1:days) {
    dS <- -beta * S[t] * I[t] / N
    dI <- beta * S[t] * I[t] / N - gamma * I[t]
    dR <- gamma * I[t]
    
    S[t + 1] <- S[t] + dS
    I[t + 1] <- I[t] + dI
    R[t + 1] <- R[t] + dR
  }
  
  result <- data.frame(
    day = 0:days,
    S = S,
    I = I,
    R = R
  )
  return(result)
}

#' Attack Rate
#'
#' Calculate attack rate from outbreak data.
#'
#' @param cases Number of cases.
#' @param population Population at risk.
#' @return List with attack rate and confidence interval.
#' @examples
#' # Example 1: Basic usage
#' result <- epi_attack_rate(50, 1000)
#' print(result)
#'
#' # Example 2: Using epidemic data
#' data(omni_epidemic)
#' total_cases <- sum(omni_epidemic$new_cases)
#' pop <- omni_epidemic$population[1]
#' result <- epi_attack_rate(total_cases, pop)
#' print(result)
#'
#' # Example 3: Visualization
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   df <- data.frame(
#'     metric = c("Cases", "Non-cases"),
#'     count = c(total_cases, pop - total_cases)
#'   )
#'   p <- ggplot2::ggplot(df, ggplot2::aes(x = "", y = count, fill = metric)) +
#'     ggplot2::geom_bar(stat = "identity", width = 1) +
#'     ggplot2::coord_polar("y") +
#'     ggplot2::labs(title = "Attack Rate")
#'   print(p)
#' }
#' @export
epi_attack_rate <- function(cases, population) {
  ar <- cases / population
  se <- sqrt(ar * (1 - ar) / population)
  ci_lower <- max(0, ar - 1.96 * se)
  ci_upper <- min(1, ar + 1.96 * se)
  
  result <- list(
    attack_rate = ar,
    attack_rate_percent = round(ar * 100, 2),
    ci_95 = c(ci_lower, ci_upper),
    cases = cases,
    population = population,
    note = paste0("Attack rate: ", round(ar * 100, 2), "% (95% CI: ",
                  round(ci_lower * 100, 2), "-", round(ci_upper * 100, 2), "%)")
  )
  class(result) <- "omni_epi"
  return(result)
}

#' Case Fatality Rate
#'
#' Calculate case fatality rate.
#'
#' @param deaths Number of deaths.
#' @param cases Number of cases.
#' @return List with CFR and confidence interval.
#' @examples
#' # Example 1: Basic usage
#' result <- epi_cfr(10, 100)
#' print(result)
#'
#' # Example 2: Using epidemic data
#' data(omni_epidemic)
#' total_deaths <- sum(omni_epidemic$new_deaths)
#' total_cases <- sum(omni_epidemic$new_cases)
#' result <- epi_cfr(total_deaths, total_cases)
#' print(result)
#' @export
epi_cfr <- function(deaths, cases) {
  cfr <- deaths / cases
  se <- sqrt(cfr * (1 - cfr) / cases)
  ci_lower <- max(0, cfr - 1.96 * se)
  ci_upper <- min(1, cfr + 1.96 * se)
  
  result <- list(
    cfr = cfr,
    cfr_percent = round(cfr * 100, 2),
    ci_95 = c(ci_lower, ci_upper),
    deaths = deaths,
    cases = cases,
    note = paste0("CFR: ", round(cfr * 100, 2), "% (95% CI: ",
                  round(ci_lower * 100, 2), "-", round(ci_upper * 100, 2), "%)")
  )
  class(result) <- "omni_epi"
  return(result)
}

#' Prevalence
#'
#' Calculate prevalence with confidence interval.
#'
#' @param cases Number of cases.
#' @param population Population.
#' @return List with prevalence and CI.
#' @examples
#' # Example 1: Basic usage
#' result <- epi_prevalence(50, 1000)
#' print(result)
#'
#' # Example 2: Using clinical data
#' data(omni_clinical)
#' obese <- sum(omni_clinical$bmi >= 30)
#' result <- epi_prevalence(obese, nrow(omni_clinical))
#' print(result)
#' @export
epi_prevalence <- function(cases, population) {
  prev <- cases / population
  se <- sqrt(prev * (1 - prev) / population)
  ci_lower <- max(0, prev - 1.96 * se)
  ci_upper <- min(1, prev + 1.96 * se)
  
  result <- list(
    prevalence = prev,
    prevalence_percent = round(prev * 100, 2),
    ci_95 = c(ci_lower, ci_upper),
    cases = cases,
    population = population,
    note = paste0("Prevalence: ", round(prev * 100, 2), "% (95% CI: ",
                  round(ci_lower * 100, 2), "-", round(ci_upper * 100, 2), "%)")
  )
  class(result) <- "omni_epi"
  return(result)
}

#' Incidence Rate
#'
#' Calculate incidence rate.
#'
#' @param cases Number of new cases.
#' @param person_time Person-time at risk.
#' @param unit Time unit multiplier (default 1000).
#' @return List with incidence rate and CI.
#' @examples
#' # Example 1: Basic usage
#' result <- epi_incidence(20, 5000)
#' print(result)
#'
#' # Example 2: Using epidemic data
#' data(omni_epidemic)
#' total_cases <- sum(omni_epidemic$new_cases)
#' pop <- omni_epidemic$population[1]
#' days <- max(omni_epidemic$day)
#' person_days <- pop * days
#' result <- epi_incidence(total_cases, person_days, unit = 10000)
#' print(result)
#' @export
epi_incidence <- function(cases, person_time, unit = 1000) {
  rate <- cases / person_time * unit
  se <- sqrt(cases) / person_time * unit
  ci_lower <- max(0, rate - 1.96 * se)
  ci_upper <- rate + 1.96 * se
  
  result <- list(
    incidence_rate = rate,
    ci_95 = c(ci_lower, ci_upper),
    cases = cases,
    person_time = person_time,
    unit = unit,
    note = paste0("Incidence: ", round(rate, 2), " per ", unit, " person-time")
  )
  class(result) <- "omni_epi"
  return(result)
}

#' SEIR Model
#'
#' Simulate SEIR model with exposed compartment.
#'
#' @param N Total population.
#' @param I0 Initial infected.
#' @param E0 Initial exposed.
#' @param beta Transmission rate.
#' @param sigma Progression rate (1/incubation period).
#' @param gamma Recovery rate.
#' @param days Simulation days.
#' @return Data frame with S, E, I, R compartments.
#' @examples
#' # Example 1: Basic simulation
#' result <- epi_seir(N = 1000, I0 = 5, E0 = 10, beta = 0.5, 
#'                    sigma = 0.2, gamma = 0.1, days = 60)
#' head(result)
#'
#' # Example 2: Visualization
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   p <- ggplot2::ggplot(result, ggplot2::aes(x = day)) +
#'     ggplot2::geom_line(ggplot2::aes(y = S, color = "S"), size = 1) +
#'     ggplot2::geom_line(ggplot2::aes(y = E, color = "E"), size = 1) +
#'     ggplot2::geom_line(ggplot2::aes(y = I, color = "I"), size = 1) +
#'     ggplot2::geom_line(ggplot2::aes(y = R, color = "R"), size = 1) +
#'     ggplot2::labs(title = "SEIR Model", y = "Count") +
#'     ggplot2::scale_color_manual(values = c("blue", "orange", "red", "green"))
#'   print(p)
#' }
#' @export
epi_seir <- function(N, I0, E0, beta, sigma, gamma, days) {
  S <- numeric(days + 1)
  E <- numeric(days + 1)
  I <- numeric(days + 1)
  R <- numeric(days + 1)
  
  S[1] <- N - I0 - E0
  E[1] <- E0
  I[1] <- I0
  R[1] <- 0
  
  for (t in 1:days) {
    dS <- -beta * S[t] * I[t] / N
    dE <- beta * S[t] * I[t] / N - sigma * E[t]
    dI <- sigma * E[t] - gamma * I[t]
    dR <- gamma * I[t]
    
    S[t + 1] <- S[t] + dS
    E[t + 1] <- E[t] + dE
    I[t + 1] <- I[t] + dI
    R[t + 1] <- R[t] + dR
  }
  
  result <- data.frame(
    day = 0:days,
    S = S,
    E = E,
    I = I,
    R = R
  )
  return(result)
}

#' Print Method for Epidemiological Results
#'
#' @param x omni_epi object.
#' @param ... Additional arguments (not used).
#' @examples
#' result <- epi_r0(c(10, 15, 20, 25, 30), 1:5)
#' print(result)
#' @export
print.omni_epi <- function(x, ...) {
  cat("\n=== Epidemiological Analysis ===\n")
  if (!is.null(x$r0)) {
    cat("R0:", round(x$r0, 2), "(95% CI:", round(x$r0_ci[1], 2), "-", round(x$r0_ci[2], 2), ")\n")
  }
  if (!is.null(x$attack_rate_percent)) {
    cat("Attack Rate:", x$attack_rate_percent, "%\n")
  }
  if (!is.null(x$cfr_percent)) {
    cat("CFR:", x$cfr_percent, "%\n")
  }
  if (!is.null(x$prevalence_percent)) {
    cat("Prevalence:", x$prevalence_percent, "%\n")
  }
  if (!is.null(x$incidence_rate)) {
    cat("Incidence:", round(x$incidence_rate, 2), "per", x$unit, "\n")
  }
  if (!is.null(x$note)) {
    cat("Note:", x$note, "\n")
  }
  cat("\n")
}

