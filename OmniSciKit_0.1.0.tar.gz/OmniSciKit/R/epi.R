#' Epidemiology Module
#'
#' @description
#' Provides tools for infectious disease modeling including
#' compartmental models, R0 estimation, and intervention analysis.
#'
#' @name epi
#' @keywords internal
NULL

#' SIR Model
#' @param beta Transmission rate.
#' @param gamma Recovery rate.
#' @param N Total population.
#' @param I0 Initial infected. Default 1.
#' @param R0 Initial recovered. Default 0.
#' @param t_max Maximum time. Default 100.
#' @param dt Time step. Default 0.1.
#' @return SIR model results.
#' @export
epi_sir <- function(beta, gamma, N, I0 = 1, R0 = 0, t_max = 100, dt = 0.1) {
  times <- seq(0, t_max, by = dt)
  S <- numeric(length(times)); I <- numeric(length(times)); R <- numeric(length(times))
  S[1] <- N - I0 - R0; I[1] <- I0; R[1] <- R0
  
  for (t in 2:length(times)) {
    dS <- -beta * S[t-1] * I[t-1] / N
    dI <- beta * S[t-1] * I[t-1] / N - gamma * I[t-1]
    dR <- gamma * I[t-1]
    S[t] <- S[t-1] + dS * dt
    I[t] <- I[t-1] + dI * dt
    R[t] <- R[t-1] + dR * dt
  }
  
  result <- data.frame(time = times, S = S, I = I, R = R)
  structure(list(result = result, beta = beta, gamma = gamma, N = N, R0 = beta/gamma), class = c("epi_model", "list"))
}

#' SEIR Model
#' @param beta Transmission rate.
#' @param sigma Latent rate.
#' @param gamma Recovery rate.
#' @param N Total population.
#' @param E0 Initial exposed. Default 0.
#' @param I0 Initial infected. Default 1.
#' @param R0 Initial recovered. Default 0.
#' @param t_max Maximum time. Default 100.
#' @param dt Time step. Default 0.1.
#' @return SEIR model results.
#' @export
epi_seir <- function(beta, sigma, gamma, N, E0 = 0, I0 = 1, R0 = 0, t_max = 100, dt = 0.1) {
  times <- seq(0, t_max, by = dt)
  S <- numeric(length(times)); E <- numeric(length(times)); I <- numeric(length(times)); R <- numeric(length(times))
  S[1] <- N - E0 - I0 - R0; E[1] <- E0; I[1] <- I0; R[1] <- R0
  
  for (t in 2:length(times)) {
    dS <- -beta * S[t-1] * I[t-1] / N
    dE <- beta * S[t-1] * I[t-1] / N - sigma * E[t-1]
    dI <- sigma * E[t-1] - gamma * I[t-1]
    dR <- gamma * I[t-1]
    S[t] <- S[t-1] + dS * dt
    E[t] <- E[t-1] + dE * dt
    I[t] <- I[t-1] + dI * dt
    R[t] <- R[t-1] + dR * dt
  }
  
  result <- data.frame(time = times, S = S, E = E, I = I, R = R)
  structure(list(result = result, beta = beta, sigma = sigma, gamma = gamma, N = N), class = c("epi_model", "list"))
}

#' SIRS Model (with waning immunity)
#' @param beta Transmission rate.
#' @param gamma Recovery rate.
#' @param omega Waning immunity rate.
#' @param N Total population.
#' @param I0 Initial infected. Default 1.
#' @param t_max Maximum time. Default 100.
#' @return SIRS model results.
#' @export
epi_sirs <- function(beta, gamma, omega, N, I0 = 1, t_max = 100) {
  times <- seq(0, t_max, by = 0.1)
  S <- numeric(length(times)); I <- numeric(length(times)); R <- numeric(length(times))
  S[1] <- N - I0; I[1] <- I0; R[1] <- 0
  
  for (t in 2:length(times)) {
    dt <- 0.1
    dS <- -beta * S[t-1] * I[t-1] / N + omega * R[t-1]
    dI <- beta * S[t-1] * I[t-1] / N - gamma * I[t-1]
    dR <- gamma * I[t-1] - omega * R[t-1]
    S[t] <- S[t-1] + dS * dt
    I[t] <- I[t-1] + dI * dt
    R[t] <- R[t-1] + dR * dt
  }
  
  result <- data.frame(time = times, S = S, I = I, R = R)
  structure(list(result = result, beta = beta, gamma = gamma, omega = omega, N = N), class = c("epi_model", "list"))
}

#' SEIRS Model
#' @param beta Transmission rate.
#' @param sigma Latent rate.
#' @param gamma Recovery rate.
#' @param omega Waning immunity rate.
#' @param N Total population.
#' @param t_max Maximum time. Default 100.
#' @return SEIRS model results.
#' @export
epi_seirs <- function(beta, sigma, gamma, omega, N, t_max = 100) {
  times <- seq(0, t_max, by = 0.1)
  S <- E <- I <- R <- numeric(length(times))
  S[1] <- N - 1; E[1] <- 0; I[1] <- 1; R[1] <- 0
  
  for (t in 2:length(times)) {
    dt <- 0.1
    dS <- -beta * S[t-1] * I[t-1] / N + omega * R[t-1]
    dE <- beta * S[t-1] * I[t-1] / N - sigma * E[t-1]
    dI <- sigma * E[t-1] - gamma * I[t-1]
    dR <- gamma * I[t-1] - omega * R[t-1]
    S[t] <- S[t-1] + dS * dt
    E[t] <- E[t-1] + dE * dt
    I[t] <- I[t-1] + dI * dt
    R[t] <- R[t-1] + dR * dt
  }
  
  result <- data.frame(time = times, S = S, E = E, I = I, R = R)
  structure(list(result = result), class = c("epi_model", "list"))
}

#' SIRD Model (with deaths)
#' @param beta Transmission rate.
#' @param gamma Recovery rate.
#' @param mu Death rate.
#' @param N Total population.
#' @param t_max Maximum time. Default 100.
#' @return SIRD model results.
#' @export
epi_sird <- function(beta, gamma, mu, N, t_max = 100) {
  times <- seq(0, t_max, by = 0.1)
  S <- I <- R <- D <- numeric(length(times))
  S[1] <- N - 1; I[1] <- 1; R[1] <- 0; D[1] <- 0
  
  for (t in 2:length(times)) {
    dt <- 0.1
    dS <- -beta * S[t-1] * I[t-1] / N
    dI <- beta * S[t-1] * I[t-1] / N - gamma * I[t-1] - mu * I[t-1]
    dR <- gamma * I[t-1]
    dD <- mu * I[t-1]
    S[t] <- S[t-1] + dS * dt
    I[t] <- I[t-1] + dI * dt
    R[t] <- R[t-1] + dR * dt
    D[t] <- D[t-1] + dD * dt
  }
  
  result <- data.frame(time = times, S = S, I = I, R = R, D = D)
  structure(list(result = result), class = c("epi_model", "list"))
}

#' General Epidemic Simulation
#' @param model_type Model type: "SIR", "SEIR", "SIRS", "SEIRS", "SIRD".
#' @param params List of parameters.
#' @param N Population size.
#' @param t_max Maximum time.
#' @return Simulation results.
#' @export
epi_simulate <- function(model_type = "SIR", params = list(), N = 1000, t_max = 100) {
  switch(model_type,
         SIR = epi_sir(params$beta, params$gamma, N, t_max = t_max),
         SEIR = epi_seir(params$beta, params$sigma, params$gamma, N, t_max = t_max),
         SIRS = epi_sirs(params$beta, params$gamma, params$omega, N, t_max = t_max),
         SEIRS = epi_seirs(params$beta, params$sigma, params$gamma, params$omega, N, t_max = t_max),
         SIRD = epi_sird(params$beta, params$gamma, params$mu, N, t_max = t_max))
}

#' Estimate R0
#' @param incidence Incidence data.
#' @param generation_time Generation time distribution.
#' @param method Estimation method: "exponential", "generation", "likelihood".
#' @return R0 estimate.
#' @export
epi_r0_estimate <- function(incidence, generation_time = NULL, method = "exponential") {
  if (method == "exponential") {
    # Exponential growth rate method
    times <- 1:length(incidence)
    fit <- lm(log(incidence + 0.1) ~ times)
    r <- coef(fit)[2]
    if (!is.null(generation_time)) {
      R0 <- 1 + r * mean(generation_time)
    } else {
      R0 <- exp(r)  # Approximation
    }
  } else {
    R0 <- NA
  }
  structure(list(R0 = R0, method = method), class = c("epi_r0", "list"))
}

#' Estimate Rt (time-varying reproduction number)
#' @param incidence Incidence data.
#' @param generation_time Generation time distribution.
#' @param window Window size. Default 7.
#' @return Rt estimates.
#' @export
epi_rt_estimate <- function(incidence, generation_time, window = 7) {
  n <- length(incidence)
  rt <- numeric(n)
  
  for (t in (window + 1):n) {
    recent_cases <- incidence[(t - window + 1):t]
    past_cases <- incidence[max(1, t - window + 1 - length(generation_time)):max(1, t - length(generation_time))]
    if (sum(past_cases) > 0) {
      rt[t] <- sum(recent_cases) / sum(past_cases)
    }
  }
  
  data.frame(time = 1:n, Rt = rt)
}

#' Calculate Doubling Time
#' @param cases Case counts.
#' @param times Time points.
#' @return Doubling time estimate.
#' @export
epi_doubling_time <- function(cases, times) {
  log_cases <- log(cases[cases > 0])
  valid_times <- times[cases > 0]
  fit <- lm(log_cases ~ valid_times)
  r <- coef(fit)[2]
  doubling_time <- log(2) / r
  structure(list(doubling_time = doubling_time, growth_rate = r), class = c("epi_doubling", "list"))
}

#' Calculate Growth Rate
#' @param cases Case counts.
#' @return Growth rate.
#' @export
epi_growth_rate <- function(cases) {
  log_cases <- log(cases[cases > 0])
  diff_log <- diff(log_cases)
  mean(diff_log, na.rm = TRUE)
}

#' Peak Prediction
#' @param cases Case counts.
#' @param method Prediction method: "moving_average", "logistic".
#' @return Predicted peak.
#' @export
epi_peak_prediction <- function(cases, method = "moving_average") {
  if (method == "moving_average") {
    ma <- stats::filter(cases, rep(1/7, 7), sides = 2)
    peak_day <- which.max(ma)
  } else {
    peak_day <- which.max(cases)
  }
  structure(list(peak_day = peak_day, peak_cases = cases[peak_day]), class = c("epi_peak", "list"))
}

#' Vaccine Impact Simulation
#' @param baseline_model Baseline epidemic model.
#' @param vaccine_coverage Vaccine coverage proportion.
#' @param vaccine_efficacy Vaccine efficacy.
#' @return Vaccine impact results.
#' @export
epi_vaccine_impact <- function(baseline_model, vaccine_coverage = 0.5, vaccine_efficacy = 0.8) {
  # Simplified: reduce susceptible population
  N <- baseline_model$N
  protected <- N * vaccine_coverage * vaccine_efficacy
  
  structure(list(
    protected = protected,
    coverage = vaccine_coverage,
    efficacy = vaccine_efficacy,
    impact = protected / N
  ), class = c("epi_vaccine", "list"))
}

#' Intervention Analysis
#' @param model Epidemic model.
#' @param intervention_time Time of intervention.
#' @param intervention_effect Effect on transmission (0-1).
#' @return Intervention results.
#' @export
epi_intervention <- function(model, intervention_time, intervention_effect) {
  result <- model$result
  post_intervention <- result$time >= intervention_time
  result$I[post_intervention] <- result$I[post_intervention] * (1 - intervention_effect)
  
  structure(list(
    result = result,
    intervention_time = intervention_time,
    effect = intervention_effect
  ), class = c("epi_intervention", "list"))
}

#' Contact Matrix
#' @param age_groups Number of age groups.
#' @param pattern Contact pattern: "homogeneous", "assortative".
#' @return Contact matrix.
#' @export
epi_contact_matrix <- function(age_groups = 4, pattern = "homogeneous") {
  if (pattern == "homogeneous") {
    matrix(1 / age_groups, nrow = age_groups, ncol = age_groups)
  } else {
    # Assortative mixing
    C <- matrix(0.1, nrow = age_groups, ncol = age_groups)
    diag(C) <- 0.5
    C / rowSums(C)
  }
}

#' Age-Structured Model
#' @param contact_matrix Contact matrix.
#' @param age_distribution Age group distribution.
#' @param params Model parameters.
#' @param t_max Maximum time.
#' @return Age-structured results.
#' @export
epi_age_structured <- function(contact_matrix, age_distribution, params, t_max = 100) {
  n_age <- length(age_distribution)
  times <- seq(0, t_max, by = 0.1)
  
  # Simplified age-structured SIR
  S <- matrix(0, nrow = length(times), ncol = n_age)
  I <- matrix(0, nrow = length(times), ncol = n_age)
  R <- matrix(0, nrow = length(times), ncol = n_age)
  
  S[1, ] <- age_distribution - 1
  I[1, ] <- 1
  
  for (t in 2:length(times)) {
    for (a in 1:n_age) {
      force_of_infection <- params$beta * sum(contact_matrix[a, ] * I[t-1, ] / age_distribution)
      dS <- -force_of_infection * S[t-1, a]
      dI <- force_of_infection * S[t-1, a] - params$gamma * I[t-1, a]
      dR <- params$gamma * I[t-1, a]
      S[t, a] <- S[t-1, a] + dS * 0.1
      I[t, a] <- I[t-1, a] + dI * 0.1
      R[t, a] <- R[t-1, a] + dR * 0.1
    }
  }
  
  structure(list(S = S, I = I, R = R, times = times), class = c("epi_age", "list"))
}

#' Spatial Model (simplified)
#' @param locations Data frame with x, y coordinates.
#' @param params Model parameters.
#' @param t_max Maximum time.
#' @return Spatial results.
#' @export
epi_spatial <- function(locations, params, t_max = 100) {
  n_locations <- nrow(locations)
  # Simplified: random connections
  distance_matrix <- as.matrix(dist(locations[, c("x", "y")]))
  connectivity <- exp(-distance_matrix / params$spatial_scale)
  
  structure(list(
    connectivity = connectivity,
    n_locations = n_locations
  ), class = c("epi_spatial", "list"))
}

#' Network Model
#' @param n_nodes Number of nodes.
#' @param network_type Network type: "random", "small_world", "scale_free".
#' @param p Connection probability.
#' @return Network object.
#' @export
epi_network <- function(n_nodes = 100, network_type = "random", p = 0.1) {
  if (!requireNamespace("network", quietly = TRUE)) {
    # Simple random network
    adj <- matrix(runif(n_nodes^2) < p, nrow = n_nodes)
    diag(adj) <- FALSE
  } else {
    if (network_type == "random") {
      net <- network::network(n_nodes, directed = FALSE, density = p)
      adj <- as.matrix(net)
    }
  }
  structure(list(adjacency = adj, n_nodes = n_nodes), class = c("epi_network", "list"))
}

#' Outbreak Detection
#' @param cases Case time series.
#' @param method Detection method: "cusum", "ewma".
#' @param threshold Alert threshold.
#' @return Detection results.
#' @export
epi_outbreak_detection <- function(cases, method = "cusum", threshold = 3) {
  if (method == "cusum") {
    mean_cases <- mean(cases)
    cusum <- cumsum(pmax(0, cases - mean_cases))
    alert <- cusum > threshold * sd(cases)
  } else if (method == "ewma") {
    lambda <- 0.2
    ewma <- numeric(length(cases))
    ewma[1] <- cases[1]
    for (t in 2:length(cases)) {
      ewma[t] <- lambda * cases[t] + (1 - lambda) * ewma[t-1]
    }
    alert <- abs(ewma - mean(cases)) > threshold * sd(cases)
  }
  
  data.frame(time = 1:length(cases), cases = cases, alert = alert)
}

#' Seroprevalence Estimation
#' @param n_tested Number tested.
#' @param n_positive Number positive.
#' @param sensitivity Test sensitivity.
#' @param specificity Test specificity.
#' @return Seroprevalence estimate.
#' @export
epi_seroprevalence <- function(n_tested, n_positive, sensitivity = 1, specificity = 1) {
  apparent_prev <- n_positive / n_tested
  true_prev <- (apparent_prev + specificity - 1) / (sensitivity + specificity - 1)
  se_prev <- sqrt(true_prev * (1 - true_prev) / n_tested)
  
  structure(list(
    apparent = apparent_prev,
    true = true_prev,
    ci_lower = max(0, true_prev - 1.96 * se_prev),
    ci_upper = min(1, true_prev + 1.96 * se_prev)
  ), class = c("epi_sero", "list"))
}

#' Case Fatality Rate Estimation
#' @param deaths Number of deaths.
#' @param cases Number of cases.
#' @param method CFR method: "naive", "time_adjusted".
#' @return CFR estimate.
#' @export
epi_cfr_estimate <- function(deaths, cases, method = "naive") {
  if (method == "naive") {
    cfr <- deaths / cases
  } else {
    # Time-adjusted (simplified)
    cfr <- deaths / cases * 0.8
  }
  structure(list(cfr = cfr, method = method), class = c("epi_cfr", "list"))
}

#' Infection Fatality Rate Estimation
#' @param deaths Number of deaths.
#' @param infections Estimated infections.
#' @return IFR estimate.
#' @export
epi_ifr_estimate <- function(deaths, infections) {
  ifr <- deaths / infections
  structure(list(ifr = ifr), class = c("epi_ifr", "list"))
}

#' Serial Interval Distribution
#' @param serial_intervals Observed serial intervals.
#' @param dist Distribution: "gamma", "lognormal", "weibull".
#' @return Fitted distribution.
#' @export
epi_serial_interval <- function(serial_intervals, dist = "gamma") {
  if (dist == "gamma") {
    fit <- fitdistr(serial_intervals, "gamma")
  } else if (dist == "lognormal") {
    fit <- fitdistr(serial_intervals, "lognormal")
  }
  structure(list(fit = fit, dist = dist, mean = mean(serial_intervals)), class = c("epi_si", "list"))
}

#' Generation Time Distribution
#' @param generation_times Observed generation times.
#' @return Generation time estimate.
#' @export
epi_generation_time <- function(generation_times) {
  structure(list(
    mean = mean(generation_times),
    sd = sd(generation_times),
    median = median(generation_times)
  ), class = c("epi_gt", "list"))
}

#' Incubation Period Distribution
#' @param incubation_periods Observed incubation periods.
#' @return Incubation period estimate.
#' @export
epi_incubation_period <- function(incubation_periods) {
  structure(list(
    mean = mean(incubation_periods),
    sd = sd(incubation_periods),
    median = median(incubation_periods),
    q95 = quantile(incubation_periods, 0.95)
  ), class = c("epi_incub", "list"))
}

#' Plot epidemic model
#' @param x Epidemic model object.
#' @param ... Additional arguments.
#' @return ggplot object.
#' @export
plot.epi_model <- function(x, ...) {
  df <- x$result
  df_long <- tidyr::pivot_longer(df, cols = -time, names_to = "Compartment", values_to = "Count")
  
  ggplot2::ggplot(df_long, ggplot2::aes(x = time, y = Count, color = Compartment)) +
    ggplot2::geom_line(size = 1) +
    ggplot2::labs(title = "Epidemic Model", x = "Time", y = "Number of Individuals") +
    ggplot2::theme_minimal()
}
