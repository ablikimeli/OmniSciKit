#' Theme Module
#'
#' @description
#' Provides custom ggplot2 themes and color palettes for OmniSciKit.
#'
#' @name theme
#' @keywords internal
NULL

#' OmniSciKit Theme
#' @param base_size Base font size. Default 12.
#' @param base_family Font family. Default "sans".
#' @param theme_type Theme type: "minimal", "classic", "dark".
#' @return ggplot2 theme.
#' @export
omni_theme <- function(base_size = 12, base_family = "sans", theme_type = "minimal") {
  base_theme <- switch(theme_type,
                       minimal = ggplot2::theme_minimal(base_size = base_size, base_family = base_family),
                       classic = ggplot2::theme_classic(base_size = base_size, base_family = base_family),
                       dark = ggplot2::theme_dark(base_size = base_size, base_family = base_family),
                       ggplot2::theme_minimal(base_size = base_size, base_family = base_family))
  
  base_theme +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", size = base_size * 1.2),
      axis.title = ggplot2::element_text(face = "bold"),
      legend.position = "right",
      panel.grid.minor = ggplot2::element_blank()
    )
}

#' OmniSciKit Color Palette
#' @param n Number of colors.
#' @param palette Palette name: "default", "viridis", "brewer", "custom".
#' @return Color vector.
#' @export
omni_palette <- function(n, palette = "default") {
  switch(palette,
         default = c("#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b", "#e377c2", "#7f7f7f"),
         viridis = viridisLite::viridis(n),
         brewer = RColorBrewer::brewer.pal(min(n, 8), "Set1"),
         custom = grDevices::rainbow(n))
}

#' Get Color
#' @param color_name Color name.
#' @return Hex color code.
#' @export
omni_color <- function(color_name = "primary") {
  colors <- list(
    primary = "#1f77b4",
    secondary = "#ff7f0e",
    success = "#2ca02c",
    danger = "#d62728",
    warning = "#ffbb78",
    info = "#17becf"
  )
  colors[[color_name]]
}

#' Set Font
#' @param font_family Font family.
#' @return Font setting.
#' @export
omni_font <- function(font_family = "sans") {
  ggplot2::theme(text = ggplot2::element_text(family = font_family))
}

#' Set Style
#' @param style Style name.
#' @return Style settings.
#' @export
omni_style <- function(style = "publication") {
  switch(style,
         publication = list(theme = omni_theme(), palette = omni_palette(8)),
         presentation = list(theme = omni_theme(base_size = 16), palette = omni_palette(8)),
         web = list(theme = omni_theme(base_size = 10), palette = omni_palette(8)))
}

#' Set Layout
#' @param ncol Number of columns.
#' @param nrow Number of rows.
#' @return Layout settings.
#' @export
omni_layout <- function(ncol = 2, nrow = 1) {
  list(ncol = ncol, nrow = nrow)
}
