#' OmniSciKit Theme
#'
#' @return Theme object.
#' @export
theme_omni <- function() {
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Please install ggplot2.")
  }
  ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", size = 14),
      axis.title = ggplot2::element_text(size = 12),
      legend.position = "bottom"
    )
}

#' Color Palette
#'
#' @param n Number of colors.
#' @return Color vector.
#' @export
omni_palette <- function(n = 10) {
  colors <- c("#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd",
              "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf")
  rep(colors, length.out = n)
}

#' Set Options
#'
#' @param ... Options.
#' @export
set_omni_options <- function(...) {
  opts <- list(...)
  for (nm in names(opts)) {
    options(setNames(list(opts[[nm]]), paste0("OmniSciKit.", nm)))
  }
}