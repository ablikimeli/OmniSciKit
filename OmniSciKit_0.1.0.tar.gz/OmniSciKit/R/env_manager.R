#' Environment Manager for OmniSciKit
#'
#' @description
#' Manages package dependencies and environment setup for OmniSciKit.
#' Provides functions to check, install, and configure required packages.
#'
#' @name env_manager
#' @keywords internal
NULL

#' Check Dependencies
#'
#' Checks which optional dependencies are installed and available.
#'
#' @return A data frame with dependency status
#' @export
#'
#' @examples
#' \dontrun{
#' check_deps()
#' }
check_deps <- function() {
  # Define all optional dependencies by module
  deps <- list(
    bioinformatics = c("BiocManager", "DESeq2", "edgeR", "limma", "clusterProfiler",
                       "org.Hs.eg.db", "TCGAbiolinks", "GEOquery", "SummarizedExperiment"),
    mendelian_randomization = c("TwoSampleMR", "MendelianRandomization", "ieugwasr",
                                "mr.raps", "MRPRESSO", "RadialMR"),
    machine_learning = c("caret", "randomForest", "xgboost", "glmnet", "e1071", "pROC", "ROCR"),
    epidemiology = c("deSolve", "EpiModel", "network", "statnet"),
    statistics = c("tableone", "gtsummary", "broom"),
    sample_size = c("pwr", "samplesize", "powerAnalysis")
  )
  
  # Check each dependency
  results <- list()
  for (module in names(deps)) {
    module_deps <- deps[[module]]
    installed <- sapply(module_deps, requireNamespace, quietly = TRUE)
    
    results[[module]] <- data.frame(
      package = module_deps,
      installed = installed,
      stringsAsFactors = FALSE
    )
  }
  
  # Combine results
  all_results <- do.call(rbind, results)
  rownames(all_results) <- NULL
  
  # Print summary
  cli::cli_h1("OmniSciKit Dependency Status")
  
  for (module in names(deps)) {
    module_results <- results[[module]]
    n_installed <- sum(module_results$installed)
    n_total <- nrow(module_results)
    
    if (n_installed == n_total) {
      cli::cli_alert_success("{module}: {n_installed}/{n_total} packages installed")
    } else {
      cli::cli_alert_warning("{module}: {n_installed}/{n_total} packages installed")
      missing <- module_results$package[!module_results$installed]
      cli::cli_text("  Missing: {paste(missing, collapse = ', ')}")
    }
  }
  
  invisible(all_results)
}

#' Install OmniSciKit Dependencies
#'
#' Installs all optional dependencies for OmniSciKit.
#'
#' @param modules Character vector of modules to install dependencies for.
#'   Options: "all", "bioinformatics", "mendelian_randomization",
#'   "machine_learning", "epidemiology", "statistics", "sample_size".
#' @param method Installation method: "auto", "pak", "BiocManager", "install.packages".
#' @param upgrade Whether to upgrade existing packages. Default is FALSE.
#'
#' @return Invisible NULL
#' @export
#'
#' @examples
#' \dontrun{
#' install_omni()
#' install_omni(modules = c("bioinformatics", "machine_learning"))
#' }
install_omni <- function(modules = "all", method = "auto", upgrade = FALSE) {
  # Define dependencies for each module
  all_deps <- list(
    bioinformatics = c("BiocManager", "DESeq2", "edgeR", "limma", "clusterProfiler",
                       "org.Hs.eg.db", "TCGAbiolinks", "GEOquery", "SummarizedExperiment"),
    mendelian_randomization = c("TwoSampleMR", "MendelianRandomization", "ieugwasr",
                                "mr.raps", "MRPRESSO", "RadialMR"),
    machine_learning = c("caret", "randomForest", "xgboost", "glmnet", "e1071", "pROC", "ROCR"),
    epidemiology = c("deSolve", "EpiModel", "network", "statnet"),
    statistics = c("tableone", "gtsummary", "broom"),
    sample_size = c("pwr", "samplesize", "powerAnalysis")
  )
  
  # Determine which modules to install
  if ("all" %in% modules) {
    modules <- names(all_deps)
  }
  
  # Validate modules
  invalid <- setdiff(modules, names(all_deps))
  if (length(invalid) > 0) {
    stop("Invalid modules: ", paste(invalid, collapse = ", "))
  }
  
  # Get list of packages to install
  pkgs <- unique(unlist(all_deps[modules]))
  
  cli::cli_h1("Installing OmniSciKit Dependencies")
  cli::cli_alert_info("Modules: {paste(modules, collapse = ', ')}")
  cli::cli_alert_info("Packages to install: {length(pkgs)}")
  
  # Install packages
  for (pkg in pkgs) {
    if (requireNamespace(pkg, quietly = TRUE) && !upgrade) {
      cli::cli_alert_success("{pkg} already installed")
      next
    }
    
    cli::cli_alert_info("Installing {pkg}...")
    
    tryCatch({
      if (method == "auto") {
        # Try pak first, then BiocManager, then install.packages
        if (requireNamespace("pak", quietly = TRUE)) {
          pak::pkg_install(pkg, ask = FALSE)
        } else if (pkg %in% c("DESeq2", "edgeR", "limma", "clusterProfiler",
                              "org.Hs.eg.db", "TCGAbiolinks", "GEOquery", "SummarizedExperiment")) {
          if (!requireNamespace("BiocManager", quietly = TRUE)) {
            install.packages("BiocManager")
          }
          BiocManager::install(pkg, ask = FALSE, update = FALSE)
        } else {
          install.packages(pkg, dependencies = TRUE)
        }
      } else if (method == "pak") {
        pak::pkg_install(pkg, ask = FALSE)
      } else if (method == "BiocManager") {
        BiocManager::install(pkg, ask = FALSE, update = FALSE)
      } else {
        install.packages(pkg, dependencies = TRUE)
      }
      
      cli::cli_alert_success("{pkg} installed successfully")
    }, error = function(e) {
      cli::cli_alert_danger("Failed to install {pkg}: {e$message}")
    })
  }
  
  cli::cli_alert_success("Installation complete!")
  invisible(NULL)
}

#' Set OmniSciKit Options
#'
#' Sets global options for OmniSciKit package.
#'
#' @param palette Color palette to use. Options: "default", "viridis", "brewer", "custom".
#' @param sig_level Significance level for statistical tests. Default is 0.05.
#' @param theme ggplot2 theme to use. Options: "minimal", "classic", "bw", "dark".
#' @param font Base font family for plots.
#' @param seed Random seed for reproducibility.
#' @param verbose Whether to print verbose messages. Default is TRUE.
#' @param ... Additional options.
#'
#' @return Invisible list of current options
#' @export
#'
#' @examples
#' \dontrun{
#' set_omni_options(palette = "viridis", sig_level = 0.01)
#' }
set_omni_options <- function(palette = "default", sig_level = 0.05,
                             theme = "minimal", font = "sans",
                             seed = NULL, verbose = TRUE, ...) {
  # Validate inputs
  if (!palette %in% c("default", "viridis", "brewer", "custom")) {
    stop("palette must be one of: 'default', 'viridis', 'brewer', 'custom'")
  }
  
  if (sig_level <= 0 || sig_level >= 1) {
    stop("sig_level must be between 0 and 1")
  }
  
  if (!theme %in% c("minimal", "classic", "bw", "dark")) {
    stop("theme must be one of: 'minimal', 'classic', 'bw', 'dark'")
  }
  
  # Set options
  options <- list(
    omni.palette = palette,
    omni.sig_level = sig_level,
    omni.theme = theme,
    omni.font = font,
    omni.verbose = verbose,
    ...
  )
  
  if (!is.null(seed)) {
    options$omni.seed <- seed
    set.seed(seed)
  }
  
  # Store options
  for (name in names(options)) {
    options(name = options[[name]])
  }
  
  if (verbose) {
    cli::cli_alert_success("OmniSciKit options set successfully")
  }
  
  invisible(options)
}

#' Get OmniSciKit Option
#'
#' Retrieves the value of an OmniSciKit option.
#'
#' @param name Name of the option to retrieve.
#' @param default Default value if option is not set.
#'
#' @return The value of the option, or the default value if not set.
#' @export
#'
#' @examples
#' \dontrun{
#' get_omni_option("palette")
#' get_omni_option("sig_level", 0.05)
#' }
get_omni_option <- function(name, default = NULL) {
  full_name <- paste0("omni.", name)
  getOption(full_name, default)
}
