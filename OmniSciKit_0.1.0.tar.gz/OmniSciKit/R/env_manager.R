#' Check and Install Dependencies
#'
#' Checks if required packages are installed and provides installation guidance.
#' Also attempts to load installed packages with informative messages.
#'
#' @param pkgs Character vector of package names to check.
#' @param install Logical. If TRUE, attempts to install missing packages. Default is FALSE.
#' @param load Logical. If TRUE, attempts to attach installed packages to search path. Default is TRUE.
#' @return Invisible list with components: installed, missing, loaded.
#' @examples
#' check_deps(c("ggplot2", "dplyr"))
#' @export
check_deps <- function(pkgs, install = FALSE, load = TRUE) {
  # Check which packages are installed
  installed_pkgs <- pkgs[sapply(pkgs, requireNamespace, quietly = TRUE)]
  missing_pkgs <- setdiff(pkgs, installed_pkgs)
  
  # Report missing packages
  if (length(missing_pkgs) > 0) {
    message("\u274c Missing packages (", length(missing_pkgs), "): ", paste(missing_pkgs, collapse = ", "))
    message("   Install with: install_omni(c(\"", paste(missing_pkgs, collapse = "\", \""), "\"))")
    if (any(missing_pkgs %in% c("DESeq2", "edgeR", "limma", "clusterProfiler", "org.Hs.eg.db",
                                "TCGAbiolinks", "GEOquery", "SummarizedExperiment",
                                "TwoSampleMR", "MendelianRandomization", "ieugwasr",
                                "mr.raps", "MRPRESSO", "RadialMR"))) {
      message("   Note: Some missing packages are Bioconductor packages.")
      message("   Use: install_omni(c(\"...\"), bioc = TRUE)")
    }
    if (install) {
      install_omni(missing_pkgs)
      # Recheck after installation
      installed_pkgs <- pkgs[sapply(pkgs, requireNamespace, quietly = TRUE)]
      missing_pkgs <- setdiff(pkgs, installed_pkgs)
    }
  }
  
  # Load installed packages if requested
  loaded_pkgs <- character(0)
  if (load && length(installed_pkgs) > 0) {
    for (pkg in installed_pkgs) {
      if (!pkg %in% loadedNamespaces()) {
        tryCatch({
          library(pkg, character.only = TRUE, warn.conflicts = FALSE, quietly = TRUE)
          loaded_pkgs <- c(loaded_pkgs, pkg)
        }, error = function(e) {
          message("\u26a0\ufe0f  Could not load ", pkg, ": ", conditionMessage(e))
        })
      } else {
        loaded_pkgs <- c(loaded_pkgs, pkg)
      }
    }
  }
  
  # Summary message
  if (length(missing_pkgs) == 0) {
    message("\u2705 All required packages are installed (", length(installed_pkgs), ").")
    if (load && length(loaded_pkgs) > 0) {
      message("\u2705 Loaded ", length(loaded_pkgs), " package(s): ", paste(loaded_pkgs, collapse = ", "))
    }
  } else {
    message("\u26a0\ufe0f  ", length(missing_pkgs), " package(s) still missing: ", paste(missing_pkgs, collapse = ", "))
  }
  
  invisible(list(
    installed = installed_pkgs,
    missing = missing_pkgs,
    loaded = loaded_pkgs
  ))
}

#' Install Packages with Guidance
#'
#' Installs packages from CRAN or Bioconductor with progress messages.
#'
#' @param pkgs Character vector of package names.
#' @param bioc Logical. If TRUE, uses BiocManager for Bioconductor packages.
#' @param ask Logical. If TRUE, asks before installing. Default is FALSE.
#' @return Invisible NULL.
#' @examples
#' \dontrun{
#' install_omni(c("DESeq2", "edgeR"), bioc = TRUE)
#' }
#' @export
install_omni <- function(pkgs, bioc = FALSE, ask = FALSE) {
  if (length(pkgs) == 0) {
    message("No packages to install.")
    return(invisible(NULL))
  }
  
  message("\ud83d\udce5 Installing ", length(pkgs), " package(s): ", paste(pkgs, collapse = ", "))
  
  if (bioc) {
    if (!requireNamespace("BiocManager", quietly = TRUE)) {
      message("Installing BiocManager first...")
      install.packages("BiocManager", ask = ask)
    }
    message("Using Bioconductor...")
    BiocManager::install(pkgs, ask = ask)
  } else {
    # Check if any are Bioconductor packages
    bioc_pkgs <- c("DESeq2", "edgeR", "limma", "clusterProfiler", "org.Hs.eg.db",
                   "TCGAbiolinks", "GEOquery", "SummarizedExperiment",
                   "TwoSampleMR", "MendelianRandomization", "ieugwasr",
                   "mr.raps", "MRPRESSO", "RadialMR")
    is_bioc <- pkgs %in% bioc_pkgs
    
    if (any(is_bioc)) {
      message("Note: ", sum(is_bioc), " package(s) appear to be from Bioconductor.")
      message("Consider using install_omni(bioc = TRUE) for these.")
    }
    
    install.packages(pkgs, ask = ask)
  }
  
  # Verify installation
  still_missing <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
  if (length(still_missing) == 0) {
    message("\u2705 All packages installed successfully!")
  } else {
    message("\u26a0\ufe0f  Failed to install: ", paste(still_missing, collapse = ", "))
  }
  
  invisible(NULL)
}

#' Set OmniSciKit Options
#'
#' @param ... Named options to set.
#' @return Invisible NULL.
#' @examples
#' set_omni_options(theme = "default", verbose = TRUE)
#' @export
set_omni_options <- function(...) {
  opts <- list(...)
  for (nm in names(opts)) {
    options(stats::setNames(list(opts[[nm]]), paste0("OmniSciKit.", nm)))
  }
  invisible(NULL)
}

#' Get OmniSciKit Option
#'
#' @param name Option name.
#' @param default Default value.
#' @return The option value or default.
#' @examples
#' get_omni_option("theme", "default")
#' @export
get_omni_option <- function(name, default = NULL) {
  getOption(paste0("OmniSciKit.", name), default)
}
