#' T-Test Analysis
#'
#' Performs one-sample, two-sample, or paired t-test with detailed output.
#'
#' @param x Numeric vector.
#' @param y Optional numeric vector for two-sample test.
#' @param paired Logical for paired test.
#' @param mu Null hypothesis value.
#' @return List with test results and interpretation.
#' @examples
#' # Example 1: One-sample t-test
#' # Test if mean BMI differs from 24
#' set.seed(123)
#' bmi <- rnorm(30, mean = 26.5, sd = 4)
#' result <- stats_ttest(bmi, mu = 24)
#' print(result)
#'
#' # Example 2: Two-sample t-test with clinical data
#' data(omni_clinical)
#' drug_group <- omni_clinical$cholesterol[omni_clinical$treatment == "Drug_A"]
#' placebo_group <- omni_clinical$cholesterol[omni_clinical$treatment == "Placebo"]
#' result <- stats_ttest(drug_group, placebo_group)
#' print(result)
#' cat("Mean difference:", round(result$estimate[1] - result$estimate[2], 2), "\n")
#'
#' # Example 3: Paired t-test
#' set.seed(123)
#' before <- rnorm(20, mean = 120, sd = 10)
#' after <- before - rnorm(20, mean = 8, sd = 5)
#' result <- stats_ttest(before, after, paired = TRUE)
#' print(result)
#'
#' # Example 4: Visualization
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   df <- data.frame(
#'     group = rep(c("Before", "After"), each = 20),
#'     value = c(before, after)
#'   )
#'   p <- ggplot2::ggplot(df, ggplot2::aes(x = group, y = value, fill = group)) +
#'     ggplot2::geom_boxplot() +
#'     ggplot2::labs(title = "Paired T-Test: Before vs After")
#'   print(p)
#' }
#' @export
stats_ttest <- function(x, y = NULL, paired = FALSE, mu = 0) {
  if (is.null(y)) {
    res <- t.test(x, mu = mu)
    test_type <- "One-sample"
  } else {
    res <- t.test(x, y, paired = paired, mu = mu)
    test_type <- ifelse(paired, "Paired", "Two-sample")
  }
  
  interpretation <- ifelse(res$p.value < 0.05, 
                           "Significant difference detected (p < 0.05)",
                           "No significant difference (p >= 0.05)")
  
  result <- list(
    test_type = test_type,
    statistic = res$statistic,
    p_value = res$p.value,
    conf_int = res$conf.int,
    estimate = res$estimate,
    method = res$method,
    interpretation = interpretation,
    data = list(x = x, y = y)
  )
  class(result) <- "omni_stats"
  return(result)
}

#' Wilcoxon Rank-Sum Test
#'
#' Non-parametric test for two independent samples.
#'
#' @param x Numeric vector.
#' @param y Numeric vector.
#' @param paired Logical for paired test.
#' @return List with test results.
#' @examples
#' # Example 1: Basic usage
#' set.seed(123)
#' group1 <- rnorm(20, 5, 1)
#' group2 <- rnorm(20, 6.5, 1)
#' result <- stats_wilcoxon(group1, group2)
#' print(result)
#'
#' # Example 2: With clinical data
#' data(omni_clinical)
#' drug_bp <- omni_clinical$systolic_bp[omni_clinical$treatment == "Drug_A"]
#' placebo_bp <- omni_clinical$systolic_bp[omni_clinical$treatment == "Placebo"]
#' result <- stats_wilcoxon(drug_bp, placebo_bp)
#' print(result)
#'
#' # Example 3: Visualization
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   df <- data.frame(
#'     group = rep(c("Drug", "Placebo"), c(length(drug_bp), length(placebo_bp))),
#'     bp = c(drug_bp, placebo_bp)
#'   )
#'   p <- ggplot2::ggplot(df, ggplot2::aes(x = group, y = bp, fill = group)) +
#'     ggplot2::geom_boxplot() +
#'     ggplot2::labs(title = "Blood Pressure by Treatment")
#'   print(p)
#' }
#' @export
stats_wilcoxon <- function(x, y = NULL, paired = FALSE) {
  res <- wilcox.test(x, y, paired = paired)
  result <- list(
    statistic = res$statistic,
    p_value = res$p.value,
    method = res$method,
    data = list(x = x, y = y)
  )
  class(result) <- "omni_stats"
  return(result)
}

#' ANOVA Analysis
#'
#' One-way ANOVA with post-hoc tests.
#'
#' @param x Formula or numeric vector.
#' @param y Data frame or grouping factor.
#' @return List with ANOVA table and group means.
#' @examples
#' # Example 1: Formula interface
#' set.seed(123)
#' df <- data.frame(
#'   value = c(rnorm(10, 5), rnorm(10, 7), rnorm(10, 6)),
#'   group = rep(c("A", "B", "C"), each = 10)
#' )
#' result <- stats_anova(value ~ group, df)
#' print(result)
#'
#' # Example 2: Vector interface
#' values <- c(rnorm(10, 5), rnorm(10, 7), rnorm(10, 6))
#' groups <- rep(c("A", "B", "C"), each = 10)
#' result <- stats_anova(values, groups)
#' print(result)
#'
#' # Example 3: Clinical data
#' data(omni_clinical)
#' result <- stats_anova(omni_clinical$cholesterol, omni_clinical$treatment)
#' print(result)
#'
#' # Example 4: Visualization
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   p <- ggplot2::ggplot(omni_clinical, 
#'                        ggplot2::aes(x = treatment, y = cholesterol, fill = treatment)) +
#'     ggplot2::geom_boxplot() +
#'     ggplot2::labs(title = "Cholesterol by Treatment Group")
#'   print(p)
#' }
#' @export
stats_anova <- function(x, y = NULL) {
  if (inherits(x, "formula")) {
    res <- aov(x, data = y)
    df <- y
    formula <- x
  } else {
    df <- data.frame(value = x, group = y)
    res <- aov(value ~ group, data = df)
    formula <- value ~ group
  }
  
  summary_res <- summary(res)
  group_means <- aggregate(formula, data = df, FUN = mean)
  
  result <- list(
    anova_table = summary_res,
    group_means = group_means,
    residuals = res$residuals,
    fitted = res$fitted.values,
    data = df
  )
  class(result) <- "omni_stats"
  return(result)
}

#' Correlation Analysis
#'
#' Pearson or Spearman correlation with confidence interval.
#'
#' @param x Numeric vector.
#' @param y Numeric vector.
#' @param method Correlation method.
#' @return List with correlation results.
#' @examples
#' # Example 1: Pearson correlation
#' set.seed(123)
#' x <- rnorm(50)
#' y <- 2*x + rnorm(50)
#' result <- stats_correlation(x, y)
#' print(result)
#'
#' # Example 2: Spearman correlation
#' result <- stats_correlation(x, y, method = "spearman")
#' print(result)
#'
#' # Example 3: Clinical data - age vs BMI
#' data(omni_clinical)
#' result <- stats_correlation(omni_clinical$age, omni_clinical$bmi)
#' print(result)
#'
#' # Example 4: Visualization with regression line
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   p <- ggplot2::ggplot(omni_clinical, ggplot2::aes(x = age, y = bmi)) +
#'     ggplot2::geom_point(size = 3, alpha = 0.6) +
#'     ggplot2::geom_smooth(method = "lm", color = "red") +
#'     ggplot2::labs(title = "Age vs BMI Correlation")
#'   print(p)
#' }
#' @export
stats_correlation <- function(x, y, method = "pearson") {
  res <- cor.test(x, y, method = method)
  result <- list(
    estimate = res$estimate,
    p_value = res$p.value,
    conf_int = res$conf.int,
    method = res$method,
    data = data.frame(x = x, y = y)
  )
  class(result) <- "omni_stats"
  return(result)
}

#' Linear Regression
#'
#' Linear regression with diagnostics.
#'
#' @param y Response variable.
#' @param x Predictor(s).
#' @param data Data frame.
#' @return List with model results.
#' @examples
#' # Example 1: Simple regression
#' set.seed(123)
#' x <- rnorm(50)
#' y <- 2*x + rnorm(50)
#' result <- stats_regression(y, x)
#' print(result)
#'
#' # Example 2: Multiple regression with clinical data
#' data(omni_clinical)
#' result <- stats_regression(cholesterol ~ age + bmi + systolic_bp, 
#'                            data = omni_clinical)
#' print(result)
#'
#' # Example 3: Visualization
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   p <- ggplot2::ggplot(omni_clinical, ggplot2::aes(x = age, y = cholesterol)) +
#'     ggplot2::geom_point(size = 3, alpha = 0.6) +
#'     ggplot2::geom_smooth(method = "lm", color = "blue") +
#'     ggplot2::labs(title = "Age vs Cholesterol")
#'   print(p)
#' }
#' @export
stats_regression <- function(y, x, data = NULL) {
  if (inherits(y, "formula")) {
    model <- lm(y, data = data)
  } else {
    if (is.matrix(x) || is.data.frame(x)) {
      model <- lm(y ~ ., data = as.data.frame(x))
    } else {
      model <- lm(y ~ x)
    }
  }
  
  result <- list(
    coefficients = coef(model),
    r_squared = summary(model)$r.squared,
    adj_r_squared = summary(model)$adj.r.squared,
    f_statistic = summary(model)$fstatistic,
    residuals = residuals(model),
    fitted = fitted(model),
    model = model
  )
  class(result) <- "omni_stats"
  return(result)
}

#' Chi-Square Test
#'
#' Chi-square test for contingency tables.
#'
#' @param x Matrix or table.
#' @return List with test results.
#' @examples
#' # Example 1: Basic usage
#' tbl <- matrix(c(20, 30, 15, 35), nrow = 2)
#' result <- stats_chisq(tbl)
#' print(result)
#'
#' # Example 2: Clinical data - treatment vs response
#' data(omni_clinical)
#' tbl <- table(omni_clinical$treatment, omni_clinical$response)
#' print(tbl)
#' result <- stats_chisq(tbl)
#' print(result)
#'
#' # Example 3: Visualization
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   df <- as.data.frame(tbl)
#'   p <- ggplot2::ggplot(df, ggplot2::aes(x = Var1, y = Freq, fill = Var2)) +
#'     ggplot2::geom_bar(stat = "identity", position = "dodge") +
#'     ggplot2::labs(title = "Treatment vs Response")
#'   print(p)
#' }
#' @export
stats_chisq <- function(x) {
  res <- chisq.test(x)
  result <- list(
    statistic = res$statistic,
    p_value = res$p.value,
    expected = res$expected,
    observed = x,
    method = res$method
  )
  class(result) <- "omni_stats"
  return(result)
}

#' Normality Test
#'
#' Shapiro-Wilk or Kolmogorov-Smirnov test.
#'
#' @param x Numeric vector.
#' @param method Test method.
#' @return List with test results.
#' @examples
#' # Example 1: Normal data
#' set.seed(123)
#' x <- rnorm(50)
#' result <- stats_normality(x)
#' print(result)
#'
#' # Example 2: Non-normal data
#' x <- rexp(50, rate = 1)
#' result <- stats_normality(x)
#' print(result)
#'
#' # Example 3: Clinical data - test BMI normality
#' data(omni_clinical)
#' result <- stats_normality(omni_clinical$bmi)
#' print(result)
#'
#' # Example 4: Q-Q plot
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   p <- ggplot2::ggplot(data.frame(x = omni_clinical$bmi), 
#'                        ggplot2::aes(sample = x)) +
#'     ggplot2::stat_qq() +
#'     ggplot2::stat_qq_line() +
#'     ggplot2::labs(title = "Q-Q Plot for BMI")
#'   print(p)
#' }
#' @export
stats_normality <- function(x, method = "shapiro") {
  if (method == "shapiro") {
    res <- shapiro.test(x)
  } else {
    res <- ks.test(x, "pnorm", mean = mean(x), sd = sd(x))
  }
  result <- list(
    statistic = res$statistic,
    p_value = res$p.value,
    method = res$method,
    data = x
  )
  class(result) <- "omni_stats"
  return(result)
}

#' Print Method for Statistical Results
#'
#' @param x omni_stats object.
#' @examples
#' result <- stats_ttest(rnorm(30, 5.5), rnorm(30, 5))
#' print(result)
#' @param ... Additional arguments (not used).
#' @export
print.omni_stats <- function(x, ...) {
  cat("\n=== Statistical Analysis Results ===\n")
  if (!is.null(x$test_type)) {
    cat("Test:", x$test_type, "\n")
  }
  if (!is.null(x$statistic)) {
    cat("Statistic:", round(x$statistic, 4), "\n")
  }
  if (!is.null(x$p_value)) {
    cat("P-value:", format.pval(x$p_value, eps = 0.001), "\n")
  }
  if (!is.null(x$interpretation)) {
    cat("Interpretation:", x$interpretation, "\n")
  }
  if (!is.null(x$r_squared)) {
    cat("R-squared:", round(x$r_squared, 4), "\n")
  }
  if (!is.null(x$estimate)) {
    cat("Estimate:", round(x$estimate, 4), "\n")
  }
  cat("\n")
}

