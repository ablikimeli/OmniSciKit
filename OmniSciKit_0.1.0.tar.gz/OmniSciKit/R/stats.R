#' Medical Statistics Module
#'
#' @description
#' Provides comprehensive statistical tools for medical research including
#' hypothesis testing, regression analysis, and diagnostic metrics.
#'
#' @name stats
#' @keywords internal
NULL

#' T-Test
#' @param x Numeric vector or formula.
#' @param y Optional second vector.
#' @param data Data frame.
#' @param paired Paired test. Default FALSE.
#' @param var.equal Equal variances. Default FALSE.
#' @param ... Additional arguments.
#' @return Test results.
#' @export
stats_ttest <- function(x, y = NULL, data = NULL, paired = FALSE, var.equal = FALSE, ...) {
  if (!is.null(data)) {
    fit <- t.test(x, data = data, paired = paired, var.equal = var.equal, ...)
  } else {
    fit <- t.test(x, y, paired = paired, var.equal = var.equal, ...)
  }
  structure(list(result = fit), class = c("omni_stats", "list"))
}

#' Wilcoxon Rank-Sum Test
#' @param x Numeric vector or formula.
#' @param y Optional second vector.
#' @param data Data frame.
#' @param paired Paired test. Default FALSE.
#' @param ... Additional arguments.
#' @return Test results.
#' @export
stats_wilcoxon <- function(x, y = NULL, data = NULL, paired = FALSE, ...) {
  if (!is.null(data)) {
    fit <- wilcox.test(x, data = data, paired = paired, ...)
  } else {
    fit <- wilcox.test(x, y, paired = paired, ...)
  }
  structure(list(result = fit), class = c("omni_stats", "list"))
}

#' ANOVA
#' @param formula Model formula.
#' @param data Data frame.
#' @param ... Additional arguments.
#' @return ANOVA results.
#' @export
stats_anova <- function(formula, data, ...) {
  fit <- aov(formula, data = data, ...)
  structure(list(result = fit, summary = summary(fit)), class = c("omni_stats", "list"))
}

#' Kruskal-Wallis Test
#' @param formula Model formula.
#' @param data Data frame.
#' @param ... Additional arguments.
#' @return Test results.
#' @export
stats_kruskal <- function(formula, data, ...) {
  fit <- kruskal.test(formula, data = data, ...)
  structure(list(result = fit), class = c("omni_stats", "list"))
}

#' Chi-Square Test
#' @param x Table or formula.
#' @param y Optional vector.
#' @param data Data frame.
#' @param correct Continuity correction. Default TRUE.
#' @param ... Additional arguments.
#' @return Test results.
#' @export
stats_chisq <- function(x, y = NULL, data = NULL, correct = TRUE, ...) {
  if (!is.null(data)) {
    fit <- chisq.test(x, data = data, correct = correct, ...)
  } else if (is.null(y)) {
    fit <- chisq.test(x, correct = correct, ...)
  } else {
    fit <- chisq.test(x, y, correct = correct, ...)
  }
  structure(list(result = fit), class = c("omni_stats", "list"))
}

#' Fisher's Exact Test
#' @param x Table or formula.
#' @param y Optional vector.
#' @param data Data frame.
#' @param ... Additional arguments.
#' @return Test results.
#' @export
stats_fisher <- function(x, y = NULL, data = NULL, ...) {
  if (!is.null(data)) {
    fit <- fisher.test(x, data = data, ...)
  } else if (is.null(y)) {
    fit <- fisher.test(x, ...)
  } else {
    fit <- fisher.test(x, y, ...)
  }
  structure(list(result = fit), class = c("omni_stats", "list"))
}

#' McNemar's Test
#' @param x Table or formula.
#' @param y Optional vector.
#' @param data Data frame.
#' @param correct Continuity correction. Default TRUE.
#' @return Test results.
#' @export
stats_mcnemar <- function(x, y = NULL, data = NULL, correct = TRUE) {
  if (!is.null(data)) {
    fit <- mcnemar.test(x, data = data, correct = correct)
  } else if (is.null(y)) {
    fit <- mcnemar.test(x, correct = correct)
  } else {
    fit <- mcnemar.test(x, y, correct = correct)
  }
  structure(list(result = fit), class = c("omni_stats", "list"))
}

#' Correlation Analysis
#' @param x Numeric vector or data frame.
#' @param y Optional numeric vector.
#' @param method Correlation method: "pearson", "spearman", "kendall".
#' @param ... Additional arguments.
#' @return Correlation results.
#' @export
stats_correlation <- function(x, y = NULL, method = "pearson", ...) {
  if (is.null(y)) {
    fit <- cor(x, method = method, use = "complete.obs", ...)
  } else {
    fit <- cor.test(x, y, method = method, ...)
  }
  structure(list(result = fit, method = method), class = c("omni_stats", "list"))
}

#' Linear Regression
#' @param formula Model formula.
#' @param data Data frame.
#' @param ... Additional arguments.
#' @return Regression results.
#' @export
stats_regression <- function(formula, data, ...) {
  fit <- lm(formula, data = data, ...)
  structure(list(result = fit, summary = summary(fit)), class = c("omni_stats", "list"))
}

#' Logistic Regression
#' @param formula Model formula.
#' @param data Data frame.
#' @param ... Additional arguments.
#' @return Regression results.
#' @export
stats_logistic_reg <- function(formula, data, ...) {
  fit <- glm(formula, data = data, family = binomial(), ...)
  structure(list(result = fit, summary = summary(fit)), class = c("omni_stats", "list"))
}

#' Cox Regression
#' @param formula Model formula.
#' @param data Data frame.
#' @param ... Additional arguments.
#' @return Regression results.
#' @export
stats_cox_reg <- function(formula, data, ...) {
  if (!requireNamespace("survival", quietly = TRUE)) {
    stop("survival package required")
  }
  fit <- survival::coxph(formula, data = data, ...)
  structure(list(result = fit, summary = summary(fit)), class = c("omni_stats", "list"))
}

#' Mixed Effects Model
#' @param formula Model formula.
#' @param data Data frame.
#' @param ... Additional arguments.
#' @return Model results.
#' @export
stats_mixed_model <- function(formula, data, ...) {
  if (!requireNamespace("lme4", quietly = TRUE)) {
    # Fallback to simple model
    fit <- lm(formula, data = data, ...)
  } else {
    fit <- lme4::lmer(formula, data = data, ...)
  }
  structure(list(result = fit), class = c("omni_stats", "list"))
}

#' Generalized Linear Model
#' @param formula Model formula.
#' @param data Data frame.
#' @param family Family function.
#' @param ... Additional arguments.
#' @return GLM results.
#' @export
stats_glm <- function(formula, data, family = gaussian(), ...) {
  fit <- glm(formula, data = data, family = family, ...)
  structure(list(result = fit, summary = summary(fit)), class = c("omni_stats", "list"))
}

#' Table 1 (Baseline Characteristics)
#' @param data Data frame.
#' @param strata Stratification variable.
#' @param vars Variables to include.
#' @param ... Additional arguments.
#' @return Table 1 object.
#' @export
stats_table1 <- function(data, strata = NULL, vars = NULL, ...) {
  if (!is.null(strata)) {
    if (!requireNamespace("tableone", quietly = TRUE)) {
      # Simple summary by group
      result <- aggregate(data[, vars], by = list(data[[strata]]), summary)
    } else {
      result <- tableone::CreateTableOne(vars = vars, strata = strata, data = data, ...)
    }
  } else {
    result <- summary(data[, vars])
  }
  structure(list(result = result), class = c("omni_stats", "list"))
}

#' Summary Statistics
#' @param x Vector or data frame.
#' @param by Grouping variable.
#' @param ... Additional arguments.
#' @return Summary statistics.
#' @export
stats_summary <- function(x, by = NULL, ...) {
  if (is.null(by)) {
    result <- summary(x, ...)
  } else {
    result <- by(x, by, summary, ...)
  }
  structure(list(result = result), class = c("omni_stats", "list"))
}

#' Normality Test
#' @param x Numeric vector.
#' @param method Test method: "shapiro", "ks", "ad".
#' @param ... Additional arguments.
#' @return Test results.
#' @export
stats_normality <- function(x, method = "shapiro", ...) {
  fit <- switch(method,
                shapiro = shapiro.test(x),
                ks = ks.test(x, "pnorm", mean(x), sd(x)),
                ad = if (requireNamespace("nortest", quietly = TRUE)) nortest::ad.test(x) else shapiro.test(x))
  structure(list(result = fit, method = method), class = c("omni_stats", "list"))
}

#' Homogeneity of Variance Test
#' @param formula Formula.
#' @param data Data frame.
#' @param method Test method: "bartlett", "levene", "fligner".
#' @return Test results.
#' @export
stats_homogeneity <- function(formula, data, method = "bartlett") {
  fit <- switch(method,
                bartlett = bartlett.test(formula, data),
                levene = if (requireNamespace("car", quietly = TRUE)) car::leveneTest(formula, data) else bartlett.test(formula, data),
                fligner = fligner.test(formula, data))
  structure(list(result = fit, method = method), class = c("omni_stats", "list"))
}

#' Outlier Detection
#' @param x Numeric vector.
#' @param method Detection method: "iqr", "zscore", "mad".
#' @param threshold Threshold value.
#' @return Outlier indices.
#' @export
stats_outlier <- function(x, method = "iqr", threshold = 1.5) {
  outliers <- switch(method,
                     iqr = {
                       q1 <- quantile(x, 0.25); q3 <- quantile(x, 0.75)
                       iqr <- q3 - q1
                       which(x < q1 - threshold * iqr | x > q3 + threshold * iqr)
                     },
                     zscore = which(abs(scale(x)) > threshold),
                     mad = {
                       med <- median(x); mad_val <- mad(x)
                       which(abs(x - med) > threshold * mad_val)
                     })
  structure(list(outliers = outliers, method = method), class = c("omni_stats", "list"))
}

#' Multiple Comparison Correction
#' @param p_values Vector of p-values.
#' @param method Correction method: "bonferroni", "holm", "fdr", "BH".
#' @return Corrected p-values.
#' @export
stats_multiple_comparison <- function(p_values, method = "fdr") {
  adjusted <- p.adjust(p_values, method = method)
  structure(list(original = p_values, adjusted = adjusted, method = method), class = c("omni_stats", "list"))
}

#' Effect Size Calculation
#' @param x Group 1 or formula.
#' @param y Group 2.
#' @param data Data frame.
#' @param type Effect size type: "cohen_d", "hedges_g", "odds_ratio".
#' @return Effect size.
#' @export
stats_effect_size <- function(x, y = NULL, data = NULL, type = "cohen_d") {
  if (type == "cohen_d") {
    if (is.null(y)) {
      # From formula
      vars <- all.vars(x)
      y <- data[[vars[1]]]; x <- data[[vars[2]]]
    }
    mean_diff <- mean(x) - mean(y)
    pooled_sd <- sqrt((var(x) + var(y)) / 2)
    effect <- mean_diff / pooled_sd
  } else if (type == "odds_ratio") {
    if (is.null(y)) {
      vars <- all.vars(x)
      y <- data[[vars[1]]]; x <- data[[vars[2]]]
    }
    tab <- table(x, y)
    effect <- (tab[1,1] * tab[2,2]) / (tab[1,2] * tab[2,1])
  }
  structure(list(effect = effect, type = type), class = c("omni_stats", "list"))
}

#' Confidence Interval
#' @param x Numeric vector or model.
#' @param level Confidence level. Default 0.95.
#' @param ... Additional arguments.
#' @return Confidence interval.
#' @export
stats_ci <- function(x, level = 0.95, ...) {
  if (is.numeric(x)) {
    fit <- t.test(x, conf.level = level, ...)
    ci <- fit$conf.int
  } else {
    ci <- confint(x, level = level, ...)
  }
  structure(list(ci = ci, level = level), class = c("omni_stats", "list"))
}

#' Odds Ratio and Risk Ratio
#' @param exposed_cases Cases in exposed group.
#' @param exposed_controls Controls in exposed group.
#' @param unexposed_cases Cases in unexposed group.
#' @param unexposed_controls Controls in unexposed group.
#' @return OR and RR.
#' @export
stats_or_rr <- function(exposed_cases, exposed_controls, unexposed_cases, unexposed_controls) {
  or <- (exposed_cases * unexposed_controls) / (exposed_controls * unexposed_cases)
  rr <- (exposed_cases / (exposed_cases + exposed_controls)) / (unexposed_cases / (unexposed_cases + unexposed_controls))
  
  se_log_or <- sqrt(1/exposed_cases + 1/exposed_controls + 1/unexposed_cases + 1/unexposed_controls)
  ci_lower <- exp(log(or) - 1.96 * se_log_or)
  ci_upper <- exp(log(or) + 1.96 * se_log_or)
  
  structure(list(OR = or, RR = rr, ci_lower = ci_lower, ci_upper = ci_upper), class = c("omni_stats", "list"))
}

#' ROC Analysis
#' @param actual Actual labels.
#' @param predicted Predicted probabilities.
#' @param positive Positive class.
#' @return ROC results.
#' @export
stats_roc_analysis <- function(actual, predicted, positive = NULL) {
  if (!requireNamespace("pROC", quietly = TRUE)) {
    stop("pROC package required")
  }
  roc_obj <- pROC::roc(actual, predicted, quiet = TRUE)
  structure(list(roc = roc_obj, auc = pROC::auc(roc_obj)), class = c("omni_stats", "list"))
}

#' Survival Curve (Kaplan-Meier)
#' @param formula Surv object formula.
#' @param data Data frame.
#' @param ... Additional arguments.
#' @return Survival fit.
#' @export
stats_survival_curve <- function(formula, data, ...) {
  if (!requireNamespace("survival", quietly = TRUE)) {
    stop("survival package required")
  }
  fit <- survival::survfit(formula, data = data, ...)
  structure(list(result = fit), class = c("omni_stats", "list"))
}

#' Kaplan-Meier Plot
#' @param fit Survival fit object.
#' @param data Data frame.
#' @param conf.int Show confidence interval. Default TRUE.
#' @param ... Additional arguments.
#' @return ggplot object.
#' @export
stats_km_plot <- function(fit, data, conf.int = TRUE, ...) {
  if (!requireNamespace("survminer", quietly = TRUE)) {
    # Simple plot
    df <- data.frame(time = fit$time, surv = fit$surv)
    p <- ggplot2::ggplot(df, ggplot2::aes(x = time, y = surv)) +
      ggplot2::geom_step() +
      ggplot2::labs(title = "Kaplan-Meier Curve", x = "Time", y = "Survival Probability") +
      ggplot2::theme_minimal()
  } else {
    p <- survminer::ggsurvplot(fit, data = data, conf.int = conf.int, ...)
  }
  p
}

#' Log-Rank Test
#' @param formula Formula.
#' @param data Data frame.
#' @param ... Additional arguments.
#' @return Test results.
#' @export
stats_logrank <- function(formula, data, ...) {
  if (!requireNamespace("survival", quietly = TRUE)) {
    stop("survival package required")
  }
  fit <- survival::survdiff(formula, data = data, ...)
  structure(list(result = fit), class = c("omni_stats", "list"))
}

#' C-Index (Harrell's Concordance Index)
#' @param actual Actual survival object.
#' @param predicted Predicted risk scores.
#' @return C-index.
#' @export
stats_c_index <- function(actual, predicted) {
  if (!requireNamespace("survival", quietly = TRUE)) {
    stop("survival package required")
  }
  c_index <- survival::concordance(actual ~ predicted)$concordance
  structure(list(c_index = c_index), class = c("omni_stats", "list"))
}

#' Calibration Analysis
#' @param actual Actual outcomes.
#' @param predicted Predicted probabilities.
#' @param n_bins Number of bins. Default 10.
#' @return Calibration data.
#' @export
stats_calibration <- function(actual, predicted, n_bins = 10) {
  bin_edges <- quantile(predicted, probs = seq(0, 1, length.out = n_bins + 1))
  bin_edges[1] <- 0; bin_edges[length(bin_edges)] <- 1
  bins <- cut(predicted, breaks = bin_edges, include.lowest = TRUE)
  
  cal_df <- data.frame(
    bin = levels(bins),
    predicted = tapply(predicted, bins, mean),
    observed = tapply(actual, bins, mean),
    n = table(bins)
  )
  structure(list(result = cal_df), class = c("omni_stats", "list"))
}

#' Discrimination Analysis (AUC with CI)
#' @param actual Actual labels.
#' @param predicted Predicted probabilities.
#' @return AUC with confidence interval.
#' @export
stats_discrimination <- function(actual, predicted) {
  if (!requireNamespace("pROC", quietly = TRUE)) {
    stop("pROC package required")
  }
  roc_obj <- pROC::roc(actual, predicted, quiet = TRUE)
  ci <- pROC::ci.auc(roc_obj)
  structure(list(auc = pROC::auc(roc_obj), ci = ci), class = c("omni_stats", "list"))
}

#' Bootstrap Confidence Interval
#' @param data Data.
#' @param statistic Function to compute statistic.
#' @param R Number of bootstrap replicates. Default 1000.
#' @param ... Additional arguments.
#' @return Bootstrap results.
#' @export
stats_bootstrap <- function(data, statistic, R = 1000, ...) {
  boot_results <- replicate(R, statistic(sample(data, replace = TRUE), ...))
  ci <- quantile(boot_results, c(0.025, 0.975))
  structure(list(estimate = mean(boot_results), ci = ci, R = R), class = c("omni_stats", "list"))
}

#' Permutation Test
#' @param x Group 1.
#' @param y Group 2.
#' @param statistic Test statistic function.
#' @param n_perm Number of permutations. Default 1000.
#' @return Permutation test results.
#' @export
stats_permutation <- function(x, y, statistic = mean, n_perm = 1000) {
  observed_diff <- statistic(x) - statistic(y)
  pooled <- c(x, y)
  n_x <- length(x)
  
  perm_diffs <- replicate(n_perm, {
    perm <- sample(pooled)
    statistic(perm[1:n_x]) - statistic(perm[(n_x + 1):length(pooled)])
  })
  
  p_value <- mean(abs(perm_diffs) >= abs(observed_diff))
  structure(list(observed = observed_diff, p_value = p_value, n_perm = n_perm), class = c("omni_stats", "list"))
}

#' Sensitivity and Specificity
#' @param actual Actual labels.
#' @param predicted Predicted labels.
#' @param positive Positive class.
#' @return Sensitivity and specificity.
#' @export
stats_sensitivity <- function(actual, predicted, positive = NULL) {
  cm <- table(Predicted = predicted, Actual = actual)
  sens <- cm[2, 2] / sum(cm[, 2])
  spec <- cm[1, 1] / sum(cm[, 1])
  structure(list(sensitivity = sens, specificity = spec), class = c("omni_stats", "list"))
}

#' Specificity
#' @param actual Actual labels.
#' @param predicted Predicted labels.
#' @param positive Positive class.
#' @return Specificity.
#' @export
stats_specificity <- function(actual, predicted, positive = NULL) {
  stats_sensitivity(actual, predicted, positive)$specificity
}

#' PPV and NPV
#' @param actual Actual labels.
#' @param predicted Predicted labels.
#' @return PPV and NPV.
#' @export
stats_ppv_npv <- function(actual, predicted) {
  cm <- table(Predicted = predicted, Actual = actual)
  ppv <- cm[2, 2] / sum(cm[2, ])
  npv <- cm[1, 1] / sum(cm[1, ])
  structure(list(PPV = ppv, NPV = npv), class = c("omni_stats", "list"))
}

#' AUC Confidence Interval
#' @param actual Actual labels.
#' @param predicted Predicted probabilities.
#' @return AUC with CI.
#' @export
stats_auc_ci <- function(actual, predicted) {
  stats_discrimination(actual, predicted)
}

#' NRI and IDI
#' @param actual Actual outcomes.
#' @param pred_old Predictions from old model.
#' @param pred_new Predictions from new model.
#' @param cutoffs Cutoff points.
#' @return NRI and IDI.
#' @export
stats_nri_idi <- function(actual, pred_old, pred_new, cutoffs = c(0, 0.2, 0.4, 0.6, 0.8, 1)) {
  # Simplified calculation
  nri_events <- mean((pred_new > pred_old)[actual == 1]) - mean((pred_new < pred_old)[actual == 1])
  nri_nonevents <- mean((pred_new < pred_old)[actual == 0]) - mean((pred_new > pred_old)[actual == 0])
  nri <- nri_events + nri_nonevents
  
  idi <- mean(pred_new[actual == 1]) - mean(pred_old[actual == 1]) -
    (mean(pred_new[actual == 0]) - mean(pred_old[actual == 0]))
  
  structure(list(NRI = nri, IDI = idi), class = c("omni_stats", "list"))
}

#' Decision Curve Analysis
#' @param actual Actual outcomes.
#' @param predicted Predicted probabilities.
#' @param thresholds Threshold range.
#' @return DCA data.
#' @export
stats_dca <- function(actual, predicted, thresholds = seq(0, 1, by = 0.01)) {
  prevalence <- mean(actual)
  
  dca_df <- data.frame(
    threshold = thresholds,
    treat_all = prevalence - (1 - prevalence) * thresholds / (1 - thresholds),
    treat_none = 0
  )
  
  # Calculate net benefit for model
  dca_df$model <- sapply(thresholds, function(th) {
    tp <- sum(predicted >= th & actual == 1)
    fp <- sum(predicted >= th & actual == 0)
    n <- length(actual)
    (tp / n) - (fp / n) * (th / (1 - th))
  })
  
  structure(list(result = dca_df), class = c("omni_stats", "list"))
}
