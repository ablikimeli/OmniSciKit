#' @importFrom stats heatmap
#' @importFrom utils globalVariables
globalVariables(c('Sample', 'Gene', 'Expression'))

#' PCA Analysis
#'
#' Principal Component Analysis for omics data.
#'
#' @param data Matrix or data frame (samples x features).
#' @param scale Logical to scale features.
#' @return List with PCA results.
#' @examples
#' # Example 1: Basic usage with expression data
#' data(omni_expression)
#' result <- omics_pca(t(omni_expression))
#' print(result)
#'
#' # Example 2: Plot variance explained
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   var_df <- data.frame(
#'     PC = 1:min(10, length(result$variance_explained)),
#'     Variance = result$variance_explained[1:min(10, length(result$variance_explained))]
#'   )
#'   p <- ggplot2::ggplot(var_df, ggplot2::aes(x = PC, y = Variance)) +
#'     ggplot2::geom_bar(stat = "identity", fill = "steelblue") +
#'     ggplot2::labs(title = "PCA Variance Explained")
#'   print(p)
#' }
#'
#' # Example 3: Plot PC1 vs PC2
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   pc_df <- data.frame(PC1 = result$scores[, 1], PC2 = result$scores[, 2])
#'   p <- ggplot2::ggplot(pc_df, ggplot2::aes(x = PC1, y = PC2)) +
#'     ggplot2::geom_point(size = 3, color = "darkblue") +
#'     ggplot2::labs(title = "PCA: PC1 vs PC2")
#'   print(p)
#' }
#' @export
omics_pca <- function(data, scale = TRUE) {
  pca <- prcomp(data, scale. = scale)
  
  result <- list(
    scores = pca$x,
    loadings = pca$rotation,
    variance_explained = (pca$sdev^2) / sum(pca$sdev^2) * 100,
    cumulative_variance = cumsum((pca$sdev^2) / sum(pca$sdev^2)) * 100,
    sdev = pca$sdev,
    pca_obj = pca
  )
  class(result) <- "omni_omics"
  return(result)
}

#' Data Normalization
#'
#' Normalize omics data using various methods.
#'
#' @param data Matrix or data frame.
#' @param method Method: "zscore", "minmax", "log".
#' @return List with normalized data.
#' @examples
#' # Example 1: Z-score normalization
#' data(omni_expression)
#' result <- omics_normalize(omni_expression, method = "zscore")
#' summary(result$normalized[1, ])
#'
#' # Example 2: Min-max normalization
#' result <- omics_normalize(omni_expression, method = "minmax")
#' cat("Range:", range(result$normalized), "\n")
#'
#' # Example 3: Compare before/after
#' par(mfrow = c(1, 2))
#' boxplot(omni_expression[1:10, ], main = "Original", las = 2)
#' boxplot(result$normalized[1:10, ], main = "Normalized", las = 2)
#' @export
omics_normalize <- function(data, method = "zscore") {
  if (method == "zscore") {
    normalized <- scale(data)
  } else if (method == "minmax") {
    normalized <- apply(data, 1, function(x) (x - min(x)) / (max(x) - min(x)))
    normalized <- t(normalized)
  } else if (method == "log") {
    normalized <- log2(data + 1)
  } else {
    stop("Unknown method. Use 'zscore', 'minmax', or 'log'")
  }
  
  list(
    normalized = normalized,
    method = method,
    original_dim = dim(data)
  )
}

#' Log2 Transformation
#'
#' Apply log2 transformation to omics data.
#'
#' @param data Matrix or data frame.
#' @param pseudo_count Pseudo-count to add (default 1).
#' @return List with transformed data.
#' @examples
#' # Example 1: Basic usage
#' data(omni_expression)
#' result <- omics_log2(omni_expression)
#' summary(result$transformed)
#'
#' # Example 2: Check distribution
#' par(mfrow = c(1, 2))
#' hist(omni_expression[1, ], main = "Original", breaks = 20)
#' hist(result$transformed[1, ], main = "Log2 Transformed", breaks = 20)
#'
#' # Example 3: Different pseudo-count
#' result <- omics_log2(omni_expression, pseudo_count = 0.5)
#' summary(result$transformed)
#' @export
omics_log2 <- function(data, pseudo_count = 1) {
  transformed <- log2(data + pseudo_count)
  list(
    transformed = transformed,
    pseudo_count = pseudo_count,
    original_range = range(data)
  )
}

#' Quality Control
#'
#' QC metrics for omics data.
#'
#' @param data Matrix or data frame.
#' @return List with QC metrics.
#' @examples
#' # Example 1: Basic QC
#' data(omni_expression)
#' result <- omics_qc(omni_expression)
#' print(result)
#'
#' # Example 2: Visualize sample quality
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   qc_df <- data.frame(
#'     Sample = colnames(omni_expression),
#'     Mean = colMeans(omni_expression),
#'     SD = apply(omni_expression, 2, sd)
#'   )
#'   p <- ggplot2::ggplot(qc_df, ggplot2::aes(x = Mean, y = SD)) +
#'     ggplot2::geom_point(size = 3, color = "blue") +
#'     ggplot2::labs(title = "Sample QC: Mean vs SD")
#'   print(p)
#' }
#'
#' # Example 3: Detect outliers
#' outliers <- which(result$sample_means > 
#'                   mean(result$sample_means) + 2*sd(result$sample_means))
#' cat("Outlier samples:", paste(outliers, collapse = ", "), "\n")
#' @export
omics_qc <- function(data) {
  sample_means <- colMeans(data, na.rm = TRUE)
  sample_sds <- apply(data, 2, sd, na.rm = TRUE)
  sample_meds <- apply(data, 2, median, na.rm = TRUE)
  
  gene_means <- rowMeans(data, na.rm = TRUE)
  gene_sds <- apply(data, 1, sd, na.rm = TRUE)
  
  result <- list(
    n_samples = ncol(data),
    n_genes = nrow(data),
    sample_means = sample_means,
    sample_sds = sample_sds,
    sample_meds = sample_meds,
    gene_means = gene_means,
    gene_sds = gene_sds,
    missing_pct = sum(is.na(data)) / prod(dim(data)) * 100
  )
  class(result) <- "omni_omics"
  return(result)
}

#' Heatmap Visualization
#'
#' Create heatmap for omics data.
#'
#' @param data Matrix or data frame.
#' @param scale Scale rows (default TRUE).
#' @param main Plot title.
#' @return None (plotting function).
#' @examples
#' # Example 1: Basic heatmap
#' data(omni_expression)
#' omics_heatmap(omni_expression[1:20, 1:10])
#'
#' # Example 2: With title
#' omics_heatmap(omni_expression[1:20, 1:10], 
#'               main = "Gene Expression Heatmap")
#'
#' # Example 3: Without scaling
#' omics_heatmap(omni_expression[1:20, 1:10], scale = FALSE,
#'               main = "Original Values")
#' @export
omics_heatmap <- function(data, scale = TRUE, main = "Heatmap") {
  if (requireNamespace("ggplot2", quietly = TRUE) && 
      requireNamespace("reshape2", quietly = TRUE)) {
    df <- reshape2::melt(data)
    colnames(df) <- c("Gene", "Sample", "Expression")
    
    p <- ggplot2::ggplot(df, ggplot2::aes(x = Sample, y = Gene, fill = Expression)) +
      ggplot2::geom_tile() +
      ggplot2::scale_fill_gradient2(low = "blue", mid = "white", high = "red") +
      ggplot2::theme_minimal() +
      ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90)) +
      ggplot2::labs(title = main)
    print(p)
  } else {
    if (scale) {
      data <- t(scale(t(data)))
    }
    heatmap(data, main = main, col = heat.colors(100))
  }
}

#' Differential Expression
#'
#' Simple differential expression analysis.
#'
#' @param data Expression matrix (genes x samples).
#' @param group Factor indicating groups.
#' @param method Method: "t.test" or "wilcoxon".
#' @return Data frame with DE results.
#' @examples
#' # Example 1: Basic DE analysis
#' data(omni_expression)
#' group <- factor(rep(c("Control", "Treatment"), each = 10))
#' result <- omics_de(omni_expression, group)
#' head(result)
#'
#' # Example 2: Volcano plot
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   result$significant <- result$p_value < 0.05
#'   p <- ggplot2::ggplot(result, ggplot2::aes(x = logFC, y = -log10(p_value))) +
#'     ggplot2::geom_point(ggplot2::aes(color = significant)) +
#'     ggplot2::scale_color_manual(values = c("grey", "red")) +
#'     ggplot2::labs(title = "Volcano Plot")
#'   print(p)
#' }
#'
#' # Example 3: Top DE genes
#' top_genes <- head(result[order(result$p_value), ], 10)
#' print(top_genes)
#' @export
omics_de <- function(data, group, method = "t.test") {
  results <- data.frame(
    gene = rownames(data),
    logFC = NA,
    p_value = NA,
    mean_group1 = NA,
    mean_group2 = NA
  )
  
  for (i in 1:nrow(data)) {
    g1 <- data[i, group == levels(group)[1]]
    g2 <- data[i, group == levels(group)[2]]
    
    results$mean_group1[i] <- mean(g1, na.rm = TRUE)
    results$mean_group2[i] <- mean(g2, na.rm = TRUE)
    results$logFC[i] <- log2(mean(g2, na.rm = TRUE) / mean(g1, na.rm = TRUE))
    
    if (method == "t.test") {
      res <- t.test(g1, g2)
      results$p_value[i] <- res$p.value
    } else {
      res <- wilcox.test(g1, g2)
      results$p_value[i] <- res$p.value
    }
  }
  
  results$adj_p_value <- p.adjust(results$p_value, method = "fdr")
  return(results)
}

#' Print Method for Omics Results
#'
#' @param x omni_omics object.
#' @param ... Additional arguments (not used).
#' @examples
#' result <- omics_pca(t(omni_expression))
#' print(result)
#' @export
print.omni_omics <- function(x, ...) {
  cat("\n=== Omics Analysis Results ===\n")
  if (!is.null(x$variance_explained)) {
    cat("Variance explained by PC1:", round(x$variance_explained[1], 2), "%\n")
    cat("Cumulative variance (PC1-3):", round(x$cumulative_variance[3], 2), "%\n")
  }
  if (!is.null(x$n_samples)) {
    cat("Samples:", x$n_samples, "| Genes:", x$n_genes, "\n")
    cat("Missing values:", round(x$missing_pct, 2), "%\n")
  }
  if (!is.null(x$method)) {
    cat("Method:", x$method, "\n")
  }
  cat("\n")
}

