#' Bioinformatics Analysis Module
#'
#' @description
#' Provides comprehensive tools for multi-omics data analysis including
#' differential expression, pathway enrichment, and data visualization.
#'
#' @name omics
#' @keywords internal
NULL

#' DESeq2 Differential Expression Analysis
#'
#' Performs differential expression analysis using DESeq2.
#'
#' @param count_matrix Raw count matrix (genes x samples).
#' @param sample_info Data frame with sample information.
#' @param design_formula Design formula for the comparison.
#' @param contrast Contrast for the comparison.
#' @param alpha Significance threshold. Default is 0.05.
#'
#' @return DESeq2 results object
#' @export
#'
#' @examples
#' \dontrun{
#' # Create example data
#' counts <- matrix(rpois(1000, 100), nrow = 100, ncol = 10)
#' colnames(counts) <- paste0("sample", 1:10)
#' rownames(counts) <- paste0("gene", 1:100)
#' 
#' sample_info <- data.frame(
#'   condition = factor(rep(c("control", "treatment"), each = 5)),
#'   row.names = colnames(counts)
#' )
#' 
#' # Run DESeq2
#' result <- omics_deseq2(counts, sample_info, ~condition, c("condition", "treatment", "control"))
#' }
omics_deseq2 <- function(count_matrix, sample_info, design_formula, contrast, alpha = 0.05) {
  if (!requireNamespace("DESeq2", quietly = TRUE)) {
    stop("DESeq2 package is required. Install with: install_omni('bioinformatics')")
  }
  
  # Create DESeqDataSet
  dds <- DESeq2::DESeqDataSetFromMatrix(
    countData = count_matrix,
    colData = sample_info,
    design = design_formula
  )
  
  # Run DESeq2
  dds <- DESeq2::DESeq(dds)
  
  # Get results
  res <- DESeq2::results(dds, contrast = contrast, alpha = alpha)
  
  # Add summary
  summary_res <- DESeq2::summary(res)
  
  # Return results
  structure(list(
    results = res,
    dds = dds,
    summary = summary_res,
    contrast = contrast,
    alpha = alpha
  ), class = c("omni_deseq2", "list"))
}

#' edgeR Differential Expression Analysis
#'
#' Performs differential expression analysis using edgeR.
#'
#' @param count_matrix Raw count matrix (genes x samples).
#' @param group Factor indicating group membership.
#' @param contrast Contrast for the comparison.
#' @param method Method for differential expression. Default is "exact".
#'
#' @return edgeR results object
#' @export
#'
#' @examples
#' \dontrun{
#' counts <- matrix(rpois(1000, 100), nrow = 100, ncol = 10)
#' group <- factor(rep(c("A", "B"), each = 5))
#' result <- omics_edger(counts, group)
#' }
omics_edger <- function(count_matrix, group, contrast = NULL, method = "exact") {
  if (!requireNamespace("edgeR", quietly = TRUE)) {
    stop("edgeR package is required. Install with: install_omni('bioinformatics')")
  }
  
  # Create DGEList
  dge <- edgeR::DGEList(counts = count_matrix, group = group)
  
  # Filter lowly expressed genes
  keep <- edgeR::filterByExpr(dge)
  dge <- dge[keep, , keep.lib.sizes = FALSE]
  
  # Normalize
  dge <- edgeR::calcNormFactors(dge)
  
  # Estimate dispersion
  dge <- edgeR::estimateDisp(dge)
  
  # Perform differential expression
  if (method == "exact") {
    et <- edgeR::exactTest(dge, pair = contrast)
  } else {
    design <- model.matrix(~0 + group)
    fit <- edgeR::glmFit(dge, design)
    et <- edgeR::glmLRT(fit, contrast = contrast)
  }
  
  # Return results
  structure(list(
    results = et,
    dge = dge,
    method = method,
    contrast = contrast
  ), class = c("omni_edger", "list"))
}

#' limma Differential Expression Analysis
#'
#' Performs differential expression analysis using limma-voom.
#'
#' @param count_matrix Raw count matrix (genes x samples).
#' @param sample_info Data frame with sample information.
#' @param design Design matrix.
#' @param contrast Contrast matrix.
#'
#' @return limma results object
#' @export
#'
#' @examples
#' \dontrun{
#' counts <- matrix(rpois(1000, 100), nrow = 100, ncol = 10)
#' group <- factor(rep(c("A", "B"), each = 5))
#' design <- model.matrix(~0 + group)
#' contrast <- makeContrasts(BvsA = groupB - groupA, levels = design)
#' result <- omics_limma(counts, design = design, contrast = contrast)
#' }
omics_limma <- function(count_matrix, sample_info = NULL, design = NULL, contrast = NULL) {
  if (!requireNamespace("limma", quietly = TRUE)) {
    stop("limma package is required. Install with: install_omni('bioinformatics')")
  }
  
  # Create DGEList
  dge <- edgeR::DGEList(counts = count_matrix)
  
  # Normalize
  dge <- edgeR::calcNormFactors(dge)
  
  # Create design matrix if not provided
  if (is.null(design) && !is.null(sample_info)) {
    design <- model.matrix(~0 + ., data = sample_info)
  }
  
  # Voom transformation
  v <- limma::voom(dge, design)
  
  # Fit linear model
  fit <- limma::lmFit(v, design)
  
  # Apply contrasts
  if (!is.null(contrast)) {
    fit <- limma::contrasts.fit(fit, contrast)
  }
  
  # Empirical Bayes
  fit <- limma::eBayes(fit)
  
  # Return results
  structure(list(
    results = fit,
    voom = v,
    design = design,
    contrast = contrast
  ), class = c("omni_limma", "list"))
}

#' Volcano Plot
#'
#' Creates a volcano plot for differential expression results.
#'
#' @param de_results Differential expression results (data frame with logFC and p-value columns).
#' @param fc_col Column name for log fold change. Default is "log2FoldChange".
#' @param p_col Column name for p-value. Default is "padj".
#' @param fc_threshold Fold change threshold. Default is 1.
#' @param p_threshold P-value threshold. Default is 0.05.
#' @param title Plot title.
#' @param label_genes Vector of gene names to label.
#' @param max_labels Maximum number of genes to label. Default is 20.
#'
#' @return ggplot object
#' @export
#'
#' @examples
#' \dontrun{
#' # Create example results
#' results <- data.frame(
#'   log2FoldChange = rnorm(1000),
#'   padj = runif(1000)
#' )
#' 
#' # Create volcano plot
#' p <- omics_volcano(results)
#' print(p)
#' }
omics_volcano <- function(de_results, fc_col = "log2FoldChange", p_col = "padj",
                          fc_threshold = 1, p_threshold = 0.05,
                          title = "Volcano Plot", label_genes = NULL,
                          max_labels = 20) {
  # Extract columns
  logFC <- de_results[[fc_col]]
  pvalue <- de_results[[p_col]]
  
  # Create significance categories
  de_results$significance <- "Not Significant"
  de_results$significance[abs(logFC) > fc_threshold & pvalue < p_threshold] <- "Significant"
  de_results$significance[logFC > fc_threshold & pvalue < p_threshold] <- "Up-regulated"
  de_results$significance[logFC < -fc_threshold & pvalue < p_threshold] <- "Down-regulated"
  
  # Create plot
  p <- ggplot2::ggplot(de_results, ggplot2::aes(x = logFC, y = -log10(pvalue), color = significance)) +
    ggplot2::geom_point(alpha = 0.6, size = 1.5) +
    ggplot2::scale_color_manual(values = c(
      "Not Significant" = "grey50",
      "Significant" = "blue",
      "Up-regulated" = "red",
      "Down-regulated" = "green"
    )) +
    ggplot2::geom_vline(xintercept = c(-fc_threshold, fc_threshold), linetype = "dashed", color = "grey") +
    ggplot2::geom_hline(yintercept = -log10(p_threshold), linetype = "dashed", color = "grey") +
    ggplot2::labs(
      title = title,
      x = "Log2 Fold Change",
      y = "-Log10 Adjusted P-value",
      color = "Significance"
    ) +
    ggplot2::theme_minimal()
  
  # Add gene labels if specified
  if (!is.null(label_genes)) {
    label_data <- de_results[rownames(de_results) %in% label_genes, ]
    if (nrow(label_data) > 0) {
      p <- p + ggplot2::geom_text(
        data = label_data,
        ggplot2::aes(label = rownames(label_data)),
        size = 3, vjust = -0.5, hjust = 0.5
      )
    }
  }
  
  p
}

#' Heatmap Visualization
#'
#' Creates a heatmap for gene expression data.
#'
#' @param expression_matrix Expression matrix (genes x samples).
#' @param sample_info Sample information for annotation.
#' @param gene_list List of genes to include. If NULL, uses all genes.
#' @param scale Scaling method: "row", "column", or "none".
#' @param cluster_rows Whether to cluster rows. Default is TRUE.
#' @param cluster_cols Whether to cluster columns. Default is TRUE.
#' @param show_rownames Whether to show row names. Default is FALSE.
#' @param show_colnames Whether to show column names. Default is TRUE.
#' @param title Plot title.
#'
#' @return ComplexHeatmap object or ggplot object
#' @export
#'
#' @examples
#' \dontrun{
#' expr <- matrix(rnorm(1000), nrow = 100, ncol = 10)
#' p <- omics_heatmap(expr)
#' }
omics_heatmap <- function(expression_matrix, sample_info = NULL, gene_list = NULL,
                          scale = "row", cluster_rows = TRUE, cluster_cols = TRUE,
                          show_rownames = FALSE, show_colnames = TRUE,
                          title = "Expression Heatmap") {
  # Subset genes if specified
  if (!is.null(gene_list)) {
    expression_matrix <- expression_matrix[gene_list, , drop = FALSE]
  }
  
  # Scale data
  if (scale == "row") {
    expression_matrix <- t(scale(t(expression_matrix)))
  } else if (scale == "column") {
    expression_matrix <- scale(expression_matrix)
  }
  
  # Try to use ComplexHeatmap if available
  if (requireNamespace("ComplexHeatmap", quietly = TRUE)) {
    # Create heatmap annotation
    if (!is.null(sample_info)) {
      ha <- ComplexHeatmap::HeatmapAnnotation(df = sample_info)
    } else {
      ha <- NULL
    }
    
    # Create heatmap
    ht <- ComplexHeatmap::Heatmap(
      expression_matrix,
      name = "Expression",
      cluster_rows = cluster_rows,
      cluster_columns = cluster_cols,
      show_row_names = show_rownames,
      show_column_names = show_colnames,
      top_annotation = ha,
      column_title = title
    )
    
    return(ht)
  } else {
    # Fallback to ggplot2
    # Convert to long format
    df <- as.data.frame(expression_matrix)
    df$gene <- rownames(df)
    df_long <- tidyr::pivot_longer(df, cols = -gene, names_to = "sample", values_to = "expression")
    
    # Create heatmap
    p <- ggplot2::ggplot(df_long, ggplot2::aes(x = sample, y = gene, fill = expression)) +
      ggplot2::geom_tile() +
      ggplot2::scale_fill_gradient2(low = "blue", mid = "white", high = "red") +
      ggplot2::labs(title = title, x = "Sample", y = "Gene") +
      ggplot2::theme_minimal() +
      ggplot2::theme(
        axis.text.y = if (show_rownames) ggplot2::element_text() else ggplot2::element_blank(),
        axis.text.x = if (show_colnames) ggplot2::element_text(angle = 45, hjust = 1) else ggplot2::element_blank()
      )
    
    return(p)
  }
}

#' PCA Analysis and Visualization
#'
#' Performs PCA on expression data and creates visualization.
#'
#' @param expression_matrix Expression matrix (genes x samples).
#' @param sample_info Sample information for coloring.
#' @param color_by Column in sample_info to color by.
#' @param shape_by Column in sample_info to shape by.
#' @param n_top_genes Number of top variable genes to use. Default is 500.
#' @param scale Whether to scale data. Default is TRUE.
#' @param pc_x PC to plot on x-axis. Default is 1.
#' @param pc_y PC to plot on y-axis. Default is 2.
#' @param title Plot title.
#'
#' @return ggplot object
#' @export
#'
#' @examples
#' \dontrun{
#' expr <- matrix(rnorm(1000), nrow = 100, ncol = 10)
#' sample_info <- data.frame(group = rep(c("A", "B"), each = 5))
#' p <- omics_pca(expr, sample_info, color_by = "group")
#' }
omics_pca <- function(expression_matrix, sample_info = NULL, color_by = NULL,
                      shape_by = NULL, n_top_genes = 500, scale = TRUE,
                      pc_x = 1, pc_y = 2, title = "PCA Plot") {
  # Select top variable genes
  if (nrow(expression_matrix) > n_top_genes) {
    var_genes <- apply(expression_matrix, 1, var)
    top_genes <- names(sort(var_genes, decreasing = TRUE))[1:n_top_genes]
    expression_matrix <- expression_matrix[top_genes, , drop = FALSE]
  }
  
  # Transpose for PCA (samples x genes)
  expr_t <- t(expression_matrix)
  
  # Perform PCA
  pca_result <- prcomp(expr_t, scale. = scale)
  
  # Extract PC scores
  pc_data <- as.data.frame(pca_result$x[, c(pc_x, pc_y)])
  colnames(pc_data) <- c("PC1", "PC2")
  
  # Add sample information
  if (!is.null(sample_info)) {
    pc_data <- cbind(pc_data, sample_info)
  }
  
  # Calculate variance explained
  var_explained <- summary(pca_result)$importance[2, c(pc_x, pc_y)] * 100
  
  # Create plot
  p <- ggplot2::ggplot(pc_data, ggplot2::aes(x = PC1, y = PC2))
  
  # Add color and shape aesthetics
  if (!is.null(color_by)) {
    p <- p + ggplot2::aes_string(color = color_by)
  }
  if (!is.null(shape_by)) {
    p <- p + ggplot2::aes_string(shape = shape_by)
  }
  
  p <- p +
    ggplot2::geom_point(size = 3, alpha = 0.7) +
    ggplot2::labs(
      title = title,
      x = paste0("PC", pc_x, " (", round(var_explained[1], 1), "%)"),
      y = paste0("PC", pc_y, " (", round(var_explained[2], 1), "%)"),
      color = color_by,
      shape = shape_by
    ) +
    ggplot2::theme_minimal()
  
  # Add labels if sample names are available
  if (!is.null(colnames(expression_matrix))) {
    p <- p + ggplot2::geom_text(
      ggplot2::aes(label = colnames(expression_matrix)),
      vjust = -0.5, hjust = 0.5, size = 3
    )
  }
  
  p
}

#' KEGG Pathway Enrichment
#'
#' Performs KEGG pathway enrichment analysis.
#'
#' @param gene_list List of genes (Entrez IDs or gene symbols).
#' @param organism Organism code. Default is "hsa" (human).
#' @param pvalueCutoff P-value cutoff. Default is 0.05.
#' @param qvalueCutoff Q-value cutoff. Default is 0.2.
#' @param minGSSize Minimum gene set size. Default is 10.
#' @param maxGSSize Maximum gene set size. Default is 500.
#'
#' @return enrichment result object
#' @export
#'
#' @examples
#' \dontrun{
#' genes <- c("TP53", "BRCA1", "EGFR", "MYC", "KRAS")
#' result <- omics_kegg(genes)
#' }
omics_kegg <- function(gene_list, organism = "hsa", pvalueCutoff = 0.05,
                       qvalueCutoff = 0.2, minGSSize = 10, maxGSSize = 500) {
  if (!requireNamespace("clusterProfiler", quietly = TRUE)) {
    stop("clusterProfiler package is required. Install with: install_omni('bioinformatics')")
  }
  
  # Perform KEGG enrichment
  kk <- clusterProfiler::enrichKEGG(
    gene = gene_list,
    organism = organism,
    pvalueCutoff = pvalueCutoff,
    qvalueCutoff = qvalueCutoff,
    minGSSize = minGSSize,
    maxGSSize = maxGSSize
  )
  
  structure(list(
    results = kk,
    organism = organism,
    gene_list = gene_list
  ), class = c("omni_kegg", "list"))
}

#' GO Enrichment Analysis
#'
#' Performs Gene Ontology enrichment analysis.
#'
#' @param gene_list List of genes (Entrez IDs or gene symbols).
#' @param ont GO ontology: "BP", "CC", "MF", or "ALL".
#' @param organism Organism. Default is "org.Hs.eg.db".
#' @param pvalueCutoff P-value cutoff. Default is 0.05.
#' @param qvalueCutoff Q-value cutoff. Default is 0.2.
#' @param minGSSize Minimum gene set size. Default is 10.
#' @param maxGSSize Maximum gene set size. Default is 500.
#'
#' @return enrichment result object
#' @export
#'
#' @examples
#' \dontrun{
#' genes <- c("TP53", "BRCA1", "EGFR", "MYC", "KRAS")
#' result <- omics_go(genes, ont = "BP")
#' }
omics_go <- function(gene_list, ont = "BP", organism = "org.Hs.eg.db",
                     pvalueCutoff = 0.05, qvalueCutoff = 0.2,
                     minGSSize = 10, maxGSSize = 500) {
  if (!requireNamespace("clusterProfiler", quietly = TRUE)) {
    stop("clusterProfiler package is required. Install with: install_omni('bioinformatics')")
  }
  
  # Perform GO enrichment
  go <- clusterProfiler::enrichGO(
    gene = gene_list,
    OrgDb = organism,
    ont = ont,
    pvalueCutoff = pvalueCutoff,
    qvalueCutoff = qvalueCutoff,
    minGSSize = minGSSize,
    maxGSSize = maxGSSize,
    readable = TRUE
  )
  
  structure(list(
    results = go,
    ont = ont,
    organism = organism,
    gene_list = gene_list
  ), class = c("omni_go", "list"))
}

#' GSEA Analysis
#'
#' Performs Gene Set Enrichment Analysis.
#'
#' @param gene_list Named vector of gene statistics (e.g., logFC), sorted in decreasing order.
#' @param gene_set Gene set to test. Can be a GMT file path or a list of gene sets.
#' @param organism Organism. Default is "human".
#' @param pvalueCutoff P-value cutoff. Default is 0.05.
#' @param minGSSize Minimum gene set size. Default is 10.
#' @param maxGSSize Maximum gene set size. Default is 500.
#'
#' @return GSEA result object
#' @export
#'
#' @examples
#' \dontrun{
#' # Create ranked gene list
#' gene_stats <- sort(rnorm(1000), decreasing = TRUE)
#' names(gene_stats) <- paste0("gene", 1:1000)
#' 
#' # Run GSEA
#' result <- omics_gsea(gene_stats)
#' }
omics_gsea <- function(gene_list, gene_set = NULL, organism = "human",
                       pvalueCutoff = 0.05, minGSSize = 10, maxGSSize = 500) {
  if (!requireNamespace("clusterProfiler", quietly = TRUE)) {
    stop("clusterProfiler package is required. Install with: install_omni('bioinformatics')")
  }
  
  # Use default gene sets if not provided
  if (is.null(gene_set)) {
    gene_set <- "KEGG"
  }
  
  # Perform GSEA
  gsea <- clusterProfiler::GSEA(
    geneList = gene_list,
    TERM2GENE = gene_set,
    pvalueCutoff = pvalueCutoff,
    minGSSize = minGSSize,
    maxGSSize = maxGSSize
  )
  
  structure(list(
    results = gsea,
    gene_set = gene_set,
    organism = organism
  ), class = c("omni_gsea", "list"))
}

#' Download TCGA Data
#'
#' Downloads data from The Cancer Genome Atlas (TCGA).
#'
#' @param project TCGA project code (e.g., "TCGA-BRCA").
#' @param data_type Type of data to download: "RNASeq", "miRNASeq", "Methylation", etc.
#' @param workflow_type Workflow type for RNA-seq data.
#' @param save_dir Directory to save downloaded data.
#' @param ... Additional arguments passed to TCGAbiolinks::GDCdownload.
#'
#' @return SummarizedExperiment object or file path
#' @export
#'
#' @examples
#' \dontrun{
#' # Download TCGA-BRCA RNA-seq data
#' data <- omics_tcga_download("TCGA-BRCA", "RNASeq")
#' }
omics_tcga_download <- function(project, data_type = "RNASeq",
                                workflow_type = "STAR - Counts",
                                save_dir = "./TCGA_data", ...) {
  if (!requireNamespace("TCGAbiolinks", quietly = TRUE)) {
    stop("TCGAbiolinks package is required. Install with: install_omni('bioinformatics')")
  }
  
  # Create query
  query <- TCGAbiolinks::GDCquery(
    project = project,
    data.category = data_type,
    workflow.type = workflow_type,
    ...
  )
  
  # Download data
  TCGAbiolinks::GDCdownload(query, directory = save_dir)
  
  # Prepare data
  data <- TCGAbiolinks::GDCprepare(query, directory = save_dir)
  
  structure(list(
    data = data,
    query = query,
    project = project,
    data_type = data_type
  ), class = c("omni_tcga", "list"))
}

#' Download GEO Data
#'
#' Downloads data from Gene Expression Omnibus (GEO).
#'
#' @param geo_accession GEO accession number (e.g., "GSE1009").
#' @param platform GPL platform number (optional).
#' @param save_dir Directory to save downloaded data.
#' @param ... Additional arguments passed to GEOquery::getGEO.
#'
#' @return GEOquery object or ExpressionSet
#' @export
#'
#' @examples
#' \dontrun{
#' # Download GEO dataset
#' gse <- omics_geo_download("GSE1009")
#' }
omics_geo_download <- function(geo_accession, platform = NULL,
                               save_dir = "./GEO_data", ...) {
  if (!requireNamespace("GEOquery", quietly = TRUE)) {
    stop("GEOquery package is required. Install with: install_omni('bioinformatics')")
  }
  
  # Download GEO data
  gse <- GEOquery::getGEO(
    GEO = geo_accession,
    GSEMatrix = TRUE,
    getGPL = FALSE,
    destdir = save_dir,
    ...
  )
  
  structure(list(
    data = gse,
    accession = geo_accession,
    platform = platform
  ), class = c("omni_geo", "list"))
}

#' Comprehensive Differential Expression Analysis
#'
#' Performs differential expression analysis using multiple methods.
#'
#' @param count_matrix Raw count matrix.
#' @param sample_info Sample information.
#' @param design_formula Design formula.
#' @param contrast Contrast for comparison.
#' @param methods Methods to use: "deseq2", "edger", "limma".
#' @param alpha Significance threshold.
#'
#' @return List of results from each method
#' @export
#'
#' @examples
#' \dontrun{
#' counts <- matrix(rpois(1000, 100), nrow = 100, ncol = 10)
#' sample_info <- data.frame(condition = factor(rep(c("A", "B"), each = 5)))
#' result <- omics_de_analysis(counts, sample_info, ~condition, c("condition", "B", "A"))
#' }
omics_de_analysis <- function(count_matrix, sample_info, design_formula,
                              contrast, methods = c("deseq2", "edger", "limma"),
                              alpha = 0.05) {
  results <- list()
  
  if ("deseq2" %in% methods) {
    cli::cli_alert_info("Running DESeq2...")
    results$deseq2 <- omics_deseq2(count_matrix, sample_info, design_formula, contrast, alpha)
  }
  
  if ("edger" %in% methods) {
    cli::cli_alert_info("Running edgeR...")
    group <- sample_info[[as.character(design_formula[[2]])]]
    results$edger <- omics_edger(count_matrix, group, contrast)
  }
  
  if ("limma" %in% methods) {
    cli::cli_alert_info("Running limma...")
    design <- model.matrix(design_formula, data = sample_info)
    results$limma <- omics_limma(count_matrix, design = design)
  }
  
  structure(results, class = c("omni_de_analysis", "list"))
}

#' Normalize and Transform Data
#'
#' Applies normalization and transformation to expression data.
#'
#' @param expression_matrix Expression matrix.
#' @param method Normalization method: "TMM", "RLE", "upperquartile", "none".
#' @param transform Transformation method: "log2", "vst", "rlog", "none".
#' @param prior_count Prior count for log transformation. Default is 1.
#'
#' @return Normalized and transformed expression matrix
#' @export
#'
#' @examples
#' \dontrun{
#' counts <- matrix(rpois(1000, 100), nrow = 100, ncol = 10)
#' norm_data <- omics_norm_transform(counts, method = "TMM", transform = "log2")
#' }
omics_norm_transform <- function(expression_matrix, method = "TMM",
                                 transform = "log2", prior_count = 1) {
  # Normalize
  if (method != "none") {
    dge <- edgeR::DGEList(counts = expression_matrix)
    dge <- edgeR::calcNormFactors(dge, method = method)
    expression_matrix <- edgeR::cpm(dge, log = FALSE)
  }
  
  # Transform
  if (transform == "log2") {
    expression_matrix <- log2(expression_matrix + prior_count)
  } else if (transform == "vst") {
    if (requireNamespace("DESeq2", quietly = TRUE)) {
      expression_matrix <- DESeq2::varianceStabilizingTransformation(expression_matrix)
    } else {
      warning("DESeq2 not available, using log2 transformation instead")
      expression_matrix <- log2(expression_matrix + prior_count)
    }
  } else if (transform == "rlog") {
    if (requireNamespace("DESeq2", quietly = TRUE)) {
      expression_matrix <- DESeq2::rlog(expression_matrix)
    } else {
      warning("DESeq2 not available, using log2 transformation instead")
      expression_matrix <- log2(expression_matrix + prior_count)
    }
  }
  
  expression_matrix
}

#' Batch Effect Correction
#'
#' Corrects for batch effects in expression data.
#'
#' @param expression_matrix Expression matrix.
#' @param batch Factor indicating batch membership.
#' @param covariates Additional covariates to preserve.
#' @param method Correction method: "ComBat", "limma", "sva".
#'
#' @return Corrected expression matrix
#' @export
#'
#' @examples
#' \dontrun{
#' expr <- matrix(rnorm(1000), nrow = 100, ncol = 10)
#' batch <- factor(rep(c("batch1", "batch2"), each = 5))
#' corrected <- omics_batch_correct(expr, batch)
#' }
omics_batch_correct <- function(expression_matrix, batch, covariates = NULL,
                                method = "ComBat") {
  if (method == "ComBat") {
    if (!requireNamespace("sva", quietly = TRUE)) {
      stop("sva package is required for ComBat. Install with: install.packages('sva')")
    }
    
    # Create model matrix
    if (!is.null(covariates)) {
      mod <- model.matrix(~., data = covariates)
    } else {
      mod <- matrix(1, ncol = 1, nrow = ncol(expression_matrix))
    }
    
    # Run ComBat
    corrected <- sva::ComBat(dat = expression_matrix, batch = batch, mod = mod)
  } else if (method == "limma") {
    corrected <- limma::removeBatchEffect(expression_matrix, batch = batch,
                                          covariates = covariates)
  } else if (method == "sva") {
    if (!requireNamespace("sva", quietly = TRUE)) {
      stop("sva package is required. Install with: install.packages('sva')")
    }
    
    # Estimate surrogate variables
    mod <- model.matrix(~1, data = data.frame(batch))
    mod0 <- model.matrix(~1, data = data.frame(batch))
    sva_result <- sva::sva(expression_matrix, mod, mod0)
    
    # Remove surrogate variables
    corrected <- sva::fsva(expression_matrix, mod, sva_result)$db
  }
  
  corrected
}

#' Quality Control for Expression Data
#'
#' Performs quality control checks on expression data.
#'
#' @param expression_matrix Expression matrix.
#' @param sample_info Sample information.
#' @param group Grouping variable for QC plots.
#'
#' @return List of QC results and plots
#' @export
#'
#' @examples
#' \dontrun{
#' expr <- matrix(rnorm(1000), nrow = 100, ncol = 10)
#' qc <- omics_quality_control(expr)
#' }
omics_quality_control <- function(expression_matrix, sample_info = NULL,
                                  group = NULL) {
  # Calculate QC metrics
  lib_size <- colSums(expression_matrix)
  detected_genes <- colSums(expression_matrix > 0)
  avg_expression <- rowMeans(expression_matrix)
  
  # Create QC plots
  plots <- list()
  
  # Library size plot
  plots$lib_size <- ggplot2::ggplot(
    data.frame(Sample = names(lib_size), Size = lib_size),
    ggplot2::aes(x = Sample, y = Size)
  ) +
    ggplot2::geom_bar(stat = "identity") +
    ggplot2::theme_minimal() +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1)) +
    ggplot2::labs(title = "Library Size", x = "Sample", y = "Total Counts")
  
  # Detected genes plot
  plots$detected_genes <- ggplot2::ggplot(
    data.frame(Sample = names(detected_genes), Genes = detected_genes),
    ggplot2::aes(x = Sample, y = Genes)
  ) +
    ggplot2::geom_bar(stat = "identity") +
    ggplot2::theme_minimal() +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1)) +
    ggplot2::labs(title = "Detected Genes", x = "Sample", y = "Number of Genes")
  
  # Density plot
  expr_long <- tidyr::pivot_longer(
    as.data.frame(expression_matrix),
    cols = everything(),
    names_to = "Sample",
    values_to = "Expression"
  )
  
  plots$density <- ggplot2::ggplot(expr_long, ggplot2::aes(x = Expression, color = Sample)) +
    ggplot2::geom_density() +
    ggplot2::theme_minimal() +
    ggplot2::labs(title = "Expression Density")
  
  structure(list(
    metrics = list(
      lib_size = lib_size,
      detected_genes = detected_genes,
      avg_expression = avg_expression
    ),
    plots = plots
  ), class = c("omni_qc", "list"))
}

#' Filter Low-Expressed Genes
#'
#' Filters out low-expressed genes from expression data.
#'
#' @param expression_matrix Expression matrix.
#' @param min_count Minimum count threshold. Default is 10.
#' @param min_samples Minimum number of samples with count > min_count. Default is 2.
#' @param method Filtering method: "cpm", "count", "rpkm".
#'
#' @return Filtered expression matrix
#' @export
#'
#' @examples
#' \dontrun{
#' counts <- matrix(rpois(1000, 5), nrow = 100, ncol = 10)
#' filtered <- omics_filter_genes(counts, min_count = 10, min_samples = 3)
#' }
omics_filter_genes <- function(expression_matrix, min_count = 10,
                               min_samples = 2, method = "count") {
  if (method == "count") {
    keep <- rowSums(expression_matrix >= min_count) >= min_samples
  } else if (method == "cpm") {
    cpm <- edgeR::cpm(expression_matrix)
    keep <- rowSums(cpm >= min_count) >= min_samples
  } else if (method == "rpkm") {
    # Would need gene lengths for RPKM
    warning("RPKM filtering requires gene lengths, using count method instead")
    keep <- rowSums(expression_matrix >= min_count) >= min_samples
  }
  
  expression_matrix[keep, , drop = FALSE]
}

#' Get Top Genes
#'
#' Extracts top differentially expressed genes.
#'
#' @param de_results Differential expression results.
#' @param n_top Number of top genes to return. Default is 100.
#' @param sort_by Column to sort by. Default is "padj".
#' @param ascending Sort in ascending order. Default is TRUE.
#'
#' @return Data frame of top genes
#' @export
#'
#' @examples
#' \dontrun{
#' results <- data.frame(
#'   log2FoldChange = rnorm(1000),
#'   padj = runif(1000)
#' )
#' top_genes <- omics_top_genes(results, n_top = 50)
#' }
omics_top_genes <- function(de_results, n_top = 100, sort_by = "padj",
                            ascending = TRUE) {
  # Sort results
  if (ascending) {
    de_results <- de_results[order(de_results[[sort_by]]), ]
  } else {
    de_results <- de_results[order(de_results[[sort_by]], decreasing = TRUE), ]
  }
  
  # Return top genes
  head(de_results, n_top)
}

#' Gene Annotation
#'
#' Annotates genes with additional information.
#'
#' @param gene_list List of genes.
#' @param from Type of gene identifier. Default is "SYMBOL".
#' @param to Type of annotation to add. Default is "ENTREZID".
#' @param organism Organism. Default is "org.Hs.eg.db".
#'
#' @return Data frame with gene annotations
#' @export
#'
#' @examples
#' \dontrun{
#' genes <- c("TP53", "BRCA1", "EGFR")
#' annotated <- omics_annotate(genes)
#' }
omics_annotate <- function(gene_list, from = "SYMBOL", to = "ENTREZID",
                           organism = "org.Hs.eg.db") {
  if (!requireNamespace("org.Hs.eg.db", quietly = TRUE)) {
    stop("org.Hs.eg.db package is required. Install with: install_omni('bioinformatics')")
  }
  
  # Map gene IDs
  mapped <- AnnotationDbi::mapIds(
    get(organism),
    keys = gene_list,
    column = to,
    keytype = from,
    multiVals = "first"
  )
  
  data.frame(
    gene = gene_list,
    annotation = mapped,
    stringsAsFactors = FALSE
  )
}

#' Comprehensive Enrichment Analysis
#'
#' Performs multiple enrichment analyses.
#'
#' @param gene_list List of genes.
#' @param analyses Types of enrichment to perform: "kegg", "go", "gsea".
#' @param organism Organism.
#' @param ... Additional arguments passed to individual enrichment functions.
#'
#' @return List of enrichment results
#' @export
#'
#' @examples
#' \dontrun{
#' genes <- c("TP53", "BRCA1", "EGFR", "MYC", "KRAS")
#' result <- omics_enrichment(genes, analyses = c("kegg", "go"))
#' }
omics_enrichment <- function(gene_list, analyses = c("kegg", "go"),
                             organism = "hsa", ...) {
  results <- list()
  
  if ("kegg" %in% analyses) {
    cli::cli_alert_info("Running KEGG enrichment...")
    results$kegg <- omics_kegg(gene_list, organism = organism, ...)
  }
  
  if ("go" %in% analyses) {
    cli::cli_alert_info("Running GO enrichment...")
    results$go <- omics_go(gene_list, organism = organism, ...)
  }
  
  if ("gsea" %in% analyses) {
    cli::cli_alert_info("Running GSEA...")
    results$gsea <- omics_gsea(gene_list, organism = organism, ...)
  }
  
  structure(results, class = c("omni_enrichment", "list"))
}

#' Pathway Visualization
#'
#' Visualizes enriched pathways.
#'
#' @param enrichment_result Enrichment result object.
#' @param type Type of plot: "bar", "dot", "cnet", "heat".
#' @param n_show Number of pathways to show. Default is 20.
#' @param title Plot title.
#'
#' @return ggplot object or ComplexHeatmap object
#' @export
#'
#' @examples
#' \dontrun{
#' genes <- c("TP53", "BRCA1", "EGFR", "MYC", "KRAS")
#' result <- omics_kegg(genes)
#' p <- omics_pathway(result, type = "bar")
#' }
omics_pathway <- function(enrichment_result, type = "bar", n_show = 20,
                          title = "Pathway Enrichment") {
  # Extract results
  if (inherits(enrichment_result, "omni_kegg")) {
    res <- enrichment_result$results
  } else if (inherits(enrichment_result, "omni_go")) {
    res <- enrichment_result$results
  } else {
    res <- enrichment_result
  }
  
  # Create plot based on type
  if (type == "bar") {
    p <- clusterProfiler::barplot(res, showCategory = n_show) +
      ggplot2::labs(title = title)
  } else if (type == "dot") {
    p <- clusterProfiler::dotplot(res, showCategory = n_show) +
      ggplot2::labs(title = title)
  } else if (type == "cnet") {
    p <- clusterProfiler::cnetplot(res, showCategory = n_show)
  } else if (type == "heat") {
    p <- clusterProfiler::heatplot(res, showCategory = n_show)
  }
  
  p
}
