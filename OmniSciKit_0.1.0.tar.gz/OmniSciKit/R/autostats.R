#' @importFrom utils globalVariables
globalVariables(c('sd', 'median'))

#' Automated Statistical Analysis
#'
#' Automatically selects and performs appropriate statistical tests based on data characteristics.
#' Inspired by the automatedtests package (Zeevat et al.), this function intelligently chooses
#' the right statistical method without requiring manual selection.
#'
#' @param x Numeric vector, formula, or data frame.
#' @param y Optional numeric vector, grouping factor, or response variable name.
#' @param data Data frame when using formula interface.
#' @param paired Logical for paired designs.
#' @param alpha Significance level (default 0.05).
#' @param verbose Logical to print detailed output.
#' @return List with test results, selected method, and interpretation.
#' @examples
#' # Example 1: Two-group comparison (auto-selects t-test or Wilcoxon)
#' set.seed(123)
#' group1 <- rnorm(30, mean = 5, sd = 1)
#' group2 <- rnorm(30, mean = 6, sd = 1)
#' result <- autostats(group1, group2)
#' print(result)
#'
#' # Example 2: Multiple group comparison (auto-selects ANOVA or Kruskal-Wallis)
#' set.seed(123)
#' values <- c(rnorm(20, 5), rnorm(20, 7), rnorm(20, 6))
#' groups <- rep(c("A", "B", "C"), each = 20)
#' result <- autostats(values, groups)
#' print(result)
#'
#' @export
autostats <- function(x, y = NULL, data = NULL, paired = FALSE, alpha = 0.05, verbose = TRUE) {
  
  if (inherits(x, "formula")) {
    if (is.null(data)) {
      stop("Data frame required when using formula interface")
    }
    formula_vars <- all.vars(x)
    if (length(formula_vars) == 2) {
      y <- data[[formula_vars[1]]]  # Response
      x <- data[[formula_vars[2]]]  # Grouping
    } else {
      stop("Formula must be of form: response ~ group")
    }
  }
  
  # Determine data type and structure
  result <- list()
  
  # Case 1: Single vector (one-sample test)
  if (is.null(y) && is.numeric(x)) {
    result <- .auto_one_sample(x, alpha, verbose)
  }
  # Case 2: Two vectors (two-sample or paired test)
  else if (is.numeric(x) && is.numeric(y) && !is.factor(y)) {
    if (paired) {
      result <- .auto_paired(x, y, alpha, verbose)
    } else {
      result <- .auto_two_sample(x, y, alpha, verbose)
    }
  }
  # Case 3: Numeric vector with grouping factor (ANOVA or Kruskal-Wallis)
  else if (is.numeric(x) && (is.factor(y) || is.character(y))) {
    result <- .auto_multi_group(x, y, alpha, verbose)
  }
  # Case 4: Both factors (Chi-square test)
  else if ((is.factor(x) || is.character(x)) && (is.factor(y) || is.character(y))) {
    result <- .auto_categorical(x, y, alpha, verbose)
  }
  else {
    stop("Unable to determine appropriate test for provided data types")
  }
  
  class(result) <- c("autostats", "omni_result")
  return(result)
}

#' @keywords internal
.auto_one_sample <- function(x, alpha, verbose) {
  # Check normality
  if (length(x) >= 3 && length(x) <= 5000) {
    norm_test <- shapiro.test(x)
    is_normal <- norm_test$p.value > 0.05
  } else {
    is_normal <- TRUE  # Assume normal for large samples
  }
  
  if (is_normal) {
    test_result <- t.test(x)
    method <- "One-sample t-test"
    reason <- "Data appears normally distributed"
  } else {
    test_result <- wilcox.test(x, mu = median(x))
    method <- "One-sample Wilcoxon signed-rank test"
    reason <- "Data deviates from normal distribution"
  }
  
  result <- list(
    test_type = "One-sample",
    method = method,
    selection_reason = reason,
    statistic = test_result$statistic,
    p_value = test_result$p.value,
    estimate = test_result$estimate,
    conf_int = test_result$conf.int,
    normality_test = if(exists("norm_test")) norm_test$p.value else NULL,
    interpretation = ifelse(test_result$p.value < alpha,
                           sprintf("Significant difference from null (p = %.4f)", test_result$p.value),
                           sprintf("No significant difference from null (p = %.4f)", test_result$p.value)),
    data = list(x = x)
  )
  
  if (verbose) {
    cat("\n=== Automated Statistical Analysis ===\n")
    cat(sprintf("Selected Test: %s\n", method))
    cat(sprintf("Reason: %s\n", reason))
    cat(sprintf("p-value: %.4f\n", test_result$p.value))
    cat(sprintf("Conclusion: %s\n", result$interpretation))
  }
  
  return(result)
}

#' @keywords internal
.auto_two_sample <- function(x, y, alpha, verbose) {
  # Check normality for both groups
  nx <- length(x)
  ny <- length(y)
  
  if (nx >= 3 && nx <= 5000) {
    norm_x <- shapiro.test(x)$p.value > 0.05
  } else {
    norm_x <- TRUE
  }
  
  if (ny >= 3 && ny <= 5000) {
    norm_y <- shapiro.test(y)$p.value > 0.05
  } else {
    norm_y <- TRUE
  }
  
  # Check equal variances
  if (norm_x && norm_y) {
    var_test <- var.test(x, y)
    equal_var <- var_test$p.value > 0.05
    
    if (equal_var) {
      test_result <- t.test(x, y, var.equal = TRUE)
      method <- "Two-sample t-test (equal variances)"
      reason <- "Both groups normal, equal variances assumed"
    } else {
      test_result <- t.test(x, y, var.equal = FALSE)
      method <- "Welch's t-test (unequal variances)"
      reason <- "Both groups normal, unequal variances detected"
    }
  } else {
    test_result <- wilcox.test(x, y)
    method <- "Mann-Whitney U test"
    reason <- "At least one group non-normal"
  }
  
  result <- list(
    test_type = "Two-sample",
    method = method,
    selection_reason = reason,
    statistic = test_result$statistic,
    p_value = test_result$p.value,
    estimate = test_result$estimate,
    conf_int = test_result$conf.int,
    interpretation = ifelse(test_result$p.value < alpha,
                           sprintf("Significant difference between groups (p = %.4f)", test_result$p.value),
                           sprintf("No significant difference between groups (p = %.4f)", test_result$p.value)),
    data = list(x = x, y = y)
  )
  
  if (verbose) {
    cat("\n=== Automated Statistical Analysis ===\n")
    cat(sprintf("Selected Test: %s\n", method))
    cat(sprintf("Reason: %s\n", reason))
    cat(sprintf("p-value: %.4f\n", test_result$p.value))
    cat(sprintf("Conclusion: %s\n", result$interpretation))
  }
  
  return(result)
}

#' @keywords internal
.auto_paired <- function(x, y, alpha, verbose) {
  # Check normality of differences
  diff <- x - y
  if (length(diff) >= 3 && length(diff) <= 5000) {
    norm_test <- shapiro.test(diff)
    is_normal <- norm_test$p.value > 0.05
  } else {
    is_normal <- TRUE
  }
  
  if (is_normal) {
    test_result <- t.test(x, y, paired = TRUE)
    method <- "Paired t-test"
    reason <- "Differences appear normally distributed"
  } else {
    test_result <- wilcox.test(x, y, paired = TRUE)
    method <- "Wilcoxon signed-rank test (paired)"
    reason <- "Differences deviate from normal distribution"
  }
  
  result <- list(
    test_type = "Paired",
    method = method,
    selection_reason = reason,
    statistic = test_result$statistic,
    p_value = test_result$p.value,
    estimate = test_result$estimate,
    conf_int = test_result$conf.int,
    interpretation = ifelse(test_result$p.value < alpha,
                           sprintf("Significant difference between paired observations (p = %.4f)", test_result$p.value),
                           sprintf("No significant difference between paired observations (p = %.4f)", test_result$p.value)),
    data = list(x = x, y = y, difference = diff)
  )
  
  if (verbose) {
    cat("\n=== Automated Statistical Analysis ===\n")
    cat(sprintf("Selected Test: %s\n", method))
    cat(sprintf("Reason: %s\n", reason))
    cat(sprintf("p-value: %.4f\n", test_result$p.value))
    cat(sprintf("Conclusion: %s\n", result$interpretation))
  }
  
  return(result)
}

#' @keywords internal
.auto_multi_group <- function(x, y, alpha, verbose) {
  y <- as.factor(y)
  n_groups <- length(levels(y))
  
  if (n_groups < 2) {
    stop("Need at least 2 groups for comparison")
  }
  
  # Check normality within each group
  groups <- split(x, y)
  all_normal <- TRUE
  for (g in groups) {
    if (length(g) >= 3 && length(g) <= 5000) {
      if (shapiro.test(g)$p.value <= 0.05) {
        all_normal <- FALSE
        break
      }
    }
  }
  
  # Check equal variances
  if (all_normal && n_groups == 2) {
    return(.auto_two_sample(groups[[1]], groups[[2]], alpha, verbose))
  }
  
  if (all_normal) {
    # ANOVA
    df <- data.frame(x = x, y = y)
    aov_result <- aov(x ~ y, data = df)
    aov_summary <- summary(aov_result)[[1]]
    
    test_result <- list(
      statistic = aov_summary["y", "F value"],
      p_value = aov_summary["y", "Pr(>F)"]
    )
    method <- "One-way ANOVA"
    reason <- "All groups normally distributed"
    
    # Post-hoc test if significant
    post_hoc <- NULL
    if (test_result$p_value < alpha) {
      post_hoc <- TukeyHSD(aov_result)
    }
    
    result <- list(
      test_type = "Multi-group",
      method = method,
      selection_reason = reason,
      statistic = test_result$statistic,
      p_value = test_result$p_value,
      group_means = tapply(x, y, mean),
      group_sds <- tapply(x, y, sd),
      post_hoc = post_hoc,
      interpretation = ifelse(test_result$p_value < alpha,
                             sprintf("Significant differences among groups (p = %.4f)", test_result$p_value),
                             sprintf("No significant differences among groups (p = %.4f)", test_result$p_value)),
      data = list(x = x, y = y)
    )
  } else {
    # Kruskal-Wallis
    test_result <- kruskal.test(x ~ y)
    method <- "Kruskal-Wallis test"
    reason <- "At least one group non-normal"
    
    result <- list(
      test_type = "Multi-group",
      method = method,
      selection_reason = reason,
      statistic = test_result$statistic,
      p_value = test_result$p.value,
      group_medians = tapply(x, y, median),
      interpretation = ifelse(test_result$p.value < alpha,
                             sprintf("Significant differences among groups (p = %.4f)", test_result$p.value),
                             sprintf("No significant differences among groups (p = %.4f)", test_result$p.value)),
      data = list(x = x, y = y)
    )
  }
  
  if (verbose) {
    cat("\n=== Automated Statistical Analysis ===\n")
    cat(sprintf("Selected Test: %s\n", method))
    cat(sprintf("Reason: %s\n", reason))
    cat(sprintf("Number of groups: %d\n", n_groups))
    cat(sprintf("p-value: %.4f\n", ifelse(is.null(test_result$p_value), NA, test_result$p_value)))
    cat(sprintf("Conclusion: %s\n", result$interpretation))
  }
  
  return(result)
}

#' @keywords internal
.auto_categorical <- function(x, y, alpha, verbose) {
  # Chi-square test of independence
  contingency <- table(x, y)
  test_result <- chisq.test(contingency)
  
  # Check expected frequencies
  expected <- chisq.test(contingency)$expected
  min_expected <- min(expected)
  
  if (min_expected < 5) {
    method <- "Fisher's exact test"
    reason <- "Expected frequencies < 5 in some cells"
    test_result <- fisher.test(contingency)
    statistic <- NULL
  } else {
    method <- "Chi-square test of independence"
    reason <- "All expected frequencies >= 5"
    statistic <- test_result$statistic
  }
  
  result <- list(
    test_type = "Categorical",
    method = method,
    selection_reason = reason,
    statistic = statistic,
    p_value = test_result$p.value,
    contingency_table = contingency,
    expected_frequencies = expected,
    interpretation = ifelse(test_result$p.value < alpha,
                           sprintf("Significant association between variables (p = %.4f)", test_result$p.value),
                           sprintf("No significant association between variables (p = %.4f)", test_result$p.value)),
    data = list(x = x, y = y)
  )
  
  if (verbose) {
    cat("\n=== Automated Statistical Analysis ===\n")
    cat(sprintf("Selected Test: %s\n", method))
    cat(sprintf("Reason: %s\n", reason))
    cat(sprintf("p-value: %.4f\n", test_result$p.value))
    cat(sprintf("Conclusion: %s\n", result$interpretation))
  }
  
  return(result)
}

#' Print Method for autostats Objects
#'
#' @param x autostats object.
#' @param ... Additional arguments.
#' @export
print.autostats <- function(x, ...) {
  cat("\n=== Automated Statistical Analysis Results ===\n")
  cat(sprintf("Test Type: %s\n", x$test_type))
  cat(sprintf("Method: %s\n", x$method))
  cat(sprintf("Selection Reason: %s\n", x$selection_reason))
  
  if (!is.null(x$statistic)) {
    cat(sprintf("Test Statistic: %.4f\n", x$statistic))
  }
  cat(sprintf("p-value: %.4f\n", x$p_value))
  cat(sprintf("Interpretation: %s\n", x$interpretation))
  
  if (!is.null(x$post_hoc)) {
    cat("\n--- Post-hoc Analysis ---\n")
    print(x$post_hoc)
  }
  
  invisible(x)
}

#' Summary Method for autostats Objects
#'
#' @param object autostats object.
#' @param ... Additional arguments.
#' @export
summary.autostats <- function(object, ...) {
  print(object)
  
  cat("\n=== Detailed Results ===\n")
  if (!is.null(object$data$x) && !is.null(object$data$y)) {
    if (is.numeric(object$data$x) && is.numeric(object$data$y)) {
      cat(sprintf("\nGroup 1: n=%d, mean=%.2f, sd=%.2f\n", 
                  length(object$data$x), mean(object$data$x), sd(object$data$x)))
      cat(sprintf("Group 2: n=%d, mean=%.2f, sd=%.2f\n", 
                  length(object$data$y), mean(object$data$y), sd(object$data$y)))
    }
  }
  
  if (!is.null(object$group_means)) {
    cat("\nGroup Means:\n")
    print(object$group_means)
  }
  
  invisible(object)
}
