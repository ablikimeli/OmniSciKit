# OmniSciKit

[![R-CMD-check](https://github.com/yourusername/OmniSciKit/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/yourusername/OmniSciKit/actions/workflows/R-CMD-check.yaml)
[![Codecov test coverage](https://codecov.io/gh/yourusername/OmniSciKit/branch/main/graph/badge.svg)](https://codecov.io/gh/yourusername/OmniSciKit?branch=main)

## Overview

OmniSciKit is a comprehensive R package that provides a unified framework for scientific research, including:

- **Bioinformatics**: Multi-omics data analysis, differential expression, pathway enrichment
- **Mendelian Randomization**: Causal inference methods and sensitivity analysis
- **Machine Learning**: Prediction models, cross-validation, feature selection
- **Epidemiology**: Infectious disease modeling, R0 estimation, intervention analysis
- **Statistics**: Comprehensive statistical tests and regression analysis
- **Sample Size**: Power analysis and sample size calculations

## Installation

### From CRAN (coming soon)

```r
install.packages("OmniSciKit")
```

### From GitHub

```r
# install.packages("devtools")
devtools::install_github("yourusername/OmniSciKit")
```

## Quick Start

```r
library(OmniSciKit)

# Check dependencies
check_deps()

# Install optional dependencies
install_omni(modules = c("bioinformatics", "machine_learning"))

# Set options
set_omni_options(palette = "viridis", sig_level = 0.05)

# Load example data
data(omni_demo)
head(omni_demo)
```

## Modules

### 1. Bioinformatics (`omics`)

```r
# Differential expression analysis
result <- omics_deseq2(count_matrix, sample_info, ~condition, c("condition", "treatment", "control"))

# Volcano plot
omics_volcano(result$results)

# Pathway enrichment
enrich <- omics_kegg(gene_list)
```

### 2. Mendelian Randomization (`mr`)

```r
# IVW MR
mr_result <- mr_ivw(b_exp, b_out, se_exp, se_out)

# Sensitivity analysis
sens <- mr_sensitivity(b_exp, b_out, se_exp, se_out)

# Funnel plot
mr_funnel_plot(b_exp, b_out, se_exp, se_out)
```

### 3. Machine Learning (`ml`)

```r
# Split data
split <- ml_train_test_split(data, "target")

# Train model
model <- ml_random_forest(target ~ ., split$train)

# Evaluate
pred <- predict(model, split$test)
ml_evaluate(split$test$target, pred, "classification")
```

### 4. Epidemiology (`epi`)

```r
# SIR model
sir <- epi_sir(beta = 0.3, gamma = 0.1, N = 1000)
plot(sir)

# Estimate R0
r0 <- epi_r0_estimate(incidence_data)
```

### 5. Statistics (`stats`)

```r
# T-test
ttest <- stats_ttest(group1, group2)

# Regression
reg <- stats_regression(y ~ x1 + x2, data)

# ROC analysis
roc <- stats_roc_analysis(actual, predicted)
```

### 6. Sample Size (`ss`)

```r
# T-test sample size
ss <- ss_ttest(delta = 0.5, sd = 1, power = 0.8)

# Survival analysis sample size
ss_cox(hr = 0.7, p = 0.3, power = 0.8)
```

## Documentation

For detailed documentation and examples, see the package vignettes:

```r
browseVignettes("OmniSciKit")
```

## Contributing

Contributions are welcome! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

## License

This package is licensed under the MIT License. See [LICENSE](LICENSE) for details.

## Citation

If you use OmniSciKit in your research, please cite:

```
Ablikim A (2026). OmniSciKit: A Comprehensive Toolkit for Scientific Research.
R package version 0.1.0.
```

## Contact

For questions and support, please open an issue on GitHub or contact the maintainer.

---

**Note**: This package is under active development. Some features may change in future versions.
