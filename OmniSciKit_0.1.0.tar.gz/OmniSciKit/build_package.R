# Build OmniSciKit Package
# Run this script in R to build the package

# Set working directory to package root
setwd("D:/QClaw/R包/OmniSciKit")

# Load required packages
if (!requireNamespace("devtools", quietly = TRUE)) {
  install.packages("devtools")
}
if (!requireNamespace("roxygen2", quietly = TRUE)) {
  install.packages("roxygen2")
}

# Generate documentation
cat("Generating documentation...\n")
devtools::document()

# Run R CMD check
cat("Running R CMD check...\n")
check_result <- devtools::check()

# Build package
cat("Building package...\n")
build_result <- devtools::build()

cat("Package built successfully!\n")
cat("Package location:", build_result, "\n")

# Install package locally
cat("Installing package locally...\n")
devtools::install()

cat("Done!\n")
