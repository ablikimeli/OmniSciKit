setwd('D:/QClaw/R包/OmniSciKit')
set.seed(123)

# Create datasets
omni_demo <- data.frame(
  patient_id = 1:200,
  age = round(rnorm(200, mean = 55, sd = 15)),
  sex = sample(c('Male', 'Female'), 200, replace = TRUE),
  treatment = sample(c('A', 'B'), 200, replace = TRUE),
  baseline_score = round(rnorm(200, mean = 50, sd = 10)),
  follow_up_score = round(rnorm(200, mean = 55, sd = 12)),
  response = sample(c('Yes', 'No'), 200, replace = TRUE, prob = c(0.6, 0.4)),
  survival_time = round(rexp(200, rate = 0.1)),
  event = sample(c(0, 1), 200, replace = TRUE, prob = c(0.3, 0.7))
)

omni_epi <- data.frame(
  day = 1:365,
  cases = pmax(0, round(rpois(365, lambda = c(rep(1, 50), seq(1, 100, length.out = 100), seq(100, 20, length.out = 100), rep(10, 115))))),
  deaths = pmax(0, round(rpois(365, lambda = 0.02 * c(rep(1, 50), seq(1, 100, length.out = 100), seq(100, 20, length.out = 100), rep(10, 115))))),
  recoveries = pmax(0, round(rpois(365, lambda = 0.8 * c(rep(1, 50), seq(1, 100, length.out = 100), seq(100, 20, length.out = 100), rep(10, 115)))))
)
omni_epi$cumulative_cases <- cumsum(omni_epi$cases)

omni_ml <- data.frame(
  id = 1:500,
  feature_1 = rnorm(500),
  feature_2 = rnorm(500),
  feature_3 = rnorm(500),
  feature_4 = rnorm(500),
  feature_5 = rnorm(500),
  feature_6 = rnorm(500),
  feature_7 = rnorm(500),
  feature_8 = rnorm(500),
  outcome = factor(sample(c(0, 1), 500, replace = TRUE))
)

# Save datasets
save(omni_demo, file = 'data/omni_demo.rda')
save(omni_epi, file = 'data/omni_epi.rda')
save(omni_ml, file = 'data/omni_ml.rda')

cat('Datasets created successfully!\n')
