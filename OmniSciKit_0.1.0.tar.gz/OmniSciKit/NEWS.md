# OmniSciKit News

## Version 0.1.0 (2026-04-26)

### Initial Release

This is the first release of OmniSciKit, a comprehensive R package for biomedical and public health research.

### Features

#### Sample Size Calculation
- `ss_ttest()`: Two-sample and one-sample t-test sample size
- `ss_anova()`: One-way ANOVA sample size
- `ss_correlation()`: Correlation study sample size
- `ss_proportion()`: Proportion comparison sample size
- `ss_regression()`: Linear regression sample size
- `ss_survival()`: Survival analysis sample size
- `ss_logistic()`: Logistic regression sample size
- Additional specialized functions for various study designs

#### Statistical Analysis
- `stats_ttest()`: t-test with effect size and visualization
- `stats_wilcoxon()`: Wilcoxon rank-sum test
- `stats_anova()`: One-way ANOVA
- `stats_correlation()`: Correlation analysis
- `stats_regression()`: Linear regression
- `stats_chisq()`: Chi-square test
- `stats_normality()`: Normality tests
- Additional statistical functions

#### Epidemiology
- `epi_r0()`: Basic reproduction number estimation
- `epi_sir()`: SIR model simulation
- `epi_seir()`: SEIR model simulation
- `epi_incidence()`: Incidence rate calculation
- `epi_prevalence()`: Prevalence estimation
- `epi_cfr()`: Case fatality rate
- `epi_rt()`: Time-varying reproduction number
- Additional epidemiological functions

#### Machine Learning
- `ml_train_test_split()`: Data splitting
- `ml_preprocess()`: Data preprocessing
- `ml_train()`: Model training
- `ml_predict()`: Prediction
- `ml_evaluate()`: Model evaluation
- `ml_cv()`: Cross-validation
- Additional ML functions

#### Omics Analysis
- `omics_pca()`: Principal component analysis
- `omics_normalize()`: Data normalization
- `omics_log2()`: Log2 transformation
- `omics_qc()`: Quality control
- `omics_heatmap()`: Heatmap visualization
- `omics_de()`: Differential expression
- Additional omics functions

#### Mendelian Randomization
- `mr_power()`: Power calculation
- `mr_pleiotropy()`: Pleiotropy test
- `mr_ivw()`: Inverse variance weighted
- `mr_egger()`: MR-Egger regression
- Additional MR functions

#### Utilities
- `check_deps()`: Dependency management
- `autostats()`: Automated statistical analysis
- `theme_omni()`: Custom ggplot2 theme
- Dataset management functions

### Datasets
- `omni_clinical`: Simulated clinical trial data
- `omni_expression`: Simulated gene expression data
- `omni_epidemic`: Simulated outbreak data
- `omni_ml_data`: Simulated machine learning data
- `omni_mr`: Simulated GWAS summary statistics
- `omni_timeseries`: Simulated time series data

### Documentation
- Comprehensive vignettes
- Complete function documentation with examples
- Package-level documentation
- Citation information

### Notes
- All datasets are simulated for demonstration purposes
- Soft dependency approach for optional packages
- Cross-platform compatible
- UTF-8 encoding throughout
