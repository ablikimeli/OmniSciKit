test_that("stats_ttest works", {
  x <- rnorm(50, mean = 0)
  y <- rnorm(50, mean = 1)
  result <- stats_ttest(x, y)
  expect_type(result, "list")
})

test_that("stats_regression works", {
  data <- create_test_data()
  result <- stats_regression(y ~ x, data)
  expect_type(result, "list")
})

test_that("stats_correlation works", {
  x <- rnorm(50)
  y <- rnorm(50)
  result <- stats_correlation(x, y)
  expect_type(result, "list")
})
