# Test helper functions

# Create test data
create_test_data <- function(n = 100) {
  data.frame(
    x = rnorm(n),
    y = rnorm(n),
    group = sample(c("A", "B"), n, replace = TRUE),
    outcome = rbinom(n, 1, 0.5)
  )
}

# Create test expression data
create_test_expression <- function(n_genes = 100, n_samples = 10) {
  matrix(rnorm(n_genes * n_samples), nrow = n_genes, ncol = n_samples)
}
