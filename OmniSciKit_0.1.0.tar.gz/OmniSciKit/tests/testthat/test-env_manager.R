test_that("check_deps works", {
  deps <- check_deps()
  expect_type(deps, "list")
})

test_that("set_omni_options works", {
  opts <- set_omni_options(palette = "viridis", sig_level = 0.01)
  expect_type(opts, "list")
  expect_equal(opts$omni.palette, "viridis")
})

test_that("get_omni_option works", {
  set_omni_options(palette = "viridis")
  expect_equal(get_omni_option("palette"), "viridis")
})
