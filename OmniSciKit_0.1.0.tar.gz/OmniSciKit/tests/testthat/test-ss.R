test_that("ss_ttest works", {
  result <- ss_ttest(delta = 0.5, sd = 1, power = 0.8)
  expect_type(result, "list")
  expect_gt(result$n, 0)
})

test_that("ss_chisq works", {
  result <- ss_chisq(p1 = 0.3, p2 = 0.5, power = 0.8)
  expect_type(result, "list")
  expect_gt(result$n, 0)
})

test_that("ss_correlation works", {
  result <- ss_correlation(r = 0.3, power = 0.8)
  expect_type(result, "list")
  expect_gt(result$n, 0)
})
