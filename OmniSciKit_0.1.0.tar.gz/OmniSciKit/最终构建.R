# 最终构建脚本 - 生成可安装的R包
# 在R中运行此脚本

# 设置工作目录
setwd("D:/QClaw/R包/OmniSciKit")

# 安装必要的包
if (!requireNamespace("devtools", quietly = TRUE)) {
  install.packages("devtools")
}
if (!requireNamespace("roxygen2", quietly = TRUE)) {
  install.packages("roxygen2")
}

# 生成文档
cat("正在生成文档...\n")
devtools::document()

# 构建包（不包含vignettes以加快速度）
cat("正在构建包...\n")
build_result <- devtools::build(vignettes = FALSE)

cat("包构建成功！\n")
cat("包文件位置:", build_result, "\n")

# 检查包
cat("正在检查包...\n")
check_result <- devtools::check(built_tarball = build_result)

cat("检查完成！\n")
print(check_result)
